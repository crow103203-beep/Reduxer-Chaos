Obtain the three exact library versions documented in the project README from upstream. Third-party JARs are intentionally omitted.
