﻿param(
    [Parameter(Mandatory)] [string]$ModsIndex,   # _index.json written by the Modrinth fetch script
    [Parameter(Mandatory)] [string]$ModsDir,     # folder with the downloaded jars
    [Parameter(Mandatory)] [string]$AddonJar,    # built upgrader-chaos jar
    [Parameter(Mandatory)] [string]$OutDir,
    [string]$NeoForge = '21.1.264'
)
# Builds the modpack twice: a plain folder (copy into any NeoForge 1.21.1 instance) and a .mrpack
# (import into Prism / Modrinth App / ATLauncher and other launchers that read Modrinth packs).
$ErrorActionPreference = 'Stop'

$name = 'Сжатый Хаос'
$folder = Join-Path $OutDir "$name (NeoForge 1.21.1)"
if (Test-Path $folder) { Remove-Item -Recurse -Force $folder }
New-Item -ItemType Directory -Force (Join-Path $folder 'mods') | Out-Null

$index = Get-Content $ModsIndex -Raw | ConvertFrom-Json
$files = @()
foreach ($mod in $index) {
    $target = $mod.file
    Copy-Item -LiteralPath (Join-Path $ModsDir $mod.file) -Destination (Join-Path $folder "mods\$target")
    $files += [ordered]@{
        path      = "mods/$target"
        hashes    = [ordered]@{ sha1 = $mod.sha1; sha512 = $mod.sha512 }
        # Server-only mods still go to clients: singleplayer runs the server inside the game.
        env       = [ordered]@{ client = 'required'; server = $(if ($mod.server -eq 'unsupported') { 'unsupported' } else { 'required' }) }
        downloads = @($mod.url)
        fileSize  = $mod.size
    }
}
Copy-Item -LiteralPath $AddonJar -Destination (Join-Path $folder 'mods')

# .mrpack = zip with modrinth.index.json + overrides/ (our own jar is not on Modrinth, so it rides in overrides).
$staging = Join-Path $OutDir '_mrpack'
if (Test-Path $staging) { Remove-Item -Recurse -Force $staging }
New-Item -ItemType Directory -Force (Join-Path $staging 'overrides\mods') | Out-Null
Copy-Item -LiteralPath $AddonJar -Destination (Join-Path $staging 'overrides\mods')
$manifest = [ordered]@{
    formatVersion = 1
    game          = 'minecraft'
    versionId     = '1.3.1'
    name          = $name
    summary       = 'Сожми любой предмет в катастрофу: 5 апгрейдеров, 90 явлений от дождя до торнадо EF5, потеря органов, галлюцинации и свой биом.'
    files         = $files
    dependencies  = [ordered]@{ minecraft = '1.21.1'; neoforge = $NeoForge }
}
$json = $manifest | ConvertTo-Json -Depth 6
[IO.File]::WriteAllText((Join-Path $staging 'modrinth.index.json'), $json, (New-Object System.Text.UTF8Encoding($false)))
$mrpack = Join-Path $OutDir 'upgrader-chaos-pack-1.3.1.mrpack'
if (Test-Path $mrpack) { Remove-Item -Force $mrpack }
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
# Windows PowerShell's CreateFromDirectory writes "overrides\mods\..." entries; launchers expect forward slashes.
$zip = [System.IO.Compression.ZipFile]::Open($mrpack, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    $base = (Resolve-Path $staging).Path.TrimEnd('\') + '\'
    foreach ($file in Get-ChildItem $staging -Recurse -File) {
        $entry = $file.FullName.Substring($base.Length).Replace('\', '/')
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file.FullName, $entry) | Out-Null
    }
} finally {
    $zip.Dispose()
}
Remove-Item -Recurse -Force $staging

Write-Output "folder: $folder ($((Get-ChildItem (Join-Path $folder 'mods')).Count) files)"
Write-Output "mrpack: $mrpack"
