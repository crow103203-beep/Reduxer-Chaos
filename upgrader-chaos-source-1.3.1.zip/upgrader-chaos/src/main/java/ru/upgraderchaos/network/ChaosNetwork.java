package ru.upgraderchaos.network;

import io.netty.buffer.ByteBuf;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import ru.upgraderchaos.ChaosAttachments;
import ru.upgraderchaos.UpgraderChaos;
import ru.upgraderchaos.client.ClientChaos;

public final class ChaosNetwork {

    // Client-side effect kinds, see ClientChaos. Sound kinds replace each other; the rest stack.
    public static final int SOUND_SHUFFLE = 1;
    public static final int SOUND_MONO = 2;
    public static final int SOUND_CHIPMUNK = 3;
    public static final int SOUND_DEEP = 4;
    public static final int SOUND_SILENCE = 5;
    public static final int SOUND_ECHO = 6;
    public static final int SOUND_GHOSTS = 7;
    public static final int SOUND_BROKEN_RADIO = 8;
    public static final int FOG = 20;
    public static final int BLOOD_MOON = 21;
    public static final int UPSIDE_DOWN = 22;
    public static final int CAROUSEL = 23;
    public static final int FISHEYE = 24;
    public static final int SHAKE = 25;
    public static final int INVERTED_CONTROLS = 26;
    public static final int DRUNK_SWAY = 27;
    // Hallucinations: only this player sees or hears them, nothing actually happens.
    public static final int HALLU_MOBS = 40;
    public static final int HALLU_CHAT = 41;
    public static final int HALLU_EXPLOSION = 42;
    public static final int HALLU_TREASURE = 43;
    public static final int HALLU_PAIN = 44;
    public static final int HALLU_MADNESS = 45;

    public static boolean isSound(int kind) {
        return kind > 0 && kind < 20;
    }

    public record Effect(int kind, int durationTicks, long seed) implements CustomPacketPayload {
        public static final Type<Effect> TYPE = new Type<>(UpgraderChaos.id("effect"));
        public static final StreamCodec<ByteBuf, Effect> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, Effect::kind,
                ByteBufCodecs.VAR_INT, Effect::durationTicks,
                ByteBufCodecs.VAR_LONG, Effect::seed,
                Effect::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record LostOrgans(List<String> organs) implements CustomPacketPayload {
        public static final Type<LostOrgans> TYPE = new Type<>(UpgraderChaos.id("lost_organs"));
        public static final StreamCodec<ByteBuf, LostOrgans> CODEC = StreamCodec.composite(
                ByteBufCodecs.STRING_UTF8.apply(ByteBufCodecs.list()), LostOrgans::organs,
                LostOrgans::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record Stats(Map<String, Integer> counts) implements CustomPacketPayload {
        public static final Type<Stats> TYPE = new Type<>(UpgraderChaos.id("stats"));
        public static final StreamCodec<ByteBuf, Stats> CODEC = StreamCodec.composite(
                ByteBufCodecs.map(HashMap::new, ByteBufCodecs.STRING_UTF8, ByteBufCodecs.VAR_INT), Stats::counts,
                Stats::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("3").optional();
        // The lambdas only run on a client, so the client classes are never loaded on a dedicated server.
        registrar.playToClient(Effect.TYPE, Effect.CODEC,
                (payload, context) -> context.enqueueWork(() -> ClientChaos.start(payload.kind(), payload.durationTicks(), payload.seed())));
        registrar.playToClient(LostOrgans.TYPE, LostOrgans.CODEC,
                (payload, context) -> context.enqueueWork(() -> ClientChaos.setOrgans(payload.organs())));
        registrar.playToClient(Stats.TYPE, Stats.CODEC,
                (payload, context) -> context.enqueueWork(() -> ClientChaos.setStats(payload.counts())));
    }

    public static void sendOrgans(ServerPlayer player) {
        send(player, new LostOrgans(player.getData(ru.upgraderchaos.body.Organs.LOST)));
    }

    public static void sendStats(ServerPlayer player) {
        send(player, new Stats(player.getData(ChaosAttachments.EVENT_COUNTS)));
    }

    public static void sendEffect(ServerPlayer player, int kind, int durationTicks, long seed) {
        send(player, new Effect(kind, durationTicks, seed));
    }

    /** Returns false when the player's client does not have this mod. */
    private static boolean send(ServerPlayer player, CustomPacketPayload payload) {
        // Fake players (machines from other mods) have no network connection at all.
        if (player instanceof FakePlayer || player.connection == null || !player.connection.hasChannel(payload.type())) {
            return false;
        }
        PacketDistributor.sendToPlayer(player, payload);
        return true;
    }

    private ChaosNetwork() {
    }
}
