package ru.upgraderchaos.machine;

import net.execheinz.upgrader.value.ItemValues;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import org.jetbrains.annotations.Nullable;
import ru.upgraderchaos.ChaosEvent;
import ru.upgraderchaos.ChaosEvents;
import ru.upgraderchaos.Compressor;
import ru.upgraderchaos.UpgraderChaos;

/**
 * The blue upgrader: one input slot and a "compress" button. The whole stack is squeezed into a single
 * phenomenon; nothing ever comes back out as an item.
 */
public class ChaosMenu extends AbstractContainerMenu {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU, UpgraderChaos.MOD_ID);
    public static final DeferredHolder<MenuType<?>, MenuType<ChaosMenu>> TYPE = MENUS.register("upgrader",
            () -> IMenuTypeExtension.create((id, inventory, buf) -> new ChaosMenu(id, inventory, UpgraderTier.byIndex(buf.readVarInt()))));

    public static final int BUTTON_COMPRESS = 0;
    /** Workshop buttons are BUTTON_CRAFT + recipe ordinal. */
    public static final int BUTTON_CRAFT = 100;
    public static final int SPIN_TICKS = 60;
    public static final int INPUT_X = 26;
    public static final int INPUT_Y = 30;
    public static final int INVENTORY_Y = 120;

    // Data slots are synced as shorts, so the value travels in two halves.
    private static final int SPIN_LEFT = 0;
    private static final int PENDING = 1;
    private static final int VALUE_LOW = 2;
    private static final int VALUE_HIGH = 3;
    private static final int LAST_RESULT = 4;

    private final Container input = new SimpleContainer(1) {
        @Override
        public void setChanged() {
            super.setChanged();
            ChaosMenu.this.slotsChanged(this);
        }
    };
    private final ContainerData data = new SimpleContainerData(5);
    private final Player player;
    private final UpgraderTier tier;

    public static void open(ServerPlayer player, UpgraderTier tier) {
        player.openMenu(new SimpleMenuProvider((id, inventory, p) -> new ChaosMenu(id, inventory, tier), tier.displayName()),
                buf -> buf.writeVarInt(tier.ordinal()));
    }

    public ChaosMenu(int containerId, Inventory inventory, UpgraderTier tier) {
        super(TYPE.get(), containerId);
        this.player = inventory.player;
        this.tier = tier;
        addSlot(new Slot(input, 0, INPUT_X, INPUT_Y) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return !isSpinning() && canCompress(stack);
            }

            @Override
            public boolean mayPickup(Player p) {
                return !isSpinning();
            }
        });
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, INVENTORY_Y + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, 8 + col * 18, INVENTORY_Y + 58));
        }
        addDataSlots(data);
    }

    private static boolean canCompress(ItemStack stack) {
        return !stack.isEmpty() && !ItemValues.isBlacklisted(stack.getItem())
                && !BuiltInRegistries.ITEM.getKey(stack.getItem()).getNamespace().equals(UpgraderChaos.MOD_ID);
    }

    public UpgraderTier tier() {
        return tier;
    }

    public boolean isSpinning() {
        return data.get(SPIN_LEFT) > 0;
    }

    public int spinLeft() {
        return data.get(SPIN_LEFT);
    }

    public long inputValue() {
        return ((long) (data.get(VALUE_HIGH) & 0xFFFF) << 16) | (data.get(VALUE_LOW) & 0xFFFF);
    }

    @Nullable
    public ChaosEvent lastResult() {
        int index = data.get(LAST_RESULT) - 1;
        return index >= 0 && index < ChaosEvent.values().length ? ChaosEvent.values()[index] : null;
    }

    public ItemStack inputStack() {
        return input.getItem(0);
    }

    @Override
    public boolean clickMenuButton(Player clicker, int id) {
        if (!(clicker instanceof ServerPlayer serverPlayer)) {
            return false;
        }
        if (id >= BUTTON_CRAFT && id < BUTTON_CRAFT + WorkshopRecipe.values().length) {
            WorkshopRecipe recipe = WorkshopRecipe.values()[id - BUTTON_CRAFT];
            if (recipe.availableIn(tier) && recipe.craft(serverPlayer.getInventory())) {
                serverPlayer.level().playSound(null, serverPlayer.blockPosition(), SoundEvents.SMITHING_TABLE_USE, SoundSource.PLAYERS, 0.8F, 1.0F);
                return true;
            }
            return false;
        }
        if (id != BUTTON_COMPRESS || isSpinning()) {
            return false;
        }
        ItemStack stack = input.getItem(0);
        if (!canCompress(stack)) {
            return false;
        }
        double value = ItemValues.stackValue(serverPlayer.level(), stack);
        ChaosEvent result = Compressor.pick(value, tier, serverPlayer.getRandom());
        data.set(PENDING, result.ordinal() + 1);
        data.set(SPIN_LEFT, SPIN_TICKS);
        serverPlayer.level().playSound(null, serverPlayer.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.6F, 1.6F);
        return true;
    }

    @Override
    public void broadcastChanges() {
        if (player instanceof ServerPlayer serverPlayer) {
            long value = Math.min(Integer.MAX_VALUE, Math.round(ItemValues.stackValue(serverPlayer.level(), input.getItem(0))));
            data.set(VALUE_LOW, (int) (value & 0xFFFF));
            data.set(VALUE_HIGH, (int) ((value >> 16) & 0xFFFF));
            int left = data.get(SPIN_LEFT);
            if (left > 0) {
                data.set(SPIN_LEFT, left - 1);
                if (left - 1 == 0) {
                    finish(serverPlayer);
                }
            }
        }
        super.broadcastChanges();
    }

    private void finish(ServerPlayer serverPlayer) {
        int index = data.get(PENDING) - 1;
        data.set(PENDING, 0);
        if (index < 0 || input.getItem(0).isEmpty()) {
            return;
        }
        ChaosEvent event = ChaosEvent.values()[index];
        input.setItem(0, ItemStack.EMPTY);
        input.setChanged();
        data.set(LAST_RESULT, index + 1);
        serverPlayer.level().playSound(null, serverPlayer.blockPosition(), SoundEvents.RESPAWN_ANCHOR_DEPLETE.value(), SoundSource.PLAYERS, 0.8F, 1.2F);
        ChaosEvents.trigger(serverPlayer, event);
    }

    @Override
    public void clicked(int slotId, int button, ClickType clickType, Player p) {
        if (!isSpinning()) {
            super.clicked(slotId, button, clickType, p);
        }
    }

    @Override
    public ItemStack quickMoveStack(Player p, int index) {
        if (isSpinning()) {
            return ItemStack.EMPTY;
        }
        Slot slot = slots.get(index);
        if (!slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        if (index == 0) {
            if (!moveItemStackTo(stack, 1, 37, true)) {
                return ItemStack.EMPTY;
            }
        } else if (!canCompress(stack) || !moveItemStackTo(stack, 0, 1, false)) {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.set(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return original;
    }

    @Override
    public void removed(Player p) {
        // Closing mid-spin does not save the item: the phenomenon happens right away.
        if (isSpinning() && p instanceof ServerPlayer serverPlayer) {
            data.set(SPIN_LEFT, 0);
            finish(serverPlayer);
        }
        super.removed(p);
        clearContainer(p, input);
    }

    @Override
    public boolean stillValid(Player p) {
        return p.isAlive();
    }
}
