package ru.upgraderchaos.machine;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** One of the five colored upgraders. Right-click opens the compressor and its workshop. */
public class ChaosUpgraderItem extends Item {
    private final UpgraderTier tier;

    public ChaosUpgraderItem(Properties properties, UpgraderTier tier) {
        super(properties);
        this.tier = tier;
    }

    public UpgraderTier tier() {
        return tier;
    }

    @Override
    public Component getName(ItemStack stack) {
        return tier.displayName();
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (player instanceof ServerPlayer serverPlayer) {
            ChaosMenu.open(serverPlayer, tier);
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.upgrader_chaos.upgrader.desc").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("item.upgrader_chaos.upgrader.theme", tier.theme()).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("item.upgrader_chaos.upgrader.categories", tier.categoryList()).withStyle(ChatFormatting.GRAY));
    }
}
