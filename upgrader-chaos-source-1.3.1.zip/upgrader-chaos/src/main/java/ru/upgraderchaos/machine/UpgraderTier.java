package ru.upgraderchaos.machine;

import java.util.EnumSet;
import java.util.Locale;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import ru.upgraderchaos.ChaosEvent;
import ru.upgraderchaos.ChaosEvent.Category;

/**
 * Five upgraders, green to purple. Each one produces its own categories of phenomena, from nature at green to
 * storms and mysteries at purple; inside those categories the item's value decides what is likely.
 */
public enum UpgraderTier {
    GREEN(ChatFormatting.GREEN, 0xFF2E8B3C, 0xFF7CFF8C, EnumSet.of(Category.WEATHER, Category.TIME, Category.EFFECT)),
    BLUE(ChatFormatting.BLUE, 0xFF3D7CC9, 0xFF6FB6FF, EnumSet.of(Category.SOUND, Category.VISION, Category.HALLUCINATION)),
    YELLOW(ChatFormatting.YELLOW, 0xFFB8961E, 0xFFFFE15A, EnumSet.of(Category.MOBS, Category.INVENTORY)),
    RED(ChatFormatting.RED, 0xFFB0302A, 0xFFFF6B5E, EnumSet.of(Category.BODY, Category.WORLD)),
    PURPLE(ChatFormatting.DARK_PURPLE, 0xFF7A35B8, 0xFFC77DFF, EnumSet.of(Category.STORM, Category.MYSTERY));

    public final String id = name().toLowerCase(Locale.ROOT);
    public final ChatFormatting color;
    /** Border and highlight colors of the screen. */
    public final int border;
    public final int glow;
    public final Set<Category> categories;

    UpgraderTier(ChatFormatting color, int border, int glow, Set<Category> categories) {
        this.color = color;
        this.border = border;
        this.glow = glow;
        this.categories = categories;
    }

    public boolean allows(ChaosEvent event) {
        return categories.contains(event.category);
    }

    public Component displayName() {
        return Component.translatable("item.upgrader_chaos." + id + "_upgrader").withStyle(color);
    }

    /** The theme of the upgrader: "Nature", "Mind", ... */
    public Component theme() {
        return Component.translatable("tier.upgrader_chaos." + ordinal()).withStyle(color);
    }

    /** "Weather, Time, Effects" in the categories' own colors. */
    public Component categoryList() {
        MutableComponent list = Component.empty();
        boolean first = true;
        for (Category category : categories) {
            if (!first) {
                list.append(Component.literal(", ").withStyle(ChatFormatting.GRAY));
            }
            list.append(category.displayName());
            first = false;
        }
        return list;
    }

    public static UpgraderTier byIndex(int index) {
        UpgraderTier[] tiers = values();
        return tiers[Math.floorMod(index, tiers.length)];
    }
}
