package ru.upgraderchaos.machine;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import ru.upgraderchaos.ChaosItems;
import ru.upgraderchaos.world.ChaosBlocks;

/**
 * What each upgrader's workshop can make. Upgraders (and the chaos tools) cannot be made at a crafting table:
 * every tier is built inside the tier below it, from that tier's biome resources. A workshop also offers
 * everything the weaker workshops do.
 */
public enum WorkshopRecipe {
    CHAOS_COMPASS(UpgraderTier.GREEN, () -> ChaosItems.CHAOS_COMPASS.get(), 1,
            ing(() -> Items.COMPASS, 1), ing(() -> Items.LAPIS_LAZULI, 4), ing(() -> Items.REDSTONE, 2)),
    BLUE_UPGRADER(UpgraderTier.GREEN, () -> ChaosItems.upgrader(UpgraderTier.BLUE), 1,
            ing(() -> ChaosBlocks.CHAOS_LOG.asItem(), 16), ing(() -> ChaosItems.CHAOS_SHARD.get(), 8), ing(() -> Items.LAPIS_LAZULI, 8)),
    YELLOW_UPGRADER(UpgraderTier.BLUE, () -> ChaosItems.upgrader(UpgraderTier.YELLOW), 1,
            ing(() -> ChaosItems.CHAOS_SHARD.get(), 16), ing(() -> ChaosItems.STORM_CRYSTAL.get(), 8), ing(() -> Items.GOLD_INGOT, 4)),
    INTEGRITY_AMULET(UpgraderTier.YELLOW, () -> ChaosItems.INTEGRITY_AMULET.get(), 1,
            ing(() -> ChaosItems.STORM_CRYSTAL.get(), 4), ing(() -> ChaosItems.BLOOD_RUBY.get(), 2), ing(() -> Items.GOLD_INGOT, 2)),
    RED_UPGRADER(UpgraderTier.YELLOW, () -> ChaosItems.upgrader(UpgraderTier.RED), 1,
            ing(() -> ChaosItems.STORM_CRYSTAL.get(), 12), ing(() -> ChaosItems.BLOOD_RUBY.get(), 6), ing(() -> Items.DIAMOND, 4)),
    PURPLE_UPGRADER(UpgraderTier.RED, () -> ChaosItems.upgrader(UpgraderTier.PURPLE), 1,
            ing(() -> ChaosItems.BLOOD_RUBY.get(), 12), ing(() -> ChaosItems.VOID_SHARD.get(), 6), ing(() -> Items.DIAMOND_BLOCK, 2)),
    VOID_AMULETS(UpgraderTier.PURPLE, () -> ChaosItems.INTEGRITY_AMULET.get(), 3,
            ing(() -> ChaosItems.VOID_SHARD.get(), 2), ing(() -> ChaosItems.BLOOD_RUBY.get(), 2));

    public record Ingredient(Supplier<Item> item, int count) {
    }

    private static Ingredient ing(Supplier<Item> item, int count) {
        return new Ingredient(item, count);
    }

    public final UpgraderTier tier;
    private final Supplier<Item> result;
    private final int resultCount;
    public final List<Ingredient> ingredients;

    WorkshopRecipe(UpgraderTier tier, Supplier<Item> result, int resultCount, Ingredient... ingredients) {
        this.tier = tier;
        this.result = result;
        this.resultCount = resultCount;
        this.ingredients = List.of(ingredients);
    }

    public ItemStack result() {
        return new ItemStack(result.get(), resultCount);
    }

    public boolean availableIn(UpgraderTier workshop) {
        return tier.ordinal() <= workshop.ordinal();
    }

    public static int count(Inventory inventory, Item item) {
        int total = 0;
        for (ItemStack stack : inventory.items) {
            if (stack.is(item)) {
                total += stack.getCount();
            }
        }
        return total;
    }

    public boolean canCraft(Inventory inventory) {
        for (Ingredient ingredient : ingredients) {
            if (count(inventory, ingredient.item().get()) < ingredient.count()) {
                return false;
            }
        }
        return true;
    }

    /** Takes the ingredients from the main inventory and hands out the result. Returns false if something is missing. */
    public boolean craft(Inventory inventory) {
        if (!canCraft(inventory)) {
            return false;
        }
        for (Ingredient ingredient : ingredients) {
            int left = ingredient.count();
            for (ItemStack stack : inventory.items) {
                if (left > 0 && stack.is(ingredient.item().get())) {
                    int taken = Math.min(left, stack.getCount());
                    stack.shrink(taken);
                    left -= taken;
                }
            }
        }
        ItemStack out = result();
        if (!inventory.add(out)) {
            inventory.player.drop(out, false);
        }
        inventory.setChanged();
        return true;
    }
}
