package ru.upgraderchaos;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** A catalog entry for the upgrader. Players never get these; winning one fires the event instead. */
public class ChaosEventItem extends Item {
    private final ChaosEvent event;

    public ChaosEventItem(Properties properties, ChaosEvent event) {
        super(properties);
        this.event = event;
    }

    public ChaosEvent event() {
        return event;
    }

    @Override
    public Component getName(ItemStack stack) {
        return Component.translatable(getDescriptionId(stack)).withStyle(event.category.color);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable(event.translationKey() + ".desc").withStyle(ChatFormatting.GRAY));
        if (event.needsPmWeather() && !UpgraderChaos.hasPmWeather()) {
            tooltip.add(Component.translatable("tooltip.upgrader_chaos.needs_pmweather").withStyle(ChatFormatting.DARK_RED));
        }
        tooltip.add(Component.translatable("tooltip.upgrader_chaos.creative_use").withStyle(ChatFormatting.DARK_GRAY));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!player.isCreative()) {
            return InteractionResultHolder.pass(stack);
        }
        if (player instanceof ServerPlayer serverPlayer) {
            ChaosEvents.trigger(serverPlayer, event);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
