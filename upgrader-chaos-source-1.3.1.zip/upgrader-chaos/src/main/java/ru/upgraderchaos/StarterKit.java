package ru.upgraderchaos;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import ru.upgraderchaos.machine.UpgraderTier;

/** Every player gets the green upgrader the first time they join a world. The index needs no item (key I). */
@EventBusSubscriber(modid = UpgraderChaos.MOD_ID)
public final class StarterKit {
    private static final String GIVEN_GREEN = UpgraderChaos.MOD_ID + ":starter_kit_green";

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        // The persisted tag survives death, so the upgrader is handed out only once per world.
        CompoundTag persisted = player.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        if (persisted.getBoolean(GIVEN_GREEN)) {
            return;
        }
        ItemStack stack = new ItemStack(ChaosItems.upgrader(UpgraderTier.GREEN));
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
        persisted.putBoolean(GIVEN_GREEN, true);
        player.getPersistentData().put(Player.PERSISTED_NBT_TAG, persisted);
    }

    private StarterKit() {
    }
}
