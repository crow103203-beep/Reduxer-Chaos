package ru.upgraderchaos.dev;

import java.lang.reflect.Field;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import ru.upgraderchaos.ChaosAttachments;
import ru.upgraderchaos.ChaosEvent;
import ru.upgraderchaos.ChaosEvents;
import ru.upgraderchaos.ChaosItems;
import ru.upgraderchaos.UpgraderChaos;
import ru.upgraderchaos.client.ChaosScreen;
import ru.upgraderchaos.client.ClientScreens;
import ru.upgraderchaos.compat.PmWeather;
import ru.upgraderchaos.machine.ChaosMenu;
import ru.upgraderchaos.machine.UpgraderTier;
import ru.upgraderchaos.network.ChaosNetwork;
import ru.upgraderchaos.world.ChaosBiome;
import ru.upgraderchaos.world.WorldClock;

/** Dev only: -Dupgrader_chaos.clienttest=true walks through the upgrader, workshop, index and biome, taking screenshots. */
@EventBusSubscriber(modid = UpgraderChaos.MOD_ID, value = Dist.CLIENT)
public final class ClientSelfTest {
    private static int ticks = -1;

    private static boolean enabled() {
        return Boolean.getBoolean("upgrader_chaos.clienttest");
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!enabled() || !(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        PmWeather.clearAll(player.serverLevel());
        // The test world is full of leftovers from the server test (TNT, bosses); don't die in it.
        player.getAbilities().invulnerable = true;
        player.onUpdateAbilities();
        player.setHealth(player.getMaxHealth());
        player.setData(ChaosAttachments.EVENT_COUNTS, Map.of("rain", 3, "tornado_weak", 1, "fog", 2));
        ChaosNetwork.sendStats(player);
        var found = player.serverLevel().findClosestBiome3d(b -> b.is(ChaosBiome.CHAOS_LANDS), player.blockPosition(), 3200, 32, 64);
        if (found != null) {
            BlockPos at = found.getFirst();
            player.serverLevel().getChunk(at.getX() >> 4, at.getZ() >> 4);
            int y = player.serverLevel().getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, at.getX(), at.getZ());
            player.teleportTo(player.serverLevel(), at.getX() + 0.5, y, at.getZ() + 0.5, 0F, 10F);
        }
        player.getInventory().add(new ItemStack(ChaosItems.STORM_CRYSTAL.get(), 12));
        player.getInventory().add(new ItemStack(ChaosItems.BLOOD_RUBY.get(), 3));
        player.getInventory().add(new ItemStack(Items.DIAMOND, 4));
        WorldClock.later(60, () -> {
            ChaosMenu.open(player, UpgraderTier.YELLOW);
            if (player.containerMenu instanceof ChaosMenu menu) {
                menu.getSlot(0).set(new ItemStack(Items.GOLD_INGOT, 12));
            }
        });
    }

    private static ServerPlayer serverPlayer(Minecraft mc) {
        return mc.getSingleplayerServer().getPlayerList().getPlayer(mc.player.getUUID());
    }

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (!enabled() || mc.level == null || mc.player == null) {
            return;
        }
        // Start counting once the server has opened the upgrader for us.
        if (ticks < 0) {
            if (mc.screen instanceof ChaosScreen) {
                ticks = 80;
            }
            return;
        }
        ticks++;
        try {
            switch (ticks) {
                case 100 -> shot(mc, "1_chances.png");
                case 102 -> {
                    Field workshop = ChaosScreen.class.getDeclaredField("workshop");
                    workshop.setAccessible(true);
                    workshop.set(mc.screen, true);
                }
                case 110 -> shot(mc, "2_workshop.png");
                case 115 -> {
                    ServerPlayer player = serverPlayer(mc);
                    player.server.execute(player::closeContainer);
                }
                case 125 -> ClientScreens.openIndex();
                case 140 -> shot(mc, "3_index.png");
                case 145 -> {
                    mc.setScreen(null);
                    ServerPlayer player = serverPlayer(mc);
                    player.server.execute(() -> {
                        ChaosEvents.trigger(player, ChaosEvent.FAKE_MOBS);
                        ChaosEvents.trigger(player, ChaosEvent.FAKE_CHAT);
                    });
                }
                case 260 -> shot(mc, "4_biome_hallucinations.png");
                case 280 -> mc.stop();
                default -> {
                }
            }
        } catch (Exception e) {
            UpgraderChaos.LOGGER.error("[clienttest] step {} failed", ticks, e);
        }
    }

    private static void shot(Minecraft mc, String name) {
        UpgraderChaos.LOGGER.info("[clienttest] screenshot {} screen={}", name, mc.screen);
        Screenshot.grab(mc.gameDirectory, name, mc.getMainRenderTarget(), message -> {
        });
    }

    private ClientSelfTest() {
    }
}
