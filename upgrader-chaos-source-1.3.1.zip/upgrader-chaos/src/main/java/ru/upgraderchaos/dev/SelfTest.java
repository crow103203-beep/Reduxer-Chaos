package ru.upgraderchaos.dev;

import dev.protomanly.pmweather.event.GameBusEvents;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.util.FakePlayerFactory;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import ru.upgraderchaos.ChaosEvent;
import ru.upgraderchaos.ChaosEvents;
import ru.upgraderchaos.Compressor;
import ru.upgraderchaos.UpgraderChaos;
import ru.upgraderchaos.body.Organs;
import ru.upgraderchaos.machine.ChaosMenu;
import ru.upgraderchaos.machine.UpgraderTier;
import ru.upgraderchaos.machine.WorkshopRecipe;
import ru.upgraderchaos.ChaosItems;
import ru.upgraderchaos.world.ChaosBiome;
import ru.upgraderchaos.world.ChaosBlocks;
import ru.upgraderchaos.world.WorldClock;

/** Dev only (left out of the jar): -Dupgrader_chaos.selftest=true runs every event on a fake player and stops the server. */
@EventBusSubscriber(modid = UpgraderChaos.MOD_ID)
public final class SelfTest {

    @SubscribeEvent
    public static void onStarted(ServerStartedEvent event) {
        if (!Boolean.getBoolean("upgrader_chaos.selftest")) {
            return;
        }
        ServerLevel level = event.getServer().overworld();
        ServerPlayer player = FakePlayerFactory.getMinecraft(level);
        player.moveTo(0.5, level.getHeight(Heightmap.Types.MOTION_BLOCKING, 0, 0), 0.5);
        int failures = 0;

        // How the compressor spreads results for cheap and expensive items.
        RandomSource random = RandomSource.create(1);
        for (double value : new double[]{1, 40, 400, 6400, 25600}) {
            Map<ChaosEvent, Integer> counts = new EnumMap<>(ChaosEvent.class);
            for (int i = 0; i < 2000; i++) {
                counts.merge(Compressor.pick(value, UpgraderTier.PURPLE, random), 1, Integer::sum);
            }
            List<String> top = counts.entrySet().stream().sorted((a, b) -> b.getValue() - a.getValue()).limit(5)
                    .map(e -> e.getKey().id + "=" + e.getValue()).toList();
            log("value " + value + " -> " + top);
        }

        for (ChaosEvent chaos : ChaosEvent.values()) {
            try {
                ChaosEvents.trigger(player, chaos);
                log("OK " + chaos.id);
            } catch (Throwable t) {
                failures++;
                UpgraderChaos.LOGGER.error("[selftest] FAIL " + chaos.id, t);
            }
        }
        log("organs lost after run: " + Organs.lost(player));
        List<Mob> mobs = level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(64));
        log("mobs nearby=" + mobs.size() + ": " + mobs.stream().map(m -> BuiltInRegistries.ENTITY_TYPE.getKey(m.getType()).getPath()).distinct().toList());
        if (UpgraderChaos.hasPmWeather()) {
            log("pmweather storms: " + GameBusEvents.MANAGERS.get(level.dimension()).getStorms().size());
        }

        // The blue upgrader: put diamonds in, press the button, wait for the spin.
        ChaosMenu menu = new ChaosMenu(1, player.getInventory(), UpgraderTier.YELLOW);
        menu.getSlot(0).set(new ItemStack(Items.DIAMOND, 16));
        boolean started = menu.clickMenuButton(player, ChaosMenu.BUTTON_COMPRESS);
        for (int t = 0; t < 200 && menu.isSpinning(); t++) {
            menu.broadcastChanges();
        }
        log("compress started=" + started + " consumed=" + menu.inputStack().isEmpty() + " result=" + menu.lastResult());
        if (!started || !menu.inputStack().isEmpty() || menu.lastResult() == null) {
            failures++;
        }
        menu.getSlot(0).set(new ItemStack(Items.DIRT, 1));
        menu.clickMenuButton(player, ChaosMenu.BUTTON_COMPRESS);
        for (int t = 0; t < 200 && menu.isSpinning(); t++) {
            menu.broadcastChanges();
        }
        log("dirt -> " + menu.lastResult());

        // Every tier only produces events inside its window.
        for (UpgraderTier tier : UpgraderTier.values()) {
            double[] chances = Compressor.chances(1000, tier);
            long possible = java.util.Arrays.stream(chances).filter(c -> c > 0).count();
            ChaosEvent top = ChaosEvent.values()[0];
            for (ChaosEvent e : ChaosEvent.values()) {
                if (chances[e.ordinal()] > chances[top.ordinal()]) {
                    top = e;
                }
            }
            log("tier " + tier.id + ": possible=" + possible + " top@1000=" + top.id + String.format(" %.1f%%", chances[top.ordinal()] * 100));
            boolean ownCategoriesOnly = true;
            for (ChaosEvent e : ChaosEvent.values()) {
                if (chances[e.ordinal()] > 0 && !tier.categories.contains(e.category)) {
                    ownCategoriesOnly = false;
                }
            }
            log("tier " + tier.id + " categories=" + tier.categories + " ownCategoriesOnly=" + ownCategoriesOnly);
            if (possible == 0 || !ownCategoriesOnly) {
                failures++;
            }
        }

        // Workshop: the green upgrader builds the blue one, but not the purple one.
        ChaosMenu green = new ChaosMenu(2, player.getInventory(), UpgraderTier.GREEN);
        player.getInventory().clearContent();
        player.getInventory().add(new ItemStack(ChaosBlocks.CHAOS_LOG.get(), 16));
        player.getInventory().add(new ItemStack(ChaosItems.CHAOS_SHARD.get(), 8));
        player.getInventory().add(new ItemStack(Items.LAPIS_LAZULI, 8));
        boolean craftedBlue = green.clickMenuButton(player, ChaosMenu.BUTTON_CRAFT + WorkshopRecipe.BLUE_UPGRADER.ordinal());
        boolean hasBlue = player.getInventory().contains(new ItemStack(ChaosItems.upgrader(UpgraderTier.BLUE)));
        boolean purpleBlocked = !green.clickMenuButton(player, ChaosMenu.BUTTON_CRAFT + WorkshopRecipe.PURPLE_UPGRADER.ordinal());
        log("workshop craftedBlue=" + craftedBlue + " hasBlue=" + hasBlue + " logsLeft=" + WorkshopRecipe.count(player.getInventory(), ChaosBlocks.CHAOS_LOG.asItem())
                + " purpleBlocked=" + purpleBlocked);
        if (!craftedBlue || !hasBlue || !purpleBlocked) {
            failures++;
        }

        // The Chaos Lands exist and carry the ores.
        var found = level.findClosestBiome3d(b -> b.is(ChaosBiome.CHAOS_LANDS), new net.minecraft.core.BlockPos(0, 64, 0), 6400, 32, 64);
        if (found == null) {
            failures++;
            log("chaos lands: NOT FOUND");
        } else {
            net.minecraft.core.BlockPos at = found.getFirst();
            Map<String, Integer> ores = new java.util.TreeMap<>();
            int logs = 0;
            for (int cx = -2; cx <= 2; cx++) {
                for (int cz = -2; cz <= 2; cz++) {
                    var chunk = level.getChunk((at.getX() >> 4) + cx, (at.getZ() >> 4) + cz);
                    for (net.minecraft.core.BlockPos p : net.minecraft.core.BlockPos.betweenClosed(chunk.getPos().getMinBlockX(), -64, chunk.getPos().getMinBlockZ(),
                            chunk.getPos().getMaxBlockX(), 200, chunk.getPos().getMaxBlockZ())) {
                        var state = chunk.getBlockState(p);
                        String key = BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString();
                        if (key.startsWith("upgrader_chaos:") && key.endsWith("_ore")) {
                            ores.merge(key, 1, Integer::sum);
                        } else if (key.equals("upgrader_chaos:chaos_log")) {
                            logs++;
                        }
                    }
                }
            }
            log("chaos lands at " + at + " (5x5 chunks): logs=" + logs + " ores=" + ores);
        }

        final int total = failures;
        WorldClock.later(100, () -> {
            event.getServer().tickRateManager().setTickRate(20F);
            log("RESULT failures=" + total);
            event.getServer().halt(false);
        });
    }

    private static void log(String message) {
        UpgraderChaos.LOGGER.info("[selftest] " + message);
    }

    private SelfTest() {
    }
}
