package ru.upgraderchaos;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import ru.upgraderchaos.machine.ChaosUpgraderItem;
import ru.upgraderchaos.machine.UpgraderTier;
import ru.upgraderchaos.world.ChaosBlocks;
import ru.upgraderchaos.world.ChaosCompassItem;

public final class ChaosItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(UpgraderChaos.MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, UpgraderChaos.MOD_ID);

    private static final Map<UpgraderTier, DeferredItem<ChaosUpgraderItem>> UPGRADERS = new EnumMap<>(UpgraderTier.class);

    static {
        Rarity[] rarities = {Rarity.COMMON, Rarity.UNCOMMON, Rarity.UNCOMMON, Rarity.RARE, Rarity.EPIC};
        for (UpgraderTier tier : UpgraderTier.values()) {
            UPGRADERS.put(tier, ITEMS.registerItem(tier.id + "_upgrader", props -> new ChaosUpgraderItem(props, tier),
                    new Item.Properties().stacksTo(1).rarity(rarities[tier.ordinal()])));
        }
    }

    // Upgrader materials, mined in the Chaos Lands (wood for green is the block item of the chaos log).
    public static final DeferredItem<DescribedItem> CHAOS_SHARD = ITEMS.registerItem("chaos_shard", DescribedItem::new, new Item.Properties());
    public static final DeferredItem<DescribedItem> STORM_CRYSTAL = ITEMS.registerItem("storm_crystal", DescribedItem::new, new Item.Properties());
    public static final DeferredItem<DescribedItem> BLOOD_RUBY = ITEMS.registerItem("blood_ruby", DescribedItem::new,
            new Item.Properties().rarity(Rarity.UNCOMMON));
    public static final DeferredItem<DescribedItem> VOID_SHARD = ITEMS.registerItem("void_shard", DescribedItem::new,
            new Item.Properties().rarity(Rarity.RARE));

    public static final DeferredItem<ChaosCompassItem> CHAOS_COMPASS = ITEMS.registerItem("chaos_compass", ChaosCompassItem::new,
            new Item.Properties().stacksTo(1));
    /** Kept in the inventory, it takes the next organ loss and breaks. */
    public static final DeferredItem<DescribedItem> INTEGRITY_AMULET = ITEMS.registerItem("integrity_amulet", DescribedItem::new,
            new Item.Properties().stacksTo(4).rarity(Rarity.RARE));

    // Icons for the screens. Players never get these in survival; in creative right-click fires the event.
    private static final Map<ChaosEvent, DeferredItem<ChaosEventItem>> BY_EVENT = new EnumMap<>(ChaosEvent.class);

    static {
        for (ChaosEvent event : ChaosEvent.values()) {
            Rarity rarity = event.defaultValue >= 2000 ? Rarity.EPIC : event.defaultValue >= 500 ? Rarity.RARE : Rarity.UNCOMMON;
            BY_EVENT.put(event, ITEMS.registerItem(event.id, props -> new ChaosEventItem(props, event), new Item.Properties().stacksTo(1).rarity(rarity)));
        }
    }

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("events", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.upgrader_chaos.events"))
            .icon(() -> new ItemStack(upgrader(UpgraderTier.PURPLE)))
            .displayItems((params, output) -> {
                for (UpgraderTier tier : UpgraderTier.values()) {
                    output.accept(upgrader(tier));
                }
                output.accept(CHAOS_COMPASS.get());
                output.accept(INTEGRITY_AMULET.get());
                output.accept(ChaosBlocks.CHAOS_LOG.get());
                output.accept(ChaosBlocks.CHAOS_PLANKS.get());
                output.accept(ChaosBlocks.CHAOS_LEAVES.get());
                output.accept(ChaosBlocks.CHAOS_ORE.get());
                output.accept(ChaosBlocks.STORM_CRYSTAL_ORE.get());
                output.accept(ChaosBlocks.BLOOD_RUBY_ORE.get());
                output.accept(ChaosBlocks.VOID_ORE.get());
                output.accept(CHAOS_SHARD.get());
                output.accept(STORM_CRYSTAL.get());
                output.accept(BLOOD_RUBY.get());
                output.accept(VOID_SHARD.get());
                for (ChaosEvent event : ChaosEvent.values()) {
                    output.accept(item(event));
                }
            })
            .build());

    public static Item item(ChaosEvent event) {
        return BY_EVENT.get(event).get();
    }

    public static ChaosUpgraderItem upgrader(UpgraderTier tier) {
        return UPGRADERS.get(tier).get();
    }

    private ChaosItems() {
    }
}
