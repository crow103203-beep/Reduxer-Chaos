package ru.upgraderchaos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Bee;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import ru.upgraderchaos.body.Organs;
import ru.upgraderchaos.compat.PmWeather;
import ru.upgraderchaos.network.ChaosNetwork;
import ru.upgraderchaos.world.MobChaos;
import ru.upgraderchaos.world.TimedModifiers;
import ru.upgraderchaos.world.WorldClock;

/** The second batch of phenomena. Same rules as {@link ChaosEvents}: server side, nothing is ever given as an item. */
final class MoreEvents {
    private static final int MINUTE = 1200;

    static void run(ServerPlayer player, ChaosEvent event, boolean quiet, String flavor, int duration) {
        ServerLevel level = player.serverLevel();
        RandomSource random = player.getRandom();

        switch (event) {
            case METEOR_SHOWER -> {
                for (int i = 0; i < 10; i++) {
                    WorldClock.later(10 + i * 12, () -> meteor(player));
                }
                ChaosEvents.result(player, quiet, flavor);
            }
            case ARROW_RAIN -> {
                for (int i = 0; i < 6; i++) {
                    WorldClock.later(5 + i * 10, () -> arrows(player, 8));
                }
                ChaosEvents.result(player, quiet, flavor);
            }
            case TNT_RAIN -> {
                for (int i = 0; i < 6; i++) {
                    Vec3 ground = ChaosEvents.groundNear(player, 6 + random.nextInt(14));
                    PrimedTnt tnt = new PrimedTnt(level, ground.x, ground.y + 25, ground.z, null);
                    tnt.setFuse(70 + random.nextInt(30));
                    level.addFreshEntity(tnt);
                }
                ChaosEvents.result(player, quiet, flavor);
            }
            case SHEEP_RAIN -> {
                for (int i = 0; i < 12; i++) {
                    Vec3 ground = ChaosEvents.groundNear(player, 2 + random.nextInt(10));
                    Sheep sheep = EntityType.SHEEP.create(level);
                    if (sheep != null) {
                        sheep.moveTo(ground.x, ground.y + 20 + random.nextInt(10), ground.z, random.nextFloat() * 360F, 0F);
                        sheep.setColor(DyeColor.byId(random.nextInt(16)));
                        sheep.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 600));
                        level.addFreshEntity(sheep);
                    }
                }
                ChaosEvents.result(player, quiet, flavor);
            }
            case SNOWSTORM -> {
                snowAround(level, player.blockPosition(), 10, random);
                level.setWeatherParameters(0, 6000, true, false);
                player.setTicksFrozen(player.getTicksRequiredToFreeze() + 200);
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 600, 1));
                player.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 600));
                ChaosEvents.result(player, quiet, flavor);
            }
            case TORNADO_OUTBREAK, TORNADO_OVERHEAD -> {
                boolean ok = UpgraderChaos.hasPmWeather();
                if (ok && event == ChaosEvent.TORNADO_OUTBREAK) {
                    for (int i = 0; i < 3; i++) {
                        ok &= PmWeather.tornado(player, 80 + random.nextInt(40), 15 + random.nextInt(25), 150 + i * 80);
                    }
                } else if (ok) {
                    ok = PmWeather.tornado(player, 70 + random.nextInt(25), 10 + random.nextInt(12), 0);
                }
                if (ok) {
                    ChaosEvents.result(player, quiet, flavor);
                } else {
                    level.setWeatherParameters(0, 6000, true, true);
                    ChaosEvents.lightningBarrage(player, 8);
                    ChaosEvents.result(player, quiet, "result.upgrader_chaos.no_pmweather");
                }
            }
            case LIGHTNING_CAGE -> {
                for (int ring = 0; ring < 2; ring++) {
                    WorldClock.later(1 + ring * 40, () -> lightningRing(player, 4));
                }
                ChaosEvents.result(player, quiet, flavor);
            }
            case INSTANT_DAWN -> {
                ServerLevel overworld = player.server.overworld();
                long day = overworld.getDayTime();
                overworld.setDayTime(day - Math.floorMod(day, 24000L) + 24000L);
                ChaosEvents.result(player, quiet, flavor);
            }
            case ETERNAL_DAY -> {
                WorldClock.startEternalDay(player.server, duration);
                ChaosEvents.result(player, quiet, flavor, duration / 20);
            }
            case SLOW_MOTION, FAST_FORWARD -> {
                float rate = event == ChaosEvent.SLOW_MOTION ? 8F : 40F;
                player.server.tickRateManager().setTickRate(rate);
                // 30 real seconds, counted in the changed ticks.
                WorldClock.later((int) (rate * 30), () -> player.server.tickRateManager().setTickRate(20F));
                ChaosEvents.result(player, quiet, flavor, 30);
            }
            case DOUBLE_SURGERY -> {
                ChaosEvents.organLoss(player, quiet);
                ChaosEvents.organLoss(player, quiet);
            }
            case FULL_RESTORE -> {
                Organs.restoreAll(player);
                player.setHealth(player.getMaxHealth());
                player.removeAllEffects();
                player.sendSystemMessage(Component.translatable("result.upgrader_chaos.full_restore").withStyle(ChatFormatting.GREEN));
            }
            case BLEEDING -> {
                for (int i = 0; i < 10; i++) {
                    WorldClock.later(20 + i * 60, () -> bleed(player));
                }
                ChaosEvents.result(player, quiet, flavor);
            }
            case AMNESIA -> {
                int lost = (player.experienceLevel + 1) / 2;
                player.giveExperienceLevels(-lost);
                player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200));
                ChaosEvents.result(player, quiet, flavor, lost);
            }
            case HICCUPS -> {
                for (int i = 0; i < 12; i++) {
                    WorldClock.later(20 + i * 100 + random.nextInt(40), () -> hiccup(player));
                }
                ChaosEvents.result(player, quiet, flavor);
            }
            case DRUNK -> {
                player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, MINUTE));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, MINUTE));
                ChaosNetwork.sendEffect(player, ChaosNetwork.DRUNK_SWAY, MINUTE, random.nextLong());
                ChaosEvents.result(player, quiet, flavor);
            }
            case INVERTED_CONTROLS -> {
                ChaosNetwork.sendEffect(player, ChaosNetwork.INVERTED_CONTROLS, MINUTE, random.nextLong());
                ChaosEvents.result(player, quiet, flavor, MINUTE / 20);
            }
            case ICE_AGE -> {
                int frozen = freezeWater(level, player.blockPosition(), 14);
                snowAround(level, player.blockPosition(), 12, random);
                player.setTicksFrozen(player.getTicksRequiredToFreeze() + 200);
                ChaosEvents.result(player, quiet, flavor, frozen);
            }
            case COBWEB_TRAP -> {
                List<BlockPos> placed = new ArrayList<>();
                BlockPos feet = player.blockPosition();
                for (BlockPos pos : BlockPos.betweenClosed(feet.offset(-2, 0, -2), feet.offset(2, 2, 2))) {
                    if (level.isEmptyBlock(pos) && random.nextFloat() < 0.7F) {
                        level.setBlockAndUpdate(pos, Blocks.COBWEB.defaultBlockState());
                        placed.add(pos.immutable());
                    }
                }
                cleanupLater(level, placed, Blocks.COBWEB.defaultBlockState(), 600);
                ChaosEvents.result(player, quiet, flavor);
            }
            case GLASS_CAGE -> {
                List<BlockPos> placed = new ArrayList<>();
                BlockPos feet = player.blockPosition();
                for (BlockPos pos : BlockPos.betweenClosed(feet.offset(-2, -1, -2), feet.offset(2, 3, 2))) {
                    int dx = Math.abs(pos.getX() - feet.getX());
                    int dz = Math.abs(pos.getZ() - feet.getZ());
                    int dy = pos.getY() - feet.getY();
                    boolean shell = dx == 2 || dz == 2 || dy == 3 || dy == -1;
                    if (shell && level.isEmptyBlock(pos)) {
                        level.setBlockAndUpdate(pos, Blocks.GLASS.defaultBlockState());
                        placed.add(pos.immutable());
                    }
                }
                cleanupLater(level, placed, Blocks.GLASS.defaultBlockState(), 600);
                ChaosEvents.result(player, quiet, flavor);
            }
            case SINKHOLE -> {
                BlockPos feet = player.blockPosition();
                for (BlockPos pos : BlockPos.betweenClosed(feet.offset(-1, -6, -1), feet.offset(1, -1, 1))) {
                    BlockState state = level.getBlockState(pos);
                    if (!state.isAir() && state.getDestroySpeed(level, pos) >= 0 && !state.hasBlockEntity()) {
                        level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
                    }
                }
                ChaosEvents.result(player, quiet, flavor);
            }
            case LAUNCH -> {
                player.setDeltaMovement(player.getDeltaMovement().x, 2.6, player.getDeltaMovement().z);
                player.hurtMarked = true;
                WorldClock.later(30, () -> player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 300)));
                ChaosEvents.result(player, quiet, flavor);
            }
            case RANDOM_TELEPORT -> {
                if (teleportFar(player, random)) {
                    ChaosEvents.result(player, quiet, flavor, player.getBlockX(), player.getBlockZ());
                }
            }
            case EXPLOSION -> {
                Vec3 pos = ChaosEvents.groundNear(player, 7 + random.nextInt(4));
                level.explode(null, pos.x, pos.y, pos.z, 3.0F, Level.ExplosionInteraction.MOB);
                ChaosEvents.result(player, quiet, flavor);
            }
            case EARTHQUAKE -> {
                for (ServerPlayer other : level.players()) {
                    if (other.distanceToSqr(player) < 96 * 96) {
                        ChaosNetwork.sendEffect(other, ChaosNetwork.SHAKE, 400, random.nextLong());
                    }
                }
                for (int i = 0; i < 10; i++) {
                    WorldClock.later(10 + i * 40, () -> quake(player));
                }
                ChaosEvents.result(player, quiet, flavor);
            }
            case ZOMBIE_HORDE -> ChaosEvents.result(player, quiet, flavor, MobChaos.spawnMany(player, EntityType.ZOMBIE, 10, 8, 18).size());
            case PHANTOM_SQUAD -> {
                List<Entity> phantoms = MobChaos.spawnMany(player, EntityType.PHANTOM, 4, 4, 10);
                for (Entity phantom : phantoms) {
                    phantom.setPos(phantom.getX(), phantom.getY() + 12, phantom.getZ());
                }
                ChaosEvents.result(player, quiet, flavor, phantoms.size());
            }
            case BEE_SWARM -> {
                List<Entity> bees = MobChaos.spawnMany(player, EntityType.BEE, 6, 3, 6);
                for (Entity entity : bees) {
                    if (entity instanceof Bee bee) {
                        bee.setRemainingPersistentAngerTime(600);
                        bee.setPersistentAngerTarget(player.getUUID());
                        bee.setTarget(player);
                    }
                }
                ChaosEvents.result(player, quiet, flavor, bees.size());
            }
            case PILLAGER_PATROL -> {
                int count = MobChaos.spawnMany(player, EntityType.PILLAGER, 3, 12, 20).size()
                        + MobChaos.spawnMany(player, EntityType.VINDICATOR, 1, 12, 20).size();
                ChaosEvents.result(player, quiet, flavor, count);
            }
            case PET -> {
                EntityType<?> type = switch (random.nextInt(3)) {
                    case 0 -> EntityType.WOLF;
                    case 1 -> EntityType.CAT;
                    default -> EntityType.PARROT;
                };
                for (Entity entity : MobChaos.spawnMany(player, type, 1, 1, 3)) {
                    if (entity instanceof TamableAnimal pet) {
                        pet.tame(player);
                        ChaosEvents.result(player, quiet, flavor, pet.getDisplayName());
                    }
                }
            }
            case MOBS_GLOW -> {
                List<Mob> mobs = MobChaos.nearby(player);
                for (Mob mob : mobs) {
                    mob.addEffect(new MobEffectInstance(MobEffects.GLOWING, duration));
                }
                ChaosEvents.result(player, quiet, flavor, mobs.size());
            }
            case SOUND_ECHO, SOUND_GHOSTS, SOUND_BROKEN_RADIO -> {
                int kind = event == ChaosEvent.SOUND_ECHO ? ChaosNetwork.SOUND_ECHO
                        : event == ChaosEvent.SOUND_GHOSTS ? ChaosNetwork.SOUND_GHOSTS : ChaosNetwork.SOUND_BROKEN_RADIO;
                ChaosEvents.worldEffect(level, kind, duration, random.nextLong());
                ChaosEvents.result(player, quiet, flavor, duration / 20);
            }
            case FOG -> {
                ChaosEvents.worldEffect(level, ChaosNetwork.FOG, duration, random.nextLong());
                ChaosEvents.result(player, quiet, flavor, duration / 20);
            }
            case BLOOD_MOON -> {
                WorldClock.startEternalNight(player.server, duration);
                ChaosEvents.worldEffect(level, ChaosNetwork.BLOOD_MOON, duration, random.nextLong());
                int waves = Math.max(1, duration / 1200);
                for (int i = 0; i < waves; i++) {
                    WorldClock.later(100 + i * 1200, () -> {
                        if (player.isAlive() && !player.hasDisconnected()) {
                            MobChaos.invasion(player, 4);
                        }
                    });
                }
                ChaosEvents.result(player, quiet, flavor, duration / 20);
            }
            case UPSIDE_DOWN, CAROUSEL, FISHEYE -> {
                int kind = event == ChaosEvent.UPSIDE_DOWN ? ChaosNetwork.UPSIDE_DOWN
                        : event == ChaosEvent.CAROUSEL ? ChaosNetwork.CAROUSEL : ChaosNetwork.FISHEYE;
                int ticks = event == ChaosEvent.CAROUSEL ? 600 : MINUTE;
                ChaosNetwork.sendEffect(player, kind, ticks, random.nextLong());
                ChaosEvents.result(player, quiet, flavor, ticks / 20);
            }
            case SUPER_JUMP -> {
                player.addEffect(new MobEffectInstance(MobEffects.JUMP, MINUTE, 4));
                timed(player, Attributes.SAFE_FALL_DISTANCE, "safe_fall", 12.0, AttributeModifier.Operation.ADD_VALUE, MINUTE);
                ChaosEvents.result(player, quiet, flavor);
            }
            case SPEED_DEMON -> {
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, MINUTE, 4));
                player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, MINUTE, 2));
                ChaosEvents.result(player, quiet, flavor);
            }
            case LOW_GRAVITY, HEAVY_GRAVITY -> {
                boolean low = event == ChaosEvent.LOW_GRAVITY;
                List<LivingEntity> affected = new ArrayList<>(MobChaos.nearby(player));
                affected.add(player);
                for (LivingEntity entity : affected) {
                    timed(entity, Attributes.GRAVITY, "gravity", low ? -0.8 : 1.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL, MINUTE);
                    timed(entity, Attributes.FALL_DAMAGE_MULTIPLIER, "gravity_fall", low ? -0.9 : 0.5, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL, MINUTE);
                }
                ChaosEvents.result(player, quiet, flavor, MINUTE / 20);
            }
            case FEAST -> {
                player.getFoodData().setFoodLevel(20);
                player.getFoodData().setSaturation(20F);
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
                ChaosEvents.result(player, quiet, flavor);
            }
            case INVENTORY_SHUFFLE -> {
                List<ItemStack> stacks = new ArrayList<>(player.getInventory().items);
                Collections.shuffle(stacks, new Random(random.nextLong()));
                for (int i = 0; i < stacks.size(); i++) {
                    player.getInventory().items.set(i, stacks.get(i));
                }
                player.getInventory().setChanged();
                ChaosEvents.result(player, quiet, flavor);
            }
            case RUST -> {
                int rusted = 0;
                for (List<ItemStack> list : List.of(player.getInventory().items, player.getInventory().armor, player.getInventory().offhand)) {
                    for (ItemStack stack : list) {
                        if (stack.isDamageableItem()) {
                            int max = stack.getMaxDamage();
                            stack.setDamageValue(Math.min(max - 1, stack.getDamageValue() + max / 4));
                            rusted++;
                        }
                    }
                }
                ChaosEvents.result(player, quiet, flavor, rusted);
            }
            case FAKE_MOBS, FAKE_CHAT, FAKE_EXPLOSION, FAKE_TREASURE, PHANTOM_PAIN, MADNESS -> {
                int kind = switch (event) {
                    case FAKE_MOBS -> ChaosNetwork.HALLU_MOBS;
                    case FAKE_CHAT -> ChaosNetwork.HALLU_CHAT;
                    case FAKE_EXPLOSION -> ChaosNetwork.HALLU_EXPLOSION;
                    case FAKE_TREASURE -> ChaosNetwork.HALLU_TREASURE;
                    case PHANTOM_PAIN -> ChaosNetwork.HALLU_PAIN;
                    default -> ChaosNetwork.HALLU_MADNESS;
                };
                ChaosNetwork.sendEffect(player, kind, event == ChaosEvent.MADNESS ? 3 * MINUTE : MINUTE, random.nextLong());
                // Hallucinations work best unannounced; the flavor line stays vague on purpose.
                ChaosEvents.result(player, quiet, flavor);
            }
            default -> UpgraderChaos.LOGGER.warn("No handler for chaos event {}", event.id);
        }
    }

    private static void timed(LivingEntity entity, Holder<Attribute> attribute, String name, double amount, AttributeModifier.Operation op, int ticks) {
        TimedModifiers.add(entity, attribute, UpgraderChaos.id(name), amount, op, entity.level().getGameTime() + ticks);
    }

    private static boolean alive(ServerPlayer player) {
        return player.isAlive() && !player.hasDisconnected();
    }

    private static void meteor(ServerPlayer player) {
        if (!alive(player)) {
            return;
        }
        ServerLevel level = player.serverLevel();
        Vec3 ground = ChaosEvents.groundNear(player, 5 + player.getRandom().nextInt(20));
        LargeFireball fireball = new LargeFireball(EntityType.FIREBALL, level);
        fireball.setPos(ground.x, ground.y + 40, ground.z);
        fireball.setDeltaMovement(0, -1.5, 0);
        fireball.accelerationPower = 0.08;
        level.addFreshEntity(fireball);
    }

    private static void arrows(ServerPlayer player, int count) {
        if (!alive(player)) {
            return;
        }
        ServerLevel level = player.serverLevel();
        for (int i = 0; i < count; i++) {
            Vec3 ground = ChaosEvents.groundNear(player, player.getRandom().nextInt(9));
            Arrow arrow = new Arrow(EntityType.ARROW, level);
            arrow.setPos(ground.x, ground.y + 30, ground.z);
            arrow.setDeltaMovement(0, -2.0, 0);
            arrow.pickup = AbstractArrow.Pickup.DISALLOWED;
            level.addFreshEntity(arrow);
        }
    }

    private static void lightningRing(ServerPlayer player, int radius) {
        if (!alive(player)) {
            return;
        }
        for (int i = 0; i < 8; i++) {
            double angle = Math.PI * 2 * i / 8;
            int x = player.getBlockX() + (int) Math.round(Math.cos(angle) * radius);
            int z = player.getBlockZ() + (int) Math.round(Math.sin(angle) * radius);
            int y = player.serverLevel().getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
            ChaosEvents.bolt(player.serverLevel(), Vec3.atBottomCenterOf(new BlockPos(x, y, z)));
        }
    }

    private static void bleed(ServerPlayer player) {
        if (!alive(player)) {
            return;
        }
        player.hurt(player.damageSources().generic(), 1.5F);
        player.serverLevel().sendParticles(new DustParticleOptions(new Vector3f(0.6F, 0F, 0F), 1.2F),
                player.getX(), player.getY() + 1.0, player.getZ(), 12, 0.3, 0.5, 0.3, 0.0);
    }

    private static void hiccup(ServerPlayer player) {
        if (!alive(player)) {
            return;
        }
        Vec3 motion = player.getDeltaMovement();
        player.setDeltaMovement(motion.x, 0.55, motion.z);
        player.hurtMarked = true;
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.PLAYER_BURP, SoundSource.PLAYERS, 1.0F, 1.6F);
    }

    /** Lifts a handful of surface blocks into the air; they land again as blocks and never drop items. */
    private static void quake(ServerPlayer player) {
        if (!alive(player)) {
            return;
        }
        ServerLevel level = player.serverLevel();
        RandomSource random = player.getRandom();
        level.playSound(null, player.blockPosition(), SoundEvents.GENERIC_EXPLODE.value(), SoundSource.BLOCKS, 0.4F, 0.4F);
        for (int i = 0; i < 6; i++) {
            int x = player.getBlockX() + random.nextInt(21) - 10;
            int z = player.getBlockZ() + random.nextInt(21) - 10;
            BlockPos top = new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1, z);
            BlockState state = level.getBlockState(top);
            boolean natural = state.is(BlockTags.DIRT) || state.is(BlockTags.SAND) || state.is(BlockTags.BASE_STONE_OVERWORLD) || state.is(Blocks.GRAVEL);
            if (natural && !state.hasBlockEntity()) {
                FallingBlockEntity block = FallingBlockEntity.fall(level, top, state);
                block.dropItem = false;
                block.setDeltaMovement(0, 0.35 + random.nextDouble() * 0.3, 0);
            }
        }
    }

    private static void snowAround(ServerLevel level, BlockPos center, int radius, RandomSource random) {
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (dx * dx + dz * dz > radius * radius || random.nextFloat() < 0.15F) {
                    continue;
                }
                int x = center.getX() + dx;
                int z = center.getZ() + dz;
                BlockPos pos = new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z), z);
                BlockPos below = pos.below();
                if (level.isEmptyBlock(pos) && level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) {
                    level.setBlockAndUpdate(pos, Blocks.SNOW.defaultBlockState());
                }
            }
        }
    }

    private static int freezeWater(ServerLevel level, BlockPos center, int radius) {
        int frozen = 0;
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-radius, -6, -radius), center.offset(radius, 6, radius))) {
            if (level.getBlockState(pos).is(Blocks.WATER) && level.getFluidState(pos).isSource() && level.isEmptyBlock(pos.above())) {
                level.setBlockAndUpdate(pos, Blocks.ICE.defaultBlockState());
                frozen++;
            }
        }
        return frozen;
    }

    /** Removes temporary blocks again (if nobody replaced them), so traps never turn into free resources. */
    private static void cleanupLater(ServerLevel level, List<BlockPos> placed, BlockState expected, int ticks) {
        WorldClock.later(ticks, () -> {
            for (BlockPos pos : placed) {
                if (level.getBlockState(pos) == expected) {
                    level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
                }
            }
        });
    }

    private static boolean teleportFar(ServerPlayer player, RandomSource random) {
        ServerLevel level = player.serverLevel();
        if (level.dimensionType().hasCeiling()) {
            // Nether-like: no sky to land on, so do a chorus-fruit hop instead.
            for (int i = 0; i < 16; i++) {
                double x = player.getX() + random.nextInt(65) - 32;
                double y = player.getY() + random.nextInt(17) - 8;
                double z = player.getZ() + random.nextInt(65) - 32;
                if (player.randomTeleport(x, y, z, true)) {
                    return true;
                }
            }
            return false;
        }
        for (int attempt = 0; attempt < 6; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2;
            int distance = 200 + random.nextInt(401);
            int x = player.getBlockX() + (int) (Math.cos(angle) * distance);
            int z = player.getBlockZ() + (int) (Math.sin(angle) * distance);
            level.getChunk(x >> 4, z >> 4);
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            if (level.getBlockState(new BlockPos(x, y - 1, z)).getFluidState().isEmpty()) {
                player.teleportTo(level, x + 0.5, y, z + 0.5, player.getYRot(), player.getXRot());
                return true;
            }
        }
        return false;
    }

    private MoreEvents() {
    }
}
