package ru.upgraderchaos;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.upgraderchaos.machine.ChaosMenu;
import ru.upgraderchaos.network.ChaosNetwork;
import ru.upgraderchaos.world.ChaosBiome;
import ru.upgraderchaos.world.ChaosBlocks;

@Mod(UpgraderChaos.MOD_ID)
public final class UpgraderChaos {
    public static final String MOD_ID = "upgrader_chaos";
    public static final Logger LOGGER = LoggerFactory.getLogger("Upgrader Chaos");

    public UpgraderChaos(IEventBus modBus, ModContainer container) {
        // Blocks first: their block items are added to ITEMS while ChaosBlocks loads.
        ChaosBlocks.BLOCKS.register(modBus);
        ChaosItems.ITEMS.register(modBus);
        ChaosItems.TABS.register(modBus);
        ChaosAttachments.ATTACHMENTS.register(modBus);
        ChaosMenu.MENUS.register(modBus);
        modBus.addListener(ChaosNetwork::register);
        modBus.addListener(ChaosBiome::onCommonSetup);
        container.registerConfig(ModConfig.Type.COMMON, ChaosConfig.SPEC);
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    public static boolean hasPmWeather() {
        return ModList.get().isLoaded("pmweather");
    }
}
