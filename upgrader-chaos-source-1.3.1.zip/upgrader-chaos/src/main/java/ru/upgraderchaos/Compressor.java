package ru.upgraderchaos;

import net.minecraft.util.RandomSource;
import ru.upgraderchaos.machine.UpgraderTier;

/**
 * Picks the phenomenon an item is compressed into. Only events inside the upgrader's value window can come out;
 * among those, events whose value is close to the item's value (on a log scale) are the most likely, so dirt
 * gives a bit of rain and a stack of diamonds a tornado. A small floor weight keeps every allowed event possible.
 */
public final class Compressor {
    /** How far (in e-folds of value) the roll usually strays from the item's own value. */
    private static final double SPREAD = 0.9;
    private static final double FLOOR = 0.002;

    /** Probability of every event (indexed by ordinal) for this item value in this upgrader. Sums to 1. */
    public static double[] chances(double itemValue, UpgraderTier tier) {
        ChaosEvent[] events = ChaosEvent.values();
        // Items cheaper than the cheapest allowed event aim at the cheapest ones (and pricier than the priciest at
        // the top), otherwise every event would be equally far away and the roll would become uniform.
        double cheapest = Double.MAX_VALUE;
        double priciest = 0;
        for (ChaosEvent event : events) {
            if (usable(event, tier)) {
                cheapest = Math.min(cheapest, ChaosConfig.value(event));
                priciest = Math.max(priciest, ChaosConfig.value(event));
            }
        }
        double[] weights = new double[events.length];
        if (priciest <= 0) {
            return weights;
        }
        double target = Math.log(Math.clamp(itemValue, cheapest, priciest));
        double total = 0;
        for (int i = 0; i < events.length; i++) {
            if (!usable(events[i], tier)) {
                continue;
            }
            double distance = (Math.log(ChaosConfig.value(events[i])) - target) / SPREAD;
            weights[i] = Math.exp(-0.5 * distance * distance) + FLOOR;
            total += weights[i];
        }
        for (int i = 0; i < weights.length; i++) {
            weights[i] /= total;
        }
        return weights;
    }

    private static boolean usable(ChaosEvent event, UpgraderTier tier) {
        return ChaosConfig.isEnabled(event) && tier.allows(event);
    }

    public static ChaosEvent pick(double itemValue, UpgraderTier tier, RandomSource random) {
        double[] chances = chances(itemValue, tier);
        double roll = random.nextDouble();
        ChaosEvent last = ChaosEvent.CLEAR_SKY;
        for (int i = 0; i < chances.length; i++) {
            if (chances[i] <= 0) {
                continue;
            }
            last = ChaosEvent.values()[i];
            roll -= chances[i];
            if (roll <= 0) {
                return last;
            }
        }
        return last;
    }

    private Compressor() {
    }
}
