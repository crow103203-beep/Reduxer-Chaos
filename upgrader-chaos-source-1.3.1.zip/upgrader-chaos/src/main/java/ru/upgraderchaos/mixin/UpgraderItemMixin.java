package ru.upgraderchaos.mixin;

import net.execheinz.upgrader.item.UpgraderItem;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.upgraderchaos.machine.ChaosMenu;
import ru.upgraderchaos.machine.UpgraderTier;

/** The regular Upgrader opens the green compressor: no item rewards and no picking a target anywhere. */
@Mixin(value = UpgraderItem.class, remap = false)
public abstract class UpgraderItemMixin {

    @Inject(method = "use", at = @At("HEAD"), cancellable = true)
    private void upgraderChaos$openCompressor(Level level, Player player, InteractionHand hand, CallbackInfoReturnable<InteractionResultHolder<ItemStack>> cir) {
        if (player instanceof ServerPlayer serverPlayer) {
            ChaosMenu.open(serverPlayer, UpgraderTier.GREEN);
        }
        cir.setReturnValue(InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide()));
    }
}
