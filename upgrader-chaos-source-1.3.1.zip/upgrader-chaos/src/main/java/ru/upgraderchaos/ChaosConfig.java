package ru.upgraderchaos;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import net.neoforged.neoforge.common.ModConfigSpec;

public final class ChaosConfig {
    public static final ModConfigSpec SPEC;

    private static final ModConfigSpec.ConfigValue<List<? extends String>> VALUES;
    private static final ModConfigSpec.ConfigValue<List<? extends String>> DISABLED_EVENTS;
    private static final ModConfigSpec.ConfigValue<List<? extends String>> BOSS_POOL;
    private static final ModConfigSpec.ConfigValue<List<? extends String>> MOB_BLACKLIST;
    private static final ModConfigSpec.BooleanValue ORGANS_SURVIVE_DEATH;
    private static final ModConfigSpec.BooleanValue ANNOUNCE_TO_ALL;
    private static final ModConfigSpec.BooleanValue EYE_OVERLAY;
    private static final ModConfigSpec.IntValue EFFECT_SECONDS;
    private static final ModConfigSpec.IntValue MOB_RADIUS;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.push("events");
        List<String> defaults = new ArrayList<>();
        for (ChaosEvent event : ChaosEvent.values()) {
            defaults.add(event.id + "=" + (long) event.defaultValue);
        }
        VALUES = b.comment("Value of every event in Upgrader units (iron ingot = 40, diamond = 400).",
                        "An item is most likely compressed into events of about the same value as the whole stack.")
                .defineListAllowEmpty("values", defaults, () -> "event=100", o -> o instanceof String s && s.contains("="));
        DISABLED_EVENTS = b.comment("Event ids the upgraders never compress into.")
                .defineListAllowEmpty("disabled", List.of(), () -> "", o -> o instanceof String);
        EFFECT_SECONDS = b.comment("How long timed events last (eternal night, sounds, smart/dumb/giant mobs, player size).")
                .defineInRange("effectSeconds", 300, 10, 7200);
        MOB_RADIUS = b.comment("Radius in blocks for events that change nearby mobs.")
                .defineInRange("mobRadius", 48, 8, 256);
        ANNOUNCE_TO_ALL = b.comment("Tell every player on the server what someone rolled.")
                .define("announceToAll", true);
        b.pop();

        b.push("mobs");
        BOSS_POOL = b.comment("Entities used by the 'mini boss' event (missing ones are skipped).")
                .defineListAllowEmpty("bossPool", List.of(
                        "mowziesmobs:ferrous_wroughtnaut", "mowziesmobs:frostmaw", "mowziesmobs:naga",
                        "legendary_monsters:overgrown_colossus", "legendary_monsters:frostbitten_golem",
                        "legendary_monsters:withered_abomination", "legendary_monsters:skeletosaurus",
                        "legendary_monsters:endersent", "legendary_monsters:lava_eater", "legendary_monsters:warped_fungussus",
                        "legendary_monsters:posessed_paladin", "legendary_monsters:dune_sentinel", "legendary_monsters:cloud_golem",
                        "minecraft:ravager", "minecraft:evoker", "minecraft:warden"), () -> "mod:entity", o -> o instanceof String);
        MOB_BLACKLIST = b.comment("Entities never picked by 'invasion' and 'strange guests'.")
                .defineListAllowEmpty("blacklist", List.of(
                        "minecraft:ender_dragon", "minecraft:wither", "minecraft:warden", "minecraft:elder_guardian",
                        "minecraft:guardian", "minecraft:giant", "minecraft:illusioner",
                        "mowziesmobs:umvuthi", "mowziesmobs:sculptor", "mowziesmobs:umvuthana_crane_player",
                        "mowziesmobs:umvuthana_follower_player", "mowziesmobs:elokosa_follower_howler", "mowziesmobs:umvuthana_follower_raptor",
                        "endermanoverhaul:pet_enderman", "endermanoverhaul:axolotl_pet_enderman", "endermanoverhaul:hammerhead_pet_enderman",
                        "legendary_monsters:the_obliterator", "legendary_monsters:annihilation_pursuer",
                        "legendary_monsters:ancient_guardian", "legendary_monsters:hovering_hurricane",
                        "legendary_monsters:knights_armor", "legendary_monsters:shulker_mimic"), () -> "mod:entity", o -> o instanceof String);
        b.pop();

        b.push("body");
        ORGANS_SURVIVE_DEATH = b.comment("Lost organs stay lost after death (only 'organ transplant' brings them back).")
                .define("organsSurviveDeath", true);
        EYE_OVERLAY = b.comment("Darken half of the screen when an eye is missing (client side).")
                .define("eyeOverlay", true);
        b.pop();

        SPEC = b.build();
    }

    public static double value(ChaosEvent event) {
        if (!SPEC.isLoaded()) {
            return event.defaultValue;
        }
        for (String entry : VALUES.get()) {
            int split = entry.indexOf('=');
            if (split > 0 && entry.substring(0, split).trim().equals(event.id)) {
                try {
                    return Math.max(1.0, Double.parseDouble(entry.substring(split + 1).trim()));
                } catch (NumberFormatException ignored) {
                    break;
                }
            }
        }
        return event.defaultValue;
    }

    public static boolean isEnabled(ChaosEvent event) {
        return !SPEC.isLoaded() || !DISABLED_EVENTS.get().contains(event.id);
    }

    public static List<? extends String> bossPool() {
        return BOSS_POOL.get();
    }

    public static Set<String> mobBlacklist() {
        return new HashSet<>(MOB_BLACKLIST.get());
    }

    public static boolean organsSurviveDeath() {
        return ORGANS_SURVIVE_DEATH.get();
    }

    public static boolean announceToAll() {
        return ANNOUNCE_TO_ALL.get();
    }

    public static boolean eyeOverlay() {
        return !SPEC.isLoaded() || EYE_OVERLAY.get();
    }

    public static int effectTicks() {
        return EFFECT_SECONDS.get() * 20;
    }

    public static int mobRadius() {
        return MOB_RADIUS.get();
    }

    private ChaosConfig() {
    }
}
