package ru.upgraderchaos;

import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

/**
 * Everything the blue upgrader can compress an item into. The value is the event's "price": an item of
 * similar value most likely turns into it (see {@link Compressor}).
 */
public enum ChaosEvent {
    // Vanilla-ish weather (with ProtoManly's Weather these become real storms).
    CLEAR_SKY(Category.WEATHER, 25, "minecraft:item/glowstone_dust"),
    RAIN(Category.WEATHER, 30, "minecraft:item/water_bucket"),
    THUNDERSTORM(Category.WEATHER, 70, "minecraft:item/blaze_rod"),
    LIGHTNING_BARRAGE(Category.WEATHER, 160, "minecraft:item/fire_charge"),

    // ProtoManly's Weather.
    TORNADO_WEAK(Category.STORM, 400, "minecraft:item/wind_charge"),
    TORNADO_STRONG(Category.STORM, 1500, "minecraft:item/breeze_rod"),
    TORNADO_MONSTER(Category.STORM, 5000, "minecraft:item/nether_star"),
    SUPERCELL(Category.STORM, 800, "minecraft:item/phantom_membrane"),
    SQUALL_LINE(Category.STORM, 600, "minecraft:item/feather"),
    FIRE_WHIRL(Category.STORM, 500, "minecraft:item/blaze_powder"),
    HURRICANE(Category.STORM, 3000, "minecraft:item/heart_of_the_sea"),
    MEGA_LIGHTNING(Category.STORM, 250, "minecraft:item/echo_shard"),

    // Time of day.
    DAY_NIGHT_SWAP(Category.TIME, 40, "minecraft:item/clock_00"),
    ETERNAL_NIGHT(Category.TIME, 300, "minecraft:item/ender_eye"),
    TIME_WARP(Category.TIME, 200, "minecraft:item/compass_00"),

    // Body.
    ORGAN_LOSS(Category.BODY, 90, "minecraft:item/spider_eye"),
    ORGAN_RESTORE(Category.BODY, 2500, "minecraft:item/golden_apple"),

    // Sounds of the world.
    SOUND_SHUFFLE(Category.SOUND, 150, "minecraft:item/music_disc_11"),
    SOUND_MONO(Category.SOUND, 150, "minecraft:item/goat_horn"),
    SOUND_CHIPMUNK(Category.SOUND, 120, "minecraft:item/music_disc_cat"),
    SOUND_DEEP(Category.SOUND, 120, "minecraft:item/music_disc_ward"),
    SOUND_SILENCE(Category.SOUND, 180, "minecraft:item/structure_void"),

    // Mobs.
    MOB_INVASION(Category.MOBS, 300, "minecraft:item/rotten_flesh"),
    STRANGE_GUESTS(Category.MOBS, 150, "minecraft:item/egg"),
    MINI_BOSS(Category.MOBS, 2000, "minecraft:item/ghast_tear"),
    MOBS_DUMB(Category.MOBS, 250, "minecraft:item/slime_ball"),
    MOBS_SMART(Category.MOBS, 250, "minecraft:item/experience_bottle"),
    MOBS_GIANT(Category.MOBS, 400, "minecraft:item/bone"),
    MOBS_TINY(Category.MOBS, 300, "minecraft:item/rabbit_hide"),

    // Effects on the player.
    RANDOM_EFFECT(Category.EFFECT, 80, "minecraft:item/dragon_breath"),
    EFFECT_COCKTAIL(Category.EFFECT, 200, "minecraft:item/suspicious_stew"),
    PLAYER_TINY(Category.EFFECT, 250, "minecraft:item/sugar"),
    PLAYER_GIANT(Category.EFFECT, 250, "minecraft:item/magma_cream"),

    // Things falling from the sky and other weather oddities.
    METEOR_SHOWER(Category.WEATHER, 900, "minecraft:block/magma"),
    ARROW_RAIN(Category.WEATHER, 120, "minecraft:item/arrow"),
    TNT_RAIN(Category.WEATHER, 1200, "minecraft:block/tnt_side"),
    SHEEP_RAIN(Category.WEATHER, 60, "minecraft:block/white_wool"),
    SNOWSTORM(Category.WEATHER, 90, "minecraft:item/snowball"),

    TORNADO_OUTBREAK(Category.STORM, 2500, "minecraft:item/trident"),
    TORNADO_OVERHEAD(Category.STORM, 1000, "minecraft:item/elytra"),
    LIGHTNING_CAGE(Category.STORM, 350, "minecraft:block/iron_bars"),

    INSTANT_DAWN(Category.TIME, 30, "minecraft:item/clock_48"),
    ETERNAL_DAY(Category.TIME, 250, "minecraft:block/sunflower_front"),
    SLOW_MOTION(Category.TIME, 400, "minecraft:item/honey_bottle"),
    FAST_FORWARD(Category.TIME, 400, "minecraft:item/clock_16"),

    DOUBLE_SURGERY(Category.BODY, 600, "minecraft:item/shears"),
    FULL_RESTORE(Category.BODY, 4000, "minecraft:item/enchanted_golden_apple"),
    BLEEDING(Category.BODY, 70, "minecraft:item/beetroot"),
    AMNESIA(Category.BODY, 200, "minecraft:item/book"),
    HICCUPS(Category.BODY, 40, "minecraft:item/glass_bottle"),
    DRUNK(Category.BODY, 60, "minecraft:item/fermented_spider_eye"),
    INVERTED_CONTROLS(Category.BODY, 150, "minecraft:item/lead"),

    // The ground around you.
    ICE_AGE(Category.WORLD, 450, "minecraft:block/blue_ice"),
    COBWEB_TRAP(Category.WORLD, 50, "minecraft:block/cobweb"),
    GLASS_CAGE(Category.WORLD, 80, "minecraft:block/glass"),
    SINKHOLE(Category.WORLD, 300, "minecraft:block/coarse_dirt"),
    LAUNCH(Category.WORLD, 100, "minecraft:item/firework_rocket"),
    RANDOM_TELEPORT(Category.WORLD, 700, "minecraft:item/ender_pearl"),
    EXPLOSION(Category.WORLD, 500, "minecraft:item/gunpowder"),
    EARTHQUAKE(Category.WORLD, 1100, "minecraft:block/cracked_stone_bricks"),

    ZOMBIE_HORDE(Category.MOBS, 350, "minecraft:item/poisonous_potato"),
    PHANTOM_SQUAD(Category.MOBS, 400, "minecraft:item/ink_sac"),
    BEE_SWARM(Category.MOBS, 120, "minecraft:item/honeycomb"),
    PILLAGER_PATROL(Category.MOBS, 600, "minecraft:item/crossbow_standby"),
    PET(Category.MOBS, 250, "minecraft:item/name_tag"),
    MOBS_GLOW(Category.MOBS, 40, "minecraft:item/glow_ink_sac"),

    SOUND_ECHO(Category.SOUND, 100, "minecraft:item/music_disc_mall"),
    SOUND_GHOSTS(Category.SOUND, 130, "minecraft:item/music_disc_13"),
    SOUND_BROKEN_RADIO(Category.SOUND, 110, "minecraft:item/music_disc_stal"),

    // What you see.
    FOG(Category.VISION, 90, "minecraft:item/gray_dye"),
    BLOOD_MOON(Category.VISION, 1800, "minecraft:item/red_dye"),
    UPSIDE_DOWN(Category.VISION, 220, "minecraft:item/spyglass"),
    CAROUSEL(Category.VISION, 160, "minecraft:item/minecart"),
    FISHEYE(Category.VISION, 140, "minecraft:item/amethyst_shard"),

    SUPER_JUMP(Category.EFFECT, 60, "minecraft:item/rabbit_foot"),
    SPEED_DEMON(Category.EFFECT, 80, "minecraft:item/golden_carrot"),
    LOW_GRAVITY(Category.EFFECT, 200, "minecraft:item/shulker_shell"),
    HEAVY_GRAVITY(Category.EFFECT, 200, "minecraft:item/iron_ingot"),
    FEAST(Category.EFFECT, 35, "minecraft:item/cooked_beef"),

    // Your inventory (nothing is ever added to it).
    INVENTORY_SHUFFLE(Category.INVENTORY, 150, "minecraft:item/bundle"),
    RUST(Category.INVENTORY, 300, "minecraft:item/copper_ingot"),

    // Hallucinations: only you see or hear them, nothing really happens.
    FAKE_MOBS(Category.HALLUCINATION, 80, "minecraft:item/armor_stand"),
    FAKE_CHAT(Category.HALLUCINATION, 40, "minecraft:item/writable_book"),
    FAKE_EXPLOSION(Category.HALLUCINATION, 60, "minecraft:block/tnt_top"),
    FAKE_TREASURE(Category.HALLUCINATION, 120, "minecraft:item/diamond"),
    PHANTOM_PAIN(Category.HALLUCINATION, 50, "minecraft:item/bone_meal"),
    MADNESS(Category.HALLUCINATION, 700, "minecraft:item/pufferfish"),

    // Something from the list above, but you are not told what.
    MYSTERY(Category.MYSTERY, 350, "upgrader_chaos:item/mystery"),
    DOUBLE_MYSTERY(Category.MYSTERY, 900, "upgrader_chaos:item/mystery"),
    CHAIN_REACTION(Category.MYSTERY, 3500, "minecraft:item/firework_star");

    public final String id;
    public final Category category;
    public final double defaultValue;
    public final String icon;

    ChaosEvent(Category category, double defaultValue, String icon) {
        this.id = name().toLowerCase(Locale.ROOT);
        this.category = category;
        this.defaultValue = defaultValue;
        this.icon = icon;
    }

    public String translationKey() {
        return "item." + UpgraderChaos.MOD_ID + "." + id;
    }

    public boolean needsPmWeather() {
        return category == Category.STORM && this != LIGHTNING_CAGE;
    }

    public Component displayName() {
        return Component.translatable(translationKey()).withStyle(category.color);
    }

    @Nullable
    public static ChaosEvent byId(String id) {
        for (ChaosEvent event : values()) {
            if (event.id.equals(id)) {
                return event;
            }
        }
        return null;
    }

    public enum Category {
        WEATHER(ChatFormatting.AQUA),
        STORM(ChatFormatting.DARK_AQUA),
        TIME(ChatFormatting.GOLD),
        BODY(ChatFormatting.DARK_RED),
        SOUND(ChatFormatting.YELLOW),
        MOBS(ChatFormatting.RED),
        EFFECT(ChatFormatting.GREEN),
        WORLD(ChatFormatting.DARK_GREEN),
        VISION(ChatFormatting.BLUE),
        INVENTORY(ChatFormatting.GRAY),
        HALLUCINATION(ChatFormatting.WHITE),
        MYSTERY(ChatFormatting.DARK_PURPLE);

        public final ChatFormatting color;

        Category(ChatFormatting color) {
            this.color = color;
        }

        public Component displayName() {
            return Component.translatable("category.upgrader_chaos." + name().toLowerCase(Locale.ROOT)).withStyle(color);
        }
    }
}
