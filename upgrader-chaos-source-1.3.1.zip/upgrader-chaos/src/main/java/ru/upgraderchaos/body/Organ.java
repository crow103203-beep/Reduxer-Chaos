package ru.upgraderchaos.body;

import java.util.Locale;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

/** Body parts the upgrader can take. The side effects live in {@link Organs}. */
public enum Organ {
    EYE,      // half of the screen goes dark
    EAR,      // world gets quiet, ringing in the ear
    TONGUE,   // chat turns into mumbling
    ARM,      // weaker hits, slower mining, nothing stays in the off hand
    LEG,      // slow walking, low jumps
    LUNG,     // air runs out twice as fast, can't sprint for long
    KIDNEY,   // bouts of nausea and weakness
    LIVER,    // food sometimes poisons you
    STOMACH,  // always hungry
    HEART;    // three hearts less, occasional chest pain

    public final String id = name().toLowerCase(Locale.ROOT);

    public Component displayName() {
        return Component.translatable("organ.upgrader_chaos." + id);
    }

    public Component effectText() {
        return Component.translatable("organ.upgrader_chaos." + id + ".effect");
    }

    @Nullable
    public static Organ byId(String id) {
        for (Organ organ : values()) {
            if (organ.id.equals(id)) {
                return organ;
            }
        }
        return null;
    }
}
