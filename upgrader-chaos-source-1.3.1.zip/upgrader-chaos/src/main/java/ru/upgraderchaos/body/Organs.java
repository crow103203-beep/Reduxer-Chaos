package ru.upgraderchaos.body;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.event.ServerChatEvent;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import org.jetbrains.annotations.Nullable;
import ru.upgraderchaos.ChaosAttachments;
import ru.upgraderchaos.ChaosConfig;
import ru.upgraderchaos.UpgraderChaos;
import ru.upgraderchaos.network.ChaosNetwork;

@EventBusSubscriber(modid = UpgraderChaos.MOD_ID)
public final class Organs {
    public static final Supplier<AttachmentType<List<String>>> LOST = ChaosAttachments.LOST_ORGANS;

    private static final ResourceLocation ARM_DAMAGE = UpgraderChaos.id("organ_arm_damage");
    private static final ResourceLocation ARM_MINING = UpgraderChaos.id("organ_arm_mining");
    private static final ResourceLocation LEG_SPEED = UpgraderChaos.id("organ_leg_speed");
    private static final ResourceLocation LEG_JUMP = UpgraderChaos.id("organ_leg_jump");
    private static final ResourceLocation HEART_HEALTH = UpgraderChaos.id("organ_heart_health");
    private static final String SPRINT_TICKS = UpgraderChaos.MOD_ID + ":lung_sprint";

    public static Set<Organ> lost(Player player) {
        Set<Organ> set = EnumSet.noneOf(Organ.class);
        for (String id : player.getData(LOST)) {
            Organ organ = Organ.byId(id);
            if (organ != null) {
                set.add(organ);
            }
        }
        return set;
    }

    public static boolean has(Player player, Organ organ) {
        return !player.getData(LOST).contains(organ.id);
    }

    private static void store(ServerPlayer player, Set<Organ> lost) {
        List<String> ids = new ArrayList<>();
        for (Organ organ : lost) {
            ids.add(organ.id);
        }
        player.setData(LOST, List.copyOf(ids));
        applyAttributes(player);
        ChaosNetwork.sendOrgans(player);
    }

    /** Takes a random organ the player still has. Returns null if there is nothing left to take. */
    @Nullable
    public static Organ removeRandom(ServerPlayer player) {
        Set<Organ> lost = lost(player);
        List<Organ> left = new ArrayList<>();
        for (Organ organ : Organ.values()) {
            if (!lost.contains(organ)) {
                left.add(organ);
            }
        }
        if (left.isEmpty()) {
            return null;
        }
        Organ taken = left.get(player.getRandom().nextInt(left.size()));
        lost.add(taken);
        store(player, lost);
        return taken;
    }

    @Nullable
    public static Organ restoreRandom(ServerPlayer player) {
        List<Organ> lost = new ArrayList<>(lost(player));
        if (lost.isEmpty()) {
            return null;
        }
        Organ back = lost.get(player.getRandom().nextInt(lost.size()));
        Set<Organ> rest = lost(player);
        rest.remove(back);
        store(player, rest);
        return back;
    }

    public static void restoreAll(ServerPlayer player) {
        store(player, EnumSet.noneOf(Organ.class));
    }

    private static void applyAttributes(ServerPlayer player) {
        Set<Organ> lost = lost(player);
        modifier(player, Attributes.ATTACK_DAMAGE, ARM_DAMAGE, -0.35, lost.contains(Organ.ARM));
        modifier(player, Attributes.BLOCK_BREAK_SPEED, ARM_MINING, -0.4, lost.contains(Organ.ARM));
        modifier(player, Attributes.MOVEMENT_SPEED, LEG_SPEED, -0.3, lost.contains(Organ.LEG));
        modifier(player, Attributes.JUMP_STRENGTH, LEG_JUMP, -0.3, lost.contains(Organ.LEG));

        AttributeInstance health = player.getAttribute(Attributes.MAX_HEALTH);
        if (health != null) {
            boolean want = lost.contains(Organ.HEART);
            if (want && !health.hasModifier(HEART_HEALTH)) {
                health.addPermanentModifier(new AttributeModifier(HEART_HEALTH, -6.0, AttributeModifier.Operation.ADD_VALUE));
            } else if (!want && health.hasModifier(HEART_HEALTH)) {
                health.removeModifier(HEART_HEALTH);
            }
            if (player.getHealth() > player.getMaxHealth()) {
                player.setHealth(player.getMaxHealth());
            }
        }
    }

    private static void modifier(Player player, Holder<Attribute> attribute, ResourceLocation id, double amount, boolean want) {
        AttributeInstance instance = player.getAttribute(attribute);
        if (instance == null) {
            return;
        }
        if (want && !instance.hasModifier(id)) {
            instance.addPermanentModifier(new AttributeModifier(id, amount, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        } else if (!want && instance.hasModifier(id)) {
            instance.removeModifier(id);
        }
    }

    @SubscribeEvent
    public static void onTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.isSpectator()) {
            return;
        }
        List<String> raw = player.getData(LOST);
        if (raw.isEmpty()) {
            return;
        }
        Set<Organ> lost = lost(player);
        RandomSource random = player.getRandom();

        if (player.tickCount % 20 == 0) {
            applyAttributes(player);
        }

        if (lost.contains(Organ.ARM) && player.tickCount % 10 == 0 && !player.getOffhandItem().isEmpty()) {
            ItemStack offhand = player.getOffhandItem().copy();
            player.getInventory().offhand.set(0, ItemStack.EMPTY);
            if (!player.getInventory().add(offhand)) {
                player.drop(offhand, true);
            }
            player.displayClientMessage(Component.translatable("message.upgrader_chaos.organ.arm_offhand").withStyle(ChatFormatting.GRAY), true);
        }

        if (lost.contains(Organ.LUNG)) {
            if (player.isUnderWater() && player.getAirSupply() > -19 && player.tickCount % 2 == 0) {
                player.setAirSupply(player.getAirSupply() - 1);
            }
            int sprint = player.getPersistentData().getInt(SPRINT_TICKS);
            sprint = player.isSprinting() ? sprint + 1 : Math.max(0, sprint - 2);
            if (sprint > 100) {
                sprint = 0;
                player.setSprinting(false);
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                player.causeFoodExhaustion(2.0F);
                player.displayClientMessage(Component.translatable("message.upgrader_chaos.organ.lung_breath").withStyle(ChatFormatting.GRAY), true);
            }
            player.getPersistentData().putInt(SPRINT_TICKS, sprint);
        }

        if (lost.contains(Organ.KIDNEY) && random.nextInt(3000) == 0) {
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200));
            player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 300));
            player.displayClientMessage(Component.translatable("message.upgrader_chaos.organ.kidney_pain").withStyle(ChatFormatting.RED), true);
        }

        if (lost.contains(Organ.STOMACH)) {
            player.causeFoodExhaustion(0.006F);
        }

        if (lost.contains(Organ.HEART) && random.nextInt(4000) == 0) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 2));
            player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
            player.level().playSound(null, player.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.PLAYERS, 1.0F, 1.0F);
            player.displayClientMessage(Component.translatable("message.upgrader_chaos.organ.heart_pain").withStyle(ChatFormatting.RED), true);
        }

        if (lost.contains(Organ.EYE) && random.nextInt(5000) == 0) {
            player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80));
            player.displayClientMessage(Component.translatable("message.upgrader_chaos.organ.eye_pain").withStyle(ChatFormatting.GRAY), true);
        }
    }

    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        if (has(event.getPlayer(), Organ.TONGUE)) {
            return;
        }
        event.setMessage(Component.literal(mumble(event.getRawText(), event.getPlayer().getRandom())));
    }

    /** Keeps word lengths and punctuation, turns letters into "мммф". */
    static String mumble(String text, RandomSource random) {
        String sounds = "ммммфыуа";
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                char m = sounds.charAt(random.nextInt(sounds.length()));
                out.append(Character.isUpperCase(c) ? Character.toUpperCase(m) : m);
            } else {
                out.append(c);
            }
        }
        return out.toString();
    }

    @SubscribeEvent
    public static void onFoodEaten(LivingEntityUseItemEvent.Finish event) {
        if (event.getEntity() instanceof ServerPlayer player && !has(player, Organ.LIVER)
                && event.getItem().has(DataComponents.FOOD) && player.getRandom().nextFloat() < 0.4F) {
            player.addEffect(new MobEffectInstance(MobEffects.POISON, 120));
            player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 200));
            player.displayClientMessage(Component.translatable("message.upgrader_chaos.organ.liver_poison").withStyle(ChatFormatting.DARK_GREEN), true);
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (!event.isWasDeath() || ChaosConfig.organsSurviveDeath()) {
            event.getEntity().setData(LOST, event.getOriginal().getData(LOST));
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            applyAttributes(player);
            ChaosNetwork.sendOrgans(player);
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            applyAttributes(player);
            ChaosNetwork.sendOrgans(player);
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ChaosNetwork.sendOrgans(player);
        }
    }

    private Organs() {
    }
}
