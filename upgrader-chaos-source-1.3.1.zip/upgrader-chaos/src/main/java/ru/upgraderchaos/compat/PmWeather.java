package ru.upgraderchaos.compat;

import dev.protomanly.pmweather.event.GameBusEvents;
import dev.protomanly.pmweather.weather.Storm;
import dev.protomanly.pmweather.weather.WeatherHandler;
import dev.protomanly.pmweather.weather.WeatherHandlerServer;
import dev.protomanly.pmweather.weather.storms.StormSpawnProperties;
import dev.protomanly.pmweather.weather.storms.StormType;
import dev.protomanly.pmweather.weather.storms.StormTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Talks to ProtoManly's Weather directly. Only touch this class after checking that pmweather is loaded,
 * otherwise its imports fail to resolve.
 */
public final class PmWeather {

    @Nullable
    private static WeatherHandlerServer handler(ServerLevel level) {
        WeatherHandler handler = GameBusEvents.MANAGERS.get(level.dimension());
        return handler instanceof WeatherHandlerServer server ? server : null;
    }

    /** A point {@code distance} blocks away from the player in a random direction. */
    private static Vec3 around(ServerPlayer player, double distance) {
        RandomSource random = player.getRandom();
        double angle = random.nextDouble() * Math.PI * 2.0;
        return player.position().add(Math.cos(angle) * distance, 0.0, Math.sin(angle) * distance);
    }

    /** Fully grown tornado that starts away from the player and heads for them. Same setup as /pmweather spawn tornado. */
    public static boolean tornado(ServerPlayer player, int windspeed, int width, double distance) {
        ServerLevel level = player.serverLevel();
        WeatherHandlerServer handler = handler(level);
        if (handler == null) {
            return false;
        }
        Storm storm = StormTypes.SUPERCELL.create(new StormSpawnProperties(handler, level, around(player, distance), null));
        storm.width = width;
        storm.windspeed = windspeed;
        storm.stage = 3;
        storm.velocity = Vec3.ZERO;
        storm.energy = 0;
        storm.initFirstTime();
        storm.maxStage = Math.max(storm.maxStage, 3);
        storm.maxProgress = Math.max(storm.maxProgress, 100);
        storm.maxWindspeed = windspeed;
        storm.maxWidth = width;
        storm.calcRain();
        return launch(handler, storm, true);
    }

    /** A storm cell that grows on its own up to {@code maxStage} (0 rain, 1 thunderstorm, 2 supercell, 3 tornadic). */
    public static boolean supercell(ServerPlayer player, int maxStage, int maxEnergy, double distance, boolean aim) {
        ServerLevel level = player.serverLevel();
        WeatherHandlerServer handler = handler(level);
        if (handler == null) {
            return false;
        }
        Storm storm = StormTypes.SUPERCELL.create(new StormSpawnProperties(handler, level, around(player, distance), null));
        storm.width = 0;
        storm.windspeed = 0;
        storm.stage = 0;
        storm.velocity = Vec3.ZERO;
        storm.energy = 0;
        storm.maxStage = Mth.clamp(maxStage, 0, 3);
        storm.maxProgress = Mth.clamp(maxEnergy, 1, 99);
        storm.initFirstTime();
        storm.calcRain();
        return launch(handler, storm, aim);
    }

    public static boolean squall(ServerPlayer player, int maxStage, int maxEnergy) {
        ServerLevel level = player.serverLevel();
        WeatherHandlerServer handler = handler(level);
        if (handler == null) {
            return false;
        }
        Storm storm = StormTypes.SQUALL.create(new StormSpawnProperties(handler, level, around(player, 600), null));
        storm.width = 0;
        storm.windspeed = 0;
        storm.stage = 0;
        storm.velocity = Vec3.ZERO;
        storm.energy = 0;
        storm.maxStage = Mth.clamp(maxStage, 0, 3);
        storm.maxProgress = Mth.clamp(maxEnergy, 1, 99);
        storm.initFirstTime();
        storm.calcRain();
        return launch(handler, storm, true);
    }

    public static boolean fireWhirl(ServerPlayer player, int windspeed, int width) {
        return simple(player, StormTypes.FIRE_WHIRL, windspeed, width, 30);
    }

    public static boolean hurricane(ServerPlayer player, int windspeed, int width) {
        ServerLevel level = player.serverLevel();
        WeatherHandlerServer handler = handler(level);
        if (handler == null) {
            return false;
        }
        Storm storm = StormTypes.CYCLONE.create(new StormSpawnProperties(handler, level, around(player, 1500), null));
        storm.width = width;
        storm.windspeed = windspeed;
        storm.cycloneWindspeed = windspeed;
        storm.velocity = Vec3.ZERO;
        storm.initFirstTime();
        storm.maxStage = Math.max(storm.maxStage, 3);
        storm.maxProgress = Math.max(storm.maxProgress, 100);
        storm.maxWindspeed = windspeed;
        storm.maxWidth = width;
        storm.calcRain();
        return launch(handler, storm, true);
    }

    private static boolean simple(ServerPlayer player, StormType type, int windspeed, int width, double distance) {
        ServerLevel level = player.serverLevel();
        WeatherHandlerServer handler = handler(level);
        if (handler == null) {
            return false;
        }
        Storm storm = type.create(new StormSpawnProperties(handler, level, around(player, distance), null));
        storm.width = width;
        storm.windspeed = windspeed;
        storm.velocity = Vec3.ZERO;
        storm.energy = 0;
        storm.initFirstTime();
        storm.maxWindspeed = windspeed;
        storm.maxWidth = width;
        storm.calcRain();
        return launch(handler, storm, true);
    }

    private static boolean launch(WeatherHandlerServer handler, Storm storm, boolean aim) {
        handler.addStorm(storm);
        if (aim) {
            storm.aimAtPlayer();
        }
        handler.syncStormNew(storm);
        return true;
    }

    /** PMWeather's own heavy lightning (visual + thunder), {@code power} 1..20. */
    public static boolean lightning(ServerLevel level, Vec3 pos, float power) {
        WeatherHandlerServer handler = handler(level);
        if (handler == null) {
            return false;
        }
        handler.syncLightningNew(pos, Mth.clamp(power, 1.0F, 20.0F));
        return true;
    }

    public static boolean clearAll(ServerLevel level) {
        WeatherHandlerServer handler = handler(level);
        if (handler == null) {
            return false;
        }
        handler.clearAllStorms();
        return true;
    }

    private PmWeather() {
    }
}
