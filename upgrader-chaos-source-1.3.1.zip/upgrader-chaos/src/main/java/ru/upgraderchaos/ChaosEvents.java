package ru.upgraderchaos;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import ru.upgraderchaos.body.Organ;
import ru.upgraderchaos.body.Organs;
import ru.upgraderchaos.compat.PmWeather;
import ru.upgraderchaos.network.ChaosNetwork;
import ru.upgraderchaos.world.MobChaos;
import ru.upgraderchaos.world.WorldClock;

/** What actually happens when an event is won. Runs on the server. */
public final class ChaosEvents {
    private static final Set<String> EFFECT_BLACKLIST = Set.of("minecraft:bad_omen", "minecraft:raid_omen", "minecraft:trial_omen");

    public static void trigger(ServerPlayer player, ChaosEvent event) {
        announce(player, event);
        Discovery.add(player, event);
        switch (event) {
            case MYSTERY, DOUBLE_MYSTERY -> {
                player.sendSystemMessage(Component.translatable("result.upgrader_chaos.mystery").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC));
                // The hidden events are not added to the index: you never learn what they were.
                int count = event == ChaosEvent.DOUBLE_MYSTERY ? 2 : 1;
                for (int i = 0; i < count; i++) {
                    run(player, randomPlainEvent(player.getRandom()), true);
                }
            }
            case CHAIN_REACTION -> {
                result(player, false, "result.upgrader_chaos.chain_reaction");
                for (int i = 0; i < 3; i++) {
                    ChaosEvent next = randomPlainEvent(player.getRandom());
                    WorldClock.later(20 + i * 40, () -> {
                        if (player.isAlive() && !player.hasDisconnected()) {
                            trigger(player, next);
                        }
                    });
                }
            }
            default -> run(player, event, false);
        }
    }

    /** Any enabled event that is not one of the "pick something else" boxes. */
    private static ChaosEvent randomPlainEvent(RandomSource random) {
        List<ChaosEvent> options = new ArrayList<>();
        for (ChaosEvent candidate : ChaosEvent.values()) {
            if (candidate.category != ChaosEvent.Category.MYSTERY && ChaosConfig.isEnabled(candidate)) {
                options.add(candidate);
            }
        }
        return options.isEmpty() ? ChaosEvent.CLEAR_SKY : options.get(random.nextInt(options.size()));
    }

    static void announce(ServerPlayer player, ChaosEvent event) {
        Component name = Component.translatable(event.translationKey()).withStyle(event.category.color, ChatFormatting.BOLD);
        player.sendSystemMessage(prefix().append(Component.translatable("message.upgrader_chaos.rolled", name)));
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.END_PORTAL_SPAWN, SoundSource.PLAYERS, 0.5F, 1.6F);
        if (ChaosConfig.announceToAll()) {
            for (ServerPlayer other : player.server.getPlayerList().getPlayers()) {
                if (other != player) {
                    other.sendSystemMessage(prefix().append(Component.translatable("message.upgrader_chaos.rolled_other", player.getDisplayName(), name)));
                }
            }
        }
    }

    private static MutableComponent prefix() {
        return Component.translatable("message.upgrader_chaos.prefix").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD)
                .append(Component.literal(" ").withStyle(ChatFormatting.RESET));
    }

    /** Flavor line under the announcement; hidden when the event came out of the mystery box. */
    static void result(ServerPlayer player, boolean quiet, String key, Object... args) {
        if (!quiet) {
            player.sendSystemMessage(Component.translatable(key, args).withStyle(ChatFormatting.GRAY));
        }
    }

    private static void run(ServerPlayer player, ChaosEvent event, boolean quiet) {
        ServerLevel level = player.serverLevel();
        RandomSource random = player.getRandom();
        int duration = ChaosConfig.effectTicks();
        boolean pmw = UpgraderChaos.hasPmWeather();
        String flavor = "result.upgrader_chaos." + event.id;

        switch (event) {
            case CLEAR_SKY -> {
                level.setWeatherParameters(12000 + random.nextInt(12000), 0, false, false);
                if (pmw) {
                    PmWeather.clearAll(level);
                }
                result(player, quiet, flavor);
            }
            case RAIN -> {
                level.setWeatherParameters(0, 6000 + random.nextInt(6000), true, false);
                if (pmw) {
                    PmWeather.supercell(player, 0, 60, 300, true);
                }
                result(player, quiet, flavor);
            }
            case THUNDERSTORM -> {
                level.setWeatherParameters(0, 6000 + random.nextInt(6000), true, true);
                if (pmw) {
                    PmWeather.supercell(player, 1 + random.nextInt(2), 80, 400, true);
                }
                result(player, quiet, flavor);
            }
            case LIGHTNING_BARRAGE -> {
                lightningBarrage(player, 12);
                result(player, quiet, flavor);
            }
            case TORNADO_WEAK, TORNADO_STRONG, TORNADO_MONSTER, SUPERCELL, SQUALL_LINE, FIRE_WHIRL, HURRICANE, MEGA_LIGHTNING -> {
                if (pmw && storm(player, event, random)) {
                    result(player, quiet, flavor);
                } else {
                    level.setWeatherParameters(0, 6000, true, true);
                    lightningBarrage(player, 8);
                    result(player, quiet, "result.upgrader_chaos.no_pmweather");
                }
            }
            case DAY_NIGHT_SWAP -> {
                ServerLevel overworld = player.server.overworld();
                overworld.setDayTime(overworld.getDayTime() + 12000L);
                result(player, quiet, flavor);
            }
            case ETERNAL_NIGHT -> {
                WorldClock.startEternalNight(player.server, duration);
                result(player, quiet, flavor, duration / 20);
            }
            case TIME_WARP -> {
                WorldClock.startTimeWarp(player.server, duration);
                result(player, quiet, flavor, duration / 20);
            }
            case ORGAN_LOSS -> organLoss(player, quiet);
            case ORGAN_RESTORE -> {
                Organ back = Organs.restoreRandom(player);
                if (back != null) {
                    player.sendSystemMessage(Component.translatable("result.upgrader_chaos.organ_restore", back.displayName()).withStyle(ChatFormatting.GREEN));
                } else {
                    player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 600, 1));
                    player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 2400, 2));
                    player.sendSystemMessage(Component.translatable("result.upgrader_chaos.organ_restore_none").withStyle(ChatFormatting.GREEN));
                }
            }
            case SOUND_SHUFFLE, SOUND_MONO, SOUND_CHIPMUNK, SOUND_DEEP, SOUND_SILENCE -> {
                int mode = switch (event) {
                    case SOUND_SHUFFLE -> ChaosNetwork.SOUND_SHUFFLE;
                    case SOUND_MONO -> ChaosNetwork.SOUND_MONO;
                    case SOUND_CHIPMUNK -> ChaosNetwork.SOUND_CHIPMUNK;
                    case SOUND_DEEP -> ChaosNetwork.SOUND_DEEP;
                    default -> ChaosNetwork.SOUND_SILENCE;
                };
                // Silence is shorter, a whole five minutes of nothing is just boring.
                int ticks = event == ChaosEvent.SOUND_SILENCE ? Math.min(duration, 2400) : duration;
                worldEffect(level, mode, ticks, random.nextLong());
                result(player, quiet, flavor, ticks / 20);
            }
            case MOB_INVASION -> result(player, quiet, flavor, MobChaos.invasion(player, 4 + random.nextInt(4)));
            case STRANGE_GUESTS -> result(player, quiet, flavor, MobChaos.guests(player, 3 + random.nextInt(4)));
            case MINI_BOSS -> {
                Entity boss = MobChaos.boss(player);
                if (boss != null) {
                    result(player, quiet, flavor, boss.getDisplayName());
                } else {
                    result(player, quiet, "result.upgrader_chaos.mini_boss_none", MobChaos.invasion(player, 6));
                }
            }
            case MOBS_DUMB -> result(player, quiet, flavor, MobChaos.makeDumb(player, duration), duration / 20);
            case MOBS_SMART -> result(player, quiet, flavor, MobChaos.makeSmart(player, duration), duration / 20);
            case MOBS_GIANT -> result(player, quiet, flavor, MobChaos.resize(player, true, duration), duration / 20);
            case MOBS_TINY -> result(player, quiet, flavor, MobChaos.resize(player, false, duration), duration / 20);
            case RANDOM_EFFECT -> {
                Holder<MobEffect> effect = randomEffect(random);
                if (effect != null) {
                    player.addEffect(new MobEffectInstance(effect, 20 * (30 + random.nextInt(61)), random.nextInt(2)));
                    result(player, quiet, flavor, effect.value().getDisplayName());
                }
            }
            case EFFECT_COCKTAIL -> {
                MutableComponent names = Component.empty();
                for (int i = 0; i < 3; i++) {
                    Holder<MobEffect> effect = randomEffect(random);
                    if (effect != null) {
                        player.addEffect(new MobEffectInstance(effect, 20 * (20 + random.nextInt(41)), random.nextInt(3)));
                        if (i > 0) {
                            names.append(", ");
                        }
                        names.append(effect.value().getDisplayName());
                    }
                }
                result(player, quiet, flavor, names);
            }
            case PLAYER_TINY -> {
                MobChaos.resizePlayer(player, false, duration);
                result(player, quiet, flavor, duration / 20);
            }
            case PLAYER_GIANT -> {
                MobChaos.resizePlayer(player, true, duration);
                result(player, quiet, flavor, duration / 20);
            }
            case MYSTERY, DOUBLE_MYSTERY, CHAIN_REACTION -> {
                // Handled in trigger(); never run directly.
            }
            default -> MoreEvents.run(player, event, quiet, flavor, duration);
        }
    }

    /** A client-side effect for everyone in the player's dimension ("the world sounds/looks wrong"). */
    static void worldEffect(ServerLevel level, int kind, int ticks, long seed) {
        for (ServerPlayer other : level.players()) {
            ChaosNetwork.sendEffect(other, kind, ticks, seed);
        }
    }

    private static boolean storm(ServerPlayer player, ChaosEvent event, RandomSource random) {
        return switch (event) {
            // PMWeather force-loads every chunk inside a tornado's width, so widths stay moderate:
            // a 500+ block monster means thousands of ticking chunks and a very long save on exit.
            case TORNADO_WEAK -> PmWeather.tornado(player, 75 + random.nextInt(36), 15 + random.nextInt(26), 180);
            case TORNADO_STRONG -> PmWeather.tornado(player, 170 + random.nextInt(51), 50 + random.nextInt(71), 300);
            case TORNADO_MONSTER -> PmWeather.tornado(player, 270 + random.nextInt(61), 160 + random.nextInt(141), 400);
            case SUPERCELL -> PmWeather.supercell(player, 3, 70 + random.nextInt(30), 900, true);
            case SQUALL_LINE -> PmWeather.squall(player, 3, 80 + random.nextInt(20));
            case FIRE_WHIRL -> PmWeather.fireWhirl(player, 40 + random.nextInt(41), 3 + random.nextInt(6));
            case HURRICANE -> PmWeather.hurricane(player, 100 + random.nextInt(81), 4000 + random.nextInt(4001));
            case MEGA_LIGHTNING -> {
                Vec3 pos = groundNear(player, 5 + random.nextInt(8));
                PmWeather.lightning(player.serverLevel(), pos, 20.0F);
                bolt(player.serverLevel(), pos);
                yield true;
            }
            default -> false;
        };
    }

    static void organLoss(ServerPlayer player, boolean quiet) {
        // The integrity amulet takes the hit instead and breaks.
        for (ItemStack stack : player.getInventory().items) {
            if (stack.is(ChaosItems.INTEGRITY_AMULET.get())) {
                stack.shrink(1);
                player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 0.8F, 1.3F);
                player.sendSystemMessage(Component.translatable("result.upgrader_chaos.amulet_saved").withStyle(ChatFormatting.GOLD));
                return;
            }
        }
        Organ taken = Organs.removeRandom(player);
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.PLAYER_HURT_SWEET_BERRY_BUSH, SoundSource.PLAYERS, 1.0F, 0.6F);
        player.hurt(player.damageSources().magic(), 2.0F);
        if (taken == null) {
            player.addEffect(new MobEffectInstance(MobEffects.WITHER, 200, 1));
            player.sendSystemMessage(Component.translatable("result.upgrader_chaos.organ_loss_none").withStyle(ChatFormatting.DARK_RED));
        } else if (quiet) {
            player.sendSystemMessage(Component.translatable("result.upgrader_chaos.organ_loss_quiet").withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC));
        } else {
            player.sendSystemMessage(Component.translatable("result.upgrader_chaos.organ_loss", taken.displayName().copy().withStyle(ChatFormatting.RED), taken.effectText())
                    .withStyle(ChatFormatting.DARK_RED));
        }
    }

    static void lightningBarrage(ServerPlayer player, int strikes) {
        for (int i = 0; i < strikes; i++) {
            WorldClock.later(10 + i * 14, () -> {
                if (player.isAlive() && !player.hasDisconnected()) {
                    bolt(player.serverLevel(), groundNear(player, 4 + player.getRandom().nextInt(20)));
                }
            });
        }
    }

    static Vec3 groundNear(ServerPlayer player, int distance) {
        RandomSource random = player.getRandom();
        double angle = random.nextDouble() * Math.PI * 2.0;
        int x = player.getBlockX() + (int) Math.round(Math.cos(angle) * distance);
        int z = player.getBlockZ() + (int) Math.round(Math.sin(angle) * distance);
        int y = player.serverLevel().getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        return Vec3.atBottomCenterOf(new BlockPos(x, y, z));
    }

    static void bolt(ServerLevel level, Vec3 pos) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(pos);
            level.addFreshEntity(bolt);
        }
    }

    private static Holder<MobEffect> randomEffect(RandomSource random) {
        List<Holder<MobEffect>> effects = new ArrayList<>();
        BuiltInRegistries.MOB_EFFECT.holders().forEach(holder -> {
            if (!holder.value().isInstantenous() && !EFFECT_BLACKLIST.contains(holder.key().location().toString())) {
                effects.add(holder);
            }
        });
        return effects.isEmpty() ? null : effects.get(random.nextInt(effects.size()));
    }

    private ChaosEvents() {
    }
}
