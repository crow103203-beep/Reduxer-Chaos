package ru.upgraderchaos.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import ru.upgraderchaos.UpgraderChaos;
import ru.upgraderchaos.network.ChaosNetwork;

/**
 * Things only this player sees and hears. Fake mobs live only in the client world (the server knows nothing
 * about them), fake ore is a client-side block swap, fake chat never left the client.
 */
@EventBusSubscriber(modid = UpgraderChaos.MOD_ID, value = Dist.CLIENT)
public final class ClientHallucinations {
    private static final int CHAT_LINES = 8;
    private static final List<EntityType<?>> PHANTOM_TYPES = List.of(EntityType.CREEPER, EntityType.ZOMBIE,
            EntityType.ENDERMAN, EntityType.SKELETON, EntityType.SPIDER, EntityType.WITCH);

    private record FakeMob(Entity entity, long until) {
    }

    private record FakeBlock(BlockPos pos, BlockState original, BlockState fake, long until) {
    }

    private record Task(long at, Runnable action) {
    }

    private static final List<FakeMob> MOBS = new ArrayList<>();
    private static final List<FakeBlock> BLOCKS = new ArrayList<>();
    private static final List<Task> TASKS = new ArrayList<>();
    private static long ticks;
    private static long madnessUntil;
    private static int nextId = -1_000_000;

    static void start(int kind, int durationTicks, long seed) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            return;
        }
        RandomSource random = RandomSource.create(seed);
        switch (kind) {
            case ChaosNetwork.HALLU_MOBS -> {
                int count = 3 + random.nextInt(3);
                for (int i = 0; i < count; i++) {
                    spawnMob(mc, random, durationTicks);
                }
            }
            case ChaosNetwork.HALLU_CHAT -> {
                for (int i = 0; i < 4; i++) {
                    int line = random.nextInt(CHAT_LINES);
                    later(20 + random.nextInt(Math.max(20, durationTicks)), () -> fakeChat(line));
                }
            }
            case ChaosNetwork.HALLU_EXPLOSION -> fakeExplosion(mc);
            case ChaosNetwork.HALLU_TREASURE -> fakeTreasure(mc, random, durationTicks);
            case ChaosNetwork.HALLU_PAIN -> {
                for (int i = 0; i < 3; i++) {
                    later(i * 25, ClientHallucinations::phantomPain);
                }
            }
            case ChaosNetwork.HALLU_MADNESS -> madnessUntil = ticks + durationTicks;
            default -> {
            }
        }
    }

    private static void later(int delay, Runnable action) {
        TASKS.add(new Task(ticks + delay, action));
    }

    /** A statue of a mob that stares at you and vanishes when you come close. */
    private static void spawnMob(Minecraft mc, RandomSource random, int durationTicks) {
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        Entity entity = PHANTOM_TYPES.get(random.nextInt(PHANTOM_TYPES.size())).create(level);
        if (entity == null) {
            return;
        }
        double angle = random.nextDouble() * Math.PI * 2;
        double distance = 8 + random.nextDouble() * 10;
        int x = Mth.floor(player.getX() + Math.cos(angle) * distance);
        int z = Mth.floor(player.getZ() + Math.sin(angle) * distance);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        if (Math.abs(y - player.getY()) > 12) {
            y = Mth.floor(player.getY());
        }
        entity.moveTo(x + 0.5, y, z + 0.5, 0F, 0F);
        entity.setId(nextId--);
        level.addEntity(entity);
        MOBS.add(new FakeMob(entity, ticks + durationTicks));
    }

    private static void fakeChat(int line) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        Component text = Component.translatable("hallucination.upgrader_chaos.chat." + line, mc.player.getName());
        // Join/leave lines are yellow like the real ones; everything else looks like a normal chat line.
        mc.gui.getChat().addMessage(line == 2 || line == 7 ? text.copy().withStyle(ChatFormatting.YELLOW) : text);
    }

    private static void fakeExplosion(Minecraft mc) {
        LocalPlayer player = mc.player;
        double yaw = Math.toRadians(player.getYRot());
        // Right behind your back.
        double x = player.getX() + Math.sin(yaw) * 2.0;
        double z = player.getZ() - Math.cos(yaw) * 2.0;
        double y = player.getY();
        mc.level.playLocalSound(x, y, z, SoundEvents.CREEPER_PRIMED, SoundSource.HOSTILE, 1.0F, 1.0F, false);
        later(30, () -> {
            if (mc.level != null) {
                mc.level.playLocalSound(x, y, z, SoundEvents.GENERIC_EXPLODE.value(), SoundSource.BLOCKS, 4.0F, 0.9F, false);
                mc.level.addParticle(ParticleTypes.EXPLOSION_EMITTER, x, y + 1, z, 0, 0, 0);
                ClientChaos.start(ChaosNetwork.SHAKE, 15, 0);
            }
        });
    }

    /** Exposed stone around you turns into rich ore; mining it gives plain stone. */
    private static void fakeTreasure(Minecraft mc, RandomSource random, int durationTicks) {
        ClientLevel level = mc.level;
        BlockPos center = mc.player.blockPosition();
        int placed = 0;
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-6, -4, -6), center.offset(6, 4, 6))) {
            if (placed >= 10 || random.nextFloat() > 0.25F) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            boolean stone = state.is(Blocks.STONE) || state.is(Blocks.DEEPSLATE) || state.is(Blocks.ANDESITE)
                    || state.is(Blocks.DIORITE) || state.is(Blocks.GRANITE) || state.is(Blocks.TUFF);
            if (!stone || !exposed(level, pos)) {
                continue;
            }
            boolean deep = state.is(Blocks.DEEPSLATE) || state.is(Blocks.TUFF);
            BlockState fake = switch (random.nextInt(4)) {
                case 0 -> deep ? Blocks.DEEPSLATE_DIAMOND_ORE.defaultBlockState() : Blocks.DIAMOND_ORE.defaultBlockState();
                case 1 -> deep ? Blocks.DEEPSLATE_EMERALD_ORE.defaultBlockState() : Blocks.EMERALD_ORE.defaultBlockState();
                case 2 -> Blocks.ANCIENT_DEBRIS.defaultBlockState();
                default -> deep ? Blocks.DEEPSLATE_GOLD_ORE.defaultBlockState() : Blocks.GOLD_ORE.defaultBlockState();
            };
            BlockPos fixed = pos.immutable();
            level.setBlock(fixed, fake, 11);
            BLOCKS.add(new FakeBlock(fixed, state, fake, ticks + durationTicks));
            placed++;
        }
    }

    private static boolean exposed(ClientLevel level, BlockPos pos) {
        for (Direction direction : Direction.values()) {
            if (level.getBlockState(pos.relative(direction)).isAir()) {
                return true;
            }
        }
        return false;
    }

    private static void phantomPain() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.level != null) {
            mc.player.animateHurt(mc.player.getRandom().nextFloat() * 360F);
            mc.level.playLocalSound(mc.player.getX(), mc.player.getY(), mc.player.getZ(), SoundEvents.PLAYER_HURT,
                    SoundSource.PLAYERS, 1.0F, 1.0F, false);
        }
    }

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post event) {
        ticks++;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            return;
        }
        if (!TASKS.isEmpty()) {
            List<Task> due = new ArrayList<>();
            TASKS.removeIf(task -> {
                if (task.at() <= ticks) {
                    due.add(task);
                    return true;
                }
                return false;
            });
            due.forEach(task -> task.action().run());
        }

        for (Iterator<FakeMob> it = MOBS.iterator(); it.hasNext(); ) {
            FakeMob fake = it.next();
            Entity entity = fake.entity();
            boolean gone = entity.level() != mc.level || entity.isRemoved();
            if (!gone && (fake.until() <= ticks || entity.distanceToSqr(mc.player) < 16)) {
                mc.level.playLocalSound(entity.getX(), entity.getY(), entity.getZ(), SoundEvents.ENDERMAN_TELEPORT,
                        SoundSource.HOSTILE, 0.6F, 0.6F, false);
                mc.level.removeEntity(entity.getId(), Entity.RemovalReason.DISCARDED);
                gone = true;
            }
            if (gone) {
                it.remove();
            } else {
                // Keep staring at the player.
                double dx = mc.player.getX() - entity.getX();
                double dz = mc.player.getZ() - entity.getZ();
                float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90F;
                entity.setYRot(yaw);
                entity.setYHeadRot(yaw);
                entity.setYBodyRot(yaw);
            }
        }

        for (Iterator<FakeBlock> it = BLOCKS.iterator(); it.hasNext(); ) {
            FakeBlock fake = it.next();
            if (fake.until() <= ticks) {
                if (mc.level.getBlockState(fake.pos()) == fake.fake()) {
                    mc.level.setBlock(fake.pos(), fake.original(), 11);
                }
                it.remove();
            }
        }

        if (madnessUntil > ticks && mc.player.getRandom().nextInt(220) == 0) {
            int kind = ChaosNetwork.HALLU_MOBS + mc.player.getRandom().nextInt(5);
            start(kind, 400, mc.player.getRandom().nextLong());
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        MOBS.clear();
        BLOCKS.clear();
        TASKS.clear();
        madnessUntil = 0;
    }

    private ClientHallucinations() {
    }
}
