package ru.upgraderchaos.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import ru.upgraderchaos.ChaosEvent;
import ru.upgraderchaos.ChaosItems;
import ru.upgraderchaos.Compressor;
import ru.upgraderchaos.machine.ChaosMenu;
import ru.upgraderchaos.machine.UpgraderTier;
import ru.upgraderchaos.machine.WorkshopRecipe;

/**
 * An upgrader: item on the left, a compression bar, the phenomenon on the right. A side panel shows either the
 * chance of every phenomenon for the item in the slot, or the workshop where the next upgrader is built.
 */
public class ChaosScreen extends AbstractContainerScreen<ChaosMenu> {
    private static final int BG = 0xF0101828;
    private static final int PANEL = 0xFF182238;
    private static final int SLOT = 0xFF0A1222;
    private static final int TEXT = 0xFFD6E8FF;
    private static final int MUTED = 0xFF8FA8C8;
    private static final int RESULT_X = 124;
    private static final int RESULT_Y = 18;
    private static final int RESULT_SIZE = 36;
    private static final int LEFT_WIDTH = 104;
    private static final int BUTTON_Y = 84;
    private static final int SIDE_WIDTH = 164;
    private static final int SIDE_GAP = 6;
    private static final int SIDE_TOP = 22;
    private static final int CHANCE_ROW = 18;
    private static final int RECIPE_ROW = 42;

    private final UpgraderTier tier;
    private final int border;
    private final int glow;
    private Button compress;
    private Button chancesTab;
    private Button workshopTab;
    private boolean workshop;
    private double sideScroll;
    /** Chances for the item currently in the slot, recomputed when its value changes. */
    private long chancesFor = -1;
    private final List<ChaosEvent> chanceOrder = new ArrayList<>();
    private double[] chances = new double[0];
    private List<Component> pendingTooltip;

    public ChaosScreen(ChaosMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.tier = menu.tier();
        this.border = tier.border;
        this.glow = tier.glow;
        imageWidth = 176;
        imageHeight = 202;
        inventoryLabelY = ChaosMenu.INVENTORY_Y - 11;
        titleLabelY = 5;
    }

    @Override
    protected void init() {
        super.init();
        // On small windows the centered GUI leaves no room for the side panel; shift right instead of clipping it.
        leftPos = Math.max(leftPos, SIDE_WIDTH + SIDE_GAP + 2);
        compress = addRenderableWidget(Button.builder(Component.translatable("gui.upgrader_chaos.compress"), b -> click(ChaosMenu.BUTTON_COMPRESS))
                .bounds(leftPos + 8, topPos + BUTTON_Y, 160, 20)
                .build());
        addRenderableWidget(Button.builder(Component.literal("?"), b -> minecraft.setScreen(new PhenomenaIndexScreen(this, tier)))
                .bounds(leftPos + imageWidth - 16, topPos + 3, 12, 12)
                .tooltip(Tooltip.create(Component.translatable("gui.upgrader_chaos.index.title")))
                .build());
        int sideX = sideLeft();
        chancesTab = addRenderableWidget(Button.builder(Component.translatable("gui.upgrader_chaos.tab.chances"), b -> setWorkshop(false))
                .bounds(sideX + 2, topPos + 3, SIDE_WIDTH / 2 - 3, 14).build());
        workshopTab = addRenderableWidget(Button.builder(Component.translatable("gui.upgrader_chaos.tab.workshop"), b -> setWorkshop(true))
                .bounds(sideX + SIDE_WIDTH / 2 + 1, topPos + 3, SIDE_WIDTH / 2 - 3, 14).build());
        setWorkshop(workshop);
    }

    /** The open tab's button is shown pressed (inactive). */
    private void setWorkshop(boolean workshop) {
        this.workshop = workshop;
        sideScroll = 0;
        chancesTab.active = workshop;
        workshopTab.active = !workshop;
    }

    private void click(int id) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.gameMode != null) {
            mc.gameMode.handleInventoryButtonClick(menu.containerId, id);
        }
    }

    private int sideLeft() {
        return leftPos - SIDE_WIDTH - SIDE_GAP;
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        boolean spinning = menu.isSpinning();
        compress.active = !spinning && !menu.inputStack().isEmpty();
        compress.setMessage(Component.translatable(spinning ? "gui.upgrader_chaos.compressing" : "gui.upgrader_chaos.compress"));
        long value = menu.inputStack().isEmpty() ? -1 : menu.inputValue();
        if (value != chancesFor) {
            chancesFor = value;
            chanceOrder.clear();
            if (value >= 0) {
                chances = Compressor.chances(value, tier);
                for (ChaosEvent event : ChaosEvent.values()) {
                    if (chances[event.ordinal()] > 0) {
                        chanceOrder.add(event);
                    }
                }
                chanceOrder.sort((a, b) -> Double.compare(chances[b.ordinal()], chances[a.ordinal()]));
            }
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderSide(graphics, mouseX, mouseY);
        renderTooltip(graphics, mouseX, mouseY);
        ChaosEvent shown = menu.isSpinning() ? null : menu.lastResult();
        if (shown != null && inside(mouseX, mouseY, leftPos + RESULT_X, topPos + RESULT_Y, RESULT_SIZE, RESULT_SIZE)) {
            graphics.renderComponentTooltip(font, List.of(shown.displayName(),
                    Component.translatable(shown.translationKey() + ".desc").withStyle(ChatFormatting.GRAY)), mouseX, mouseY);
        }
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        frame(graphics, x, y, imageWidth, imageHeight);
        graphics.fill(x + 4, y + 14, x + imageWidth - 4, y + BUTTON_Y - 4, PANEL);

        slot(graphics, x + ChaosMenu.INPUT_X - 1, y + ChaosMenu.INPUT_Y - 1, 18);

        // Compression bar between the item and the result; fills up while spinning.
        int barX = x + 50;
        int barY = y + ChaosMenu.INPUT_Y + 5;
        int barW = 68;
        graphics.fill(barX, barY, barX + barW, barY + 6, SLOT);
        float progress = menu.isSpinning() ? 1F - (menu.spinLeft() - partialTick) / ChaosMenu.SPIN_TICKS : 0F;
        int filled = (int) (barW * Mth.clamp(progress, 0F, 1F));
        if (filled > 0) {
            graphics.fillGradient(barX, barY, barX + filled, barY + 6, glow, border);
        }

        slot(graphics, x + RESULT_X, y + RESULT_Y, RESULT_SIZE);
        ChaosEvent icon = menu.isSpinning() ? spinningIcon() : menu.lastResult();
        if (icon != null) {
            graphics.pose().pushPose();
            graphics.pose().translate(x + RESULT_X + 2, y + RESULT_Y + 2, 0);
            graphics.pose().scale(2F, 2F, 1F);
            graphics.renderItem(new ItemStack(ChaosItems.item(icon)), 0, 0);
            graphics.pose().popPose();
        }

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                slot(graphics, x + 7 + col * 18, y + ChaosMenu.INVENTORY_Y - 1 + row * 18, 18);
            }
        }
        for (int col = 0; col < 9; col++) {
            slot(graphics, x + 7 + col * 18, y + ChaosMenu.INVENTORY_Y + 57, 18);
        }

        frame(graphics, sideLeft(), y, SIDE_WIDTH, imageHeight);
    }

    private void frame(GuiGraphics graphics, int x, int y, int w, int h) {
        graphics.fill(x - 1, y - 1, x + w + 1, y + h + 1, border);
        graphics.fill(x, y, x + w, y + h, BG);
    }

    /** Flips through the icons this upgrader can produce, fast at first and slower near the end. */
    private ChaosEvent spinningIcon() {
        List<ChaosEvent> pool = chanceOrder.isEmpty() ? List.of(ChaosEvent.values()) : chanceOrder;
        int elapsed = ChaosMenu.SPIN_TICKS - menu.spinLeft();
        int step = (int) Math.sqrt(elapsed * 12.0);
        return pool.get(Math.floorMod(step * 7919 + 13, pool.size()));
    }

    private void slot(GuiGraphics graphics, int x, int y, int size) {
        graphics.fill(x - 1, y - 1, x + size + 1, y + size + 1, border);
        graphics.fill(x, y, x + size, y + size, SLOT);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(font, title, (imageWidth - font.width(title)) / 2, titleLabelY, glow, false);
        graphics.drawString(font, playerInventoryTitle, inventoryLabelX, inventoryLabelY, TEXT, false);

        // Left column (item info) and right column (result name) never share horizontal space.
        int infoY = 52;
        if (!menu.inputStack().isEmpty()) {
            graphics.drawString(font, Component.translatable("gui.upgrader_chaos.value", menu.inputValue()), 8, infoY, TEXT, false);
        } else {
            graphics.drawString(font, Component.translatable("gui.upgrader_chaos.put_item").withStyle(ChatFormatting.ITALIC), 8, infoY, MUTED, false);
        }
        // What this upgrader can produce at all: its categories.
        infoY += 9;
        for (FormattedCharSequence line : font.split(tier.categoryList(), LEFT_WIDTH)) {
            graphics.drawString(font, line, 8, infoY, TEXT, false);
            infoY += 9;
        }

        ChaosEvent result = menu.lastResult();
        Component label = menu.isSpinning() ? Component.literal("...")
                : result != null ? result.displayName() : Component.literal("—");
        int centerX = RESULT_X + RESULT_SIZE / 2;
        List<FormattedCharSequence> lines = font.split(label, (imageWidth - 4 - centerX) * 2);
        int lineY = RESULT_Y + RESULT_SIZE + 3;
        for (int i = 0; i < Math.min(3, lines.size()); i++) {
            int width = font.width(lines.get(i));
            graphics.drawString(font, lines.get(i), centerX - width / 2, lineY + i * 9, TEXT, false);
        }
    }

    // ---- side panel -------------------------------------------------------------------------------------------

    private int sideContentTop() {
        return topPos + SIDE_TOP;
    }

    private int sideContentBottom() {
        return topPos + imageHeight - 4;
    }

    private int sideContentHeight() {
        return workshop ? recipes().size() * RECIPE_ROW : chanceOrder.size() * CHANCE_ROW;
    }

    private List<WorkshopRecipe> recipes() {
        List<WorkshopRecipe> list = new ArrayList<>();
        for (WorkshopRecipe recipe : WorkshopRecipe.values()) {
            if (recipe.availableIn(tier)) {
                list.add(recipe);
            }
        }
        return list;
    }

    private void renderSide(GuiGraphics graphics, int mouseX, int mouseY) {
        int x = sideLeft();
        int top = sideContentTop();
        int bottom = sideContentBottom();
        graphics.enableScissor(x, top, x + SIDE_WIDTH, bottom);
        pendingTooltip = null;
        Component tooltipTitle = null;
        Component tooltipLine = null;
        if (workshop) {
            int y = top - (int) sideScroll;
            for (WorkshopRecipe recipe : recipes()) {
                renderRecipe(graphics, recipe, x, y, mouseX, mouseY);
                y += RECIPE_ROW;
            }
        } else if (chanceOrder.isEmpty()) {
            for (FormattedCharSequence line : font.split(Component.translatable("gui.upgrader_chaos.chances.empty").withStyle(ChatFormatting.ITALIC), SIDE_WIDTH - 12)) {
                graphics.drawString(font, line, x + 6, top + 4, MUTED, false);
                top += 9;
            }
        } else {
            int y = top - (int) sideScroll;
            for (ChaosEvent event : chanceOrder) {
                if (y + CHANCE_ROW > top && y < bottom) {
                    boolean hovered = inside(mouseX, mouseY, x, Math.max(y, top), SIDE_WIDTH, Math.min(y + CHANCE_ROW, bottom) - Math.max(y, top));
                    if (hovered) {
                        graphics.fill(x + 1, y, x + SIDE_WIDTH - 1, y + CHANCE_ROW, 0x30FFFFFF);
                        tooltipTitle = event.displayName();
                        tooltipLine = Component.translatable(event.translationKey() + ".desc").withStyle(ChatFormatting.GRAY);
                    }
                    graphics.renderItem(new ItemStack(ChaosItems.item(event)), x + 3, y + 1);
                    String percent = formatChance(chances[event.ordinal()]);
                    int percentWidth = font.width(percent);
                    String name = font.plainSubstrByWidth(event.displayName().getString(), SIDE_WIDTH - 30 - percentWidth);
                    graphics.drawString(font, Component.literal(name).withStyle(event.category.color), x + 22, y + 5, TEXT, false);
                    graphics.drawString(font, percent, x + SIDE_WIDTH - 5 - percentWidth, y + 5, glow, false);
                }
                y += CHANCE_ROW;
            }
        }
        graphics.disableScissor();
        int content = sideContentHeight();
        int visible = bottom - sideContentTop();
        if (content > visible) {
            int thumb = Math.max(12, visible * visible / content);
            int thumbY = sideContentTop() + (int) ((visible - thumb) * (sideScroll / (content - visible)));
            graphics.fill(x + SIDE_WIDTH - 3, thumbY, x + SIDE_WIDTH - 1, thumbY + thumb, border);
        }
        if (tooltipTitle != null) {
            graphics.renderComponentTooltip(font, List.of(tooltipTitle, tooltipLine), mouseX, mouseY);
        } else if (pendingTooltip != null) {
            graphics.renderComponentTooltip(font, pendingTooltip, mouseX, mouseY);
        }
    }

    static String formatChance(double chance) {
        double percent = chance * 100.0;
        if (percent >= 10) {
            return String.format(Locale.ROOT, "%.0f%%", percent);
        }
        if (percent >= 0.1) {
            return String.format(Locale.ROOT, "%.1f%%", percent);
        }
        return "<0.1%";
    }

    private void renderRecipe(GuiGraphics graphics, WorkshopRecipe recipe, int x, int y, int mouseX, int mouseY) {
        Inventory inventory = Minecraft.getInstance().player.getInventory();
        ItemStack result = recipe.result();
        graphics.renderItem(result, x + 4, y + 2);
        graphics.renderItemDecorations(font, result, x + 4, y + 2);
        Component fullName = result.getHoverName();
        String name = font.plainSubstrByWidth(fullName.getString(), SIDE_WIDTH - 72);
        graphics.drawString(font, Component.literal(name).withStyle(fullName.getStyle()), x + 24, y + 6, TEXT, false);

        boolean can = recipe.canCraft(inventory);
        int buttonX = x + SIDE_WIDTH - 46;
        boolean hover = inside(mouseX, mouseY, buttonX, y + 3, 42, 14);
        graphics.fill(buttonX, y + 3, buttonX + 42, y + 17, can ? (hover ? glow : border) : 0xFF333A48);
        Component craft = Component.translatable("gui.upgrader_chaos.craft");
        graphics.drawString(font, craft, buttonX + 21 - font.width(craft) / 2, y + 6, can ? 0xFFFFFFFF : 0xFF7A8090, false);

        int ix = x + 6;
        for (WorkshopRecipe.Ingredient ingredient : recipe.ingredients) {
            ItemStack stack = new ItemStack(ingredient.item().get());
            graphics.renderItem(stack, ix, y + 21);
            int have = WorkshopRecipe.count(inventory, ingredient.item().get());
            String count = String.valueOf(ingredient.count());
            graphics.pose().pushPose();
            graphics.pose().translate(0, 0, 200);
            graphics.drawString(font, count, ix + 17 - font.width(count), y + 30, have >= ingredient.count() ? 0xFF7CFF8C : 0xFFFF6B5E, true);
            graphics.pose().popPose();
            if (inside(mouseX, mouseY, ix, y + 21, 16, 16)) {
                // Drawn after the scissor is lifted, otherwise the tooltip would be clipped to the panel.
                pendingTooltip = List.of(stack.getHoverName(),
                        Component.translatable("gui.upgrader_chaos.have", have, ingredient.count()).withStyle(ChatFormatting.GRAY));
            }
            ix += 22;
        }
        graphics.fill(x + 4, y + RECIPE_ROW - 2, x + SIDE_WIDTH - 4, y + RECIPE_ROW - 1, 0x40FFFFFF);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (workshop && inside(mouseX, mouseY, sideLeft(), sideContentTop(), SIDE_WIDTH, sideContentBottom() - sideContentTop())) {
            int y = sideContentTop() - (int) sideScroll;
            for (WorkshopRecipe recipe : recipes()) {
                if (inside(mouseX, mouseY, sideLeft() + SIDE_WIDTH - 46, y + 3, 42, 14)
                        && recipe.canCraft(Minecraft.getInstance().player.getInventory())) {
                    click(ChaosMenu.BUTTON_CRAFT + recipe.ordinal());
                    Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
                    return true;
                }
                y += RECIPE_ROW;
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    /** The side panel counts as part of the screen, so clicking it never drops the carried item. */
    @Override
    protected boolean hasClickedOutside(double mouseX, double mouseY, int left, int top, int button) {
        return super.hasClickedOutside(mouseX, mouseY, left, top, button)
                && !inside(mouseX, mouseY, sideLeft(), topPos, SIDE_WIDTH, imageHeight);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (inside(mouseX, mouseY, sideLeft(), topPos, SIDE_WIDTH, imageHeight)) {
            int max = Math.max(0, sideContentHeight() - (sideContentBottom() - sideContentTop()));
            sideScroll = Mth.clamp(sideScroll - scrollY * 18, 0, max);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }
}
