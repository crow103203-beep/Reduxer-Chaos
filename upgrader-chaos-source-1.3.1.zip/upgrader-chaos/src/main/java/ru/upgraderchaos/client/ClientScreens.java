package ru.upgraderchaos.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import org.lwjgl.glfw.GLFW;
import ru.upgraderchaos.UpgraderChaos;
import ru.upgraderchaos.machine.ChaosMenu;
import ru.upgraderchaos.machine.ChaosUpgraderItem;
import ru.upgraderchaos.machine.UpgraderTier;

@EventBusSubscriber(modid = UpgraderChaos.MOD_ID, value = Dist.CLIENT)
public final class ClientScreens {
    /** The index is always one key away, no item needed. */
    public static final KeyMapping OPEN_INDEX = new KeyMapping("key.upgrader_chaos.index", InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_I, "key.categories.upgrader_chaos");

    @SubscribeEvent
    public static void onRegisterScreens(RegisterMenuScreensEvent event) {
        event.register(ChaosMenu.TYPE.get(), ChaosScreen::new);
    }

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(OPEN_INDEX);
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        while (OPEN_INDEX.consumeClick()) {
            if (Minecraft.getInstance().screen == null) {
                openIndex();
            }
        }
    }

    /** Opens the index set to the strongest upgrader the player carries. */
    public static void openIndex() {
        Minecraft mc = Minecraft.getInstance();
        UpgraderTier best = UpgraderTier.GREEN;
        if (mc.player != null) {
            for (ItemStack stack : mc.player.getInventory().items) {
                if (stack.getItem() instanceof ChaosUpgraderItem upgrader && upgrader.tier().ordinal() > best.ordinal()) {
                    best = upgrader.tier();
                }
            }
        }
        mc.setScreen(new PhenomenaIndexScreen(null, best));
    }

    private ClientScreens() {
    }
}
