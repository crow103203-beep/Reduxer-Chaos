package ru.upgraderchaos.client;

import net.minecraft.client.resources.sounds.AbstractSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;

/** A replacement sound. Its own class so the sound hook can recognise it and leave it alone. */
public class ChaosSoundInstance extends AbstractSoundInstance {
    public ChaosSoundInstance(ResourceLocation location, SoundSource source, float volume, float pitch, boolean looping, int delay,
                              SoundInstance.Attenuation attenuation, double x, double y, double z, boolean relative) {
        super(location, source, SoundInstance.createUnseededRandom());
        this.volume = volume;
        this.pitch = pitch;
        this.looping = looping;
        this.delay = delay;
        this.attenuation = attenuation;
        this.x = x;
        this.y = y;
        this.z = z;
        this.relative = relative;
    }
}
