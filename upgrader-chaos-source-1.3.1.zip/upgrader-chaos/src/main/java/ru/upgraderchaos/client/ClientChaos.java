package ru.upgraderchaos.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.Input;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.resources.sounds.TickableSoundInstance;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.client.sounds.WeighedSoundEvents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.client.event.sound.PlaySoundEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import ru.upgraderchaos.ChaosConfig;
import ru.upgraderchaos.UpgraderChaos;
import ru.upgraderchaos.network.ChaosNetwork;

/** Client half of the chaos: replaced sounds, strange vision and controls, the missing ear and the missing eye. */
@EventBusSubscriber(modid = UpgraderChaos.MOD_ID, value = Dist.CLIENT)
public final class ClientChaos {
    private static final String[] MONO_SOUNDS = {
            "entity.chicken.ambient", "entity.goat.screaming.ambient", "entity.villager.ambient", "entity.cat.ambient",
            "entity.pig.ambient", "entity.ghast.scream", "entity.cow.ambient", "entity.creeper.primed", "entity.sheep.ambient"
    };
    private static final String[] GHOST_SOUNDS = {
            "ambient.cave", "entity.creeper.primed", "entity.zombie.ambient", "block.wooden_door.open", "entity.enderman.stare",
            "entity.player.hurt", "entity.warden.heartbeat", "block.chest.open", "entity.skeleton.step", "entity.ghast.warn"
    };

    private static Set<String> organs = Set.of();
    private static Map<String, Integer> stats = Map.of();
    private static final Map<Integer, Long> UNTIL = new HashMap<>();
    private static final Map<Integer, Long> SEEDS = new HashMap<>();
    private static long clientTicks;
    private static List<ResourceLocation> shufflePool;
    private static int tinnitusLeft;

    public static void setOrgans(List<String> lost) {
        organs = new HashSet<>(lost);
    }

    public static void setStats(Map<String, Integer> counts) {
        stats = Map.copyOf(counts);
    }

    /** How many times each phenomenon happened to this player. */
    public static Map<String, Integer> stats() {
        return stats;
    }

    public static void start(int kind, int durationTicks, long seed) {
        if (kind >= ChaosNetwork.HALLU_MOBS) {
            ClientHallucinations.start(kind, durationTicks, seed);
            return;
        }
        if (ChaosNetwork.isSound(kind)) {
            // Only one sound mode at a time; the newest wins.
            UNTIL.keySet().removeIf(ChaosNetwork::isSound);
            shufflePool = null;
        }
        UNTIL.put(kind, clientTicks + durationTicks);
        SEEDS.put(kind, seed);
        if (kind == ChaosNetwork.SOUND_SILENCE) {
            Minecraft.getInstance().getSoundManager().stop();
        }
    }

    private static boolean active(int kind) {
        Long until = UNTIL.get(kind);
        return until != null && until > clientTicks;
    }

    private static int activeSound() {
        for (Map.Entry<Integer, Long> entry : UNTIL.entrySet()) {
            if (ChaosNetwork.isSound(entry.getKey()) && entry.getValue() > clientTicks) {
                return entry.getKey();
            }
        }
        return 0;
    }

    private static long seed(int kind) {
        return SEEDS.getOrDefault(kind, 0L);
    }

    private static boolean missing(String organ) {
        return organs.contains(organ);
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        clientTicks++;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.isPaused()) {
            return;
        }
        RandomSource random = mc.player.getRandom();
        // Ringing in the missing ear: a few quiet high notes now and then.
        if (missing("ear")) {
            if (tinnitusLeft == 0 && random.nextInt(1800) == 0) {
                tinnitusLeft = 60;
            }
            if (tinnitusLeft > 0) {
                if (tinnitusLeft % 6 == 0) {
                    mc.getSoundManager().play(new ChaosSoundInstance(SoundEvents.NOTE_BLOCK_CHIME.value().getLocation(),
                            SoundSource.MASTER, 0.12F, 2.0F, false, 0, SoundInstance.Attenuation.NONE, 0, 0, 0, true));
                }
                tinnitusLeft--;
            }
        }
        // Ghost sounds: something creaks or breathes somewhere near you.
        if (activeSound() == ChaosNetwork.SOUND_GHOSTS && random.nextInt(90) == 0) {
            ResourceLocation id = ResourceLocation.withDefaultNamespace(GHOST_SOUNDS[random.nextInt(GHOST_SOUNDS.length)]);
            double angle = random.nextDouble() * Math.PI * 2;
            double dist = 3 + random.nextDouble() * 6;
            mc.getSoundManager().play(new ChaosSoundInstance(id, SoundSource.AMBIENT, 0.8F, 0.7F + random.nextFloat() * 0.4F, false, 0,
                    SoundInstance.Attenuation.LINEAR, mc.player.getX() + Math.cos(angle) * dist, mc.player.getY(),
                    mc.player.getZ() + Math.sin(angle) * dist, false));
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        organs = Set.of();
        stats = Map.of();
        UNTIL.clear();
        SEEDS.clear();
        tinnitusLeft = 0;
    }

    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent event) {
        SoundInstance sound = event.getSound();
        if (sound == null || sound instanceof ChaosSoundInstance) {
            return;
        }
        int mode = activeSound();
        boolean deaf = missing("ear");
        if ((mode == 0 || mode == ChaosNetwork.SOUND_GHOSTS) && !deaf) {
            return;
        }
        if (mode == ChaosNetwork.SOUND_SILENCE) {
            event.setSound(null);
            return;
        }
        // Moving/looping sounds (music, minecarts, elytra) keep their own logic.
        if (sound instanceof TickableSoundInstance || sound.getSource() == SoundSource.MASTER || sound.getSource() == SoundSource.MUSIC) {
            return;
        }
        SoundManager manager = Minecraft.getInstance().getSoundManager();
        WeighedSoundEvents resolved = sound.resolve(manager);
        if (resolved == null) {
            return;
        }
        ResourceLocation location = sound.getLocation();
        float volume = sound.getVolume();
        float pitch = sound.getPitch();
        switch (mode) {
            case ChaosNetwork.SOUND_SHUFFLE -> location = shuffled(manager, location);
            case ChaosNetwork.SOUND_MONO -> location = ResourceLocation.withDefaultNamespace(MONO_SOUNDS[Math.floorMod(seed(mode), MONO_SOUNDS.length)]);
            case ChaosNetwork.SOUND_CHIPMUNK -> pitch = Math.min(2.0F, pitch * 1.9F);
            case ChaosNetwork.SOUND_DEEP -> pitch = Math.max(0.5F, pitch * 0.5F);
            case ChaosNetwork.SOUND_BROKEN_RADIO -> pitch = 0.5F + (float) Math.random() * 1.5F;
            default -> {
            }
        }
        if (deaf) {
            volume *= 0.35F;
        }
        event.setSound(copy(sound, location, volume, pitch));
        if (mode == ChaosNetwork.SOUND_ECHO) {
            manager.playDelayed(copy(sound, location, volume * 0.5F, pitch), 8);
            manager.playDelayed(copy(sound, location, volume * 0.25F, pitch), 16);
        }
    }

    private static ChaosSoundInstance copy(SoundInstance sound, ResourceLocation location, float volume, float pitch) {
        return new ChaosSoundInstance(location, sound.getSource(), volume, pitch, sound.isLooping(), sound.getDelay(),
                sound.getAttenuation(), sound.getX(), sound.getY(), sound.getZ(), sound.isRelative());
    }

    /** Each sound always turns into the same other sound for the whole event, so the world stays "consistent". */
    private static ResourceLocation shuffled(SoundManager manager, ResourceLocation original) {
        if (shufflePool == null) {
            List<ResourceLocation> pool = new ArrayList<>();
            for (ResourceLocation id : manager.getAvailableSounds()) {
                String path = id.getPath();
                if (!path.startsWith("music") && !path.startsWith("ambient.") && !path.contains("record")) {
                    pool.add(id);
                }
            }
            pool.sort(null);
            shufflePool = pool;
        }
        if (shufflePool.isEmpty()) {
            return original;
        }
        return shufflePool.get(Math.floorMod(Objects.hash(original.toString(), seed(activeSound())), shufflePool.size()));
    }

    @SubscribeEvent
    public static void onFog(ViewportEvent.RenderFog event) {
        if (active(ChaosNetwork.FOG)) {
            event.setNearPlaneDistance(0F);
            event.setFarPlaneDistance(Math.min(event.getFarPlaneDistance(), 14F));
            event.setCanceled(true);
        } else if (active(ChaosNetwork.BLOOD_MOON)) {
            event.setNearPlaneDistance(0F);
            event.setFarPlaneDistance(Math.min(event.getFarPlaneDistance(), 72F));
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor event) {
        if (active(ChaosNetwork.BLOOD_MOON)) {
            event.setRed(0.45F);
            event.setGreen(0.02F);
            event.setBlue(0.03F);
        } else if (active(ChaosNetwork.FOG)) {
            event.setRed(0.7F);
            event.setGreen(0.7F);
            event.setBlue(0.72F);
        }
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        float t = clientTicks + (float) event.getPartialTick();
        if (active(ChaosNetwork.UPSIDE_DOWN)) {
            event.setRoll(event.getRoll() + 180F);
        }
        if (active(ChaosNetwork.CAROUSEL)) {
            event.setRoll(event.getRoll() + (t * 6F) % 360F);
        }
        if (active(ChaosNetwork.DRUNK_SWAY)) {
            event.setRoll(event.getRoll() + Mth.sin(t * 0.08F) * 10F);
            event.setYaw(event.getYaw() + Mth.sin(t * 0.05F) * 4F);
        }
        if (active(ChaosNetwork.SHAKE)) {
            RandomSource random = RandomSource.create((long) (t * 3));
            event.setYaw(event.getYaw() + (random.nextFloat() - 0.5F) * 2.4F);
            event.setPitch(event.getPitch() + (random.nextFloat() - 0.5F) * 2.4F);
            event.setRoll(event.getRoll() + (random.nextFloat() - 0.5F) * 3F);
        }
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        if (active(ChaosNetwork.FISHEYE)) {
            event.setFOV(Math.min(170.0, event.getFOV() * 1.9));
        }
    }

    @SubscribeEvent
    public static void onMovement(MovementInputUpdateEvent event) {
        if (!active(ChaosNetwork.INVERTED_CONTROLS)) {
            return;
        }
        Input input = event.getInput();
        input.forwardImpulse = -input.forwardImpulse;
        input.leftImpulse = -input.leftImpulse;
        boolean up = input.up;
        input.up = input.down;
        input.down = up;
        boolean left = input.left;
        input.left = input.right;
        input.right = left;
    }

    /** Missing eye: the left part of the screen fades to black. */
    private static void renderEye(GuiGraphics graphics) {
        Minecraft mc = Minecraft.getInstance();
        if (!missing("eye") || mc.options.hideGui || mc.player == null || !ChaosConfig.eyeOverlay()) {
            return;
        }
        int width = graphics.guiWidth();
        int height = graphics.guiHeight();
        int solid = width * 28 / 100;
        int fade = width * 18 / 100;
        graphics.fill(0, 0, solid, height, 0xF2000000);
        for (int i = 0; i < fade; i += 2) {
            int alpha = (int) (0xF2 * Math.pow(1.0 - (double) i / fade, 1.6));
            graphics.fill(solid + i, 0, solid + i + 2, height, alpha << 24);
        }
    }

    @EventBusSubscriber(modid = UpgraderChaos.MOD_ID, value = Dist.CLIENT)
    public static final class ModEvents {
        @SubscribeEvent
        public static void onRegisterLayers(RegisterGuiLayersEvent event) {
            event.registerAbove(VanillaGuiLayers.CAMERA_OVERLAYS, UpgraderChaos.id("missing_eye"), (graphics, delta) -> renderEye(graphics));
        }
    }

    private ClientChaos() {
    }
}
