package ru.upgraderchaos.client;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import ru.upgraderchaos.ChaosConfig;
import ru.upgraderchaos.ChaosEvent;
import ru.upgraderchaos.ChaosItems;
import ru.upgraderchaos.Compressor;
import ru.upgraderchaos.machine.UpgraderTier;

/**
 * Every phenomenon grouped by kind, with its value, how often it already happened to you, and its drop chance
 * for a chosen upgrader and item value. Opened from the index item, the "?" button in an upgrader, or a key.
 */
public class PhenomenaIndexScreen extends Screen {
    private static final int BG = 0xF0101828;
    private static final int ROW = 18;
    private static final int PANEL_WIDTH = 350;
    private static final long[] VALUES = {1, 10, 40, 100, 250, 400, 1000, 2500, 6400, 25600};

    /** Either a category header (event == null) or one phenomenon. */
    private record Entry(ChaosEvent.Category category, @Nullable ChaosEvent event) {
    }

    @Nullable
    private final Screen parent;
    private final List<Entry> entries = new ArrayList<>();
    private final List<Button> tierButtons = new ArrayList<>();
    private UpgraderTier tier;
    private int valueIndex = 3;
    private double[] chances;
    private double scroll;

    public PhenomenaIndexScreen(@Nullable Screen parent, UpgraderTier tier) {
        super(Component.translatable("gui.upgrader_chaos.index.title"));
        this.parent = parent;
        this.tier = tier;
        for (ChaosEvent.Category category : ChaosEvent.Category.values()) {
            entries.add(new Entry(category, null));
            List<ChaosEvent> events = new ArrayList<>();
            for (ChaosEvent event : ChaosEvent.values()) {
                if (event.category == category) {
                    events.add(event);
                }
            }
            events.sort(Comparator.comparingDouble(ChaosConfig::value));
            for (ChaosEvent event : events) {
                entries.add(new Entry(category, event));
            }
        }
        recompute();
    }

    private void recompute() {
        chances = Compressor.chances(VALUES[valueIndex], tier);
    }

    private int left() {
        return (width - PANEL_WIDTH) / 2;
    }

    private int listTop() {
        return 74;
    }

    private int listBottom() {
        return height - 14;
    }

    private int maxScroll() {
        return Math.max(0, entries.size() * ROW - (listBottom() - listTop()));
    }

    @Override
    protected void init() {
        int x = left() + 8;
        int buttonWidth = (PANEL_WIDTH - 16) / UpgraderTier.values().length;
        tierButtons.clear();
        for (UpgraderTier option : UpgraderTier.values()) {
            Button button = addRenderableWidget(Button.builder(
                    Component.translatable("tier.upgrader_chaos.color." + option.ordinal()).withStyle(option.color), b -> selectTier(option))
                    .tooltip(Tooltip.create(Component.empty().append(option.theme()).append("\n").append(option.categoryList())))
                    .bounds(x + option.ordinal() * buttonWidth, 34, buttonWidth - 2, 14).build());
            tierButtons.add(button);
        }
        selectTier(tier);
        int y = 52;
        addRenderableWidget(Button.builder(Component.literal("<"), b -> shiftValue(-1)).bounds(left() + 8, y, 16, 14).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> shiftValue(1)).bounds(left() + PANEL_WIDTH - 24, y, 16, 14).build());
    }

    /** The chosen tier's button is shown pressed (inactive). */
    private void selectTier(UpgraderTier option) {
        tier = option;
        for (int i = 0; i < tierButtons.size(); i++) {
            tierButtons.get(i).active = i != option.ordinal();
        }
        recompute();
    }

    private void shiftValue(int delta) {
        valueIndex = Mth.clamp(valueIndex + delta, 0, VALUES.length - 1);
        recompute();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scroll = Mth.clamp(scroll - scrollY * ROW * 2, 0, maxScroll());
        return true;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        int left = left();
        int right = left + PANEL_WIDTH;

        Map<String, Integer> stats = ClientChaos.stats();
        long seen = entries.stream().filter(e -> e.event() != null && stats.containsKey(e.event().id)).count();
        graphics.drawCenteredString(font, title.copy().withStyle(ChatFormatting.BOLD), width / 2, 13, tier.glow);
        graphics.drawCenteredString(font, Component.translatable("gui.upgrader_chaos.index.found", seen, ChaosEvent.values().length), width / 2, 23, 0xFF8FA8C8);
        Component valueLine = Component.translatable("gui.upgrader_chaos.index.for", tier.displayName(), VALUES[valueIndex]);
        graphics.drawCenteredString(font, valueLine, width / 2, 55, 0xFFD6E8FF);

        Component hoverTitle = null;
        Component hoverDesc = null;
        graphics.enableScissor(left, listTop(), right, listBottom());
        int y = listTop() - (int) scroll;
        for (Entry entry : entries) {
            if (y + ROW >= listTop() && y <= listBottom()) {
                if (entry.event() == null) {
                    graphics.fill(left + 4, y + ROW - 3, right - 4, y + ROW - 2, tier.border);
                    graphics.drawString(font, entry.category().displayName().copy().withStyle(ChatFormatting.BOLD), left + 8, y + 6, 0xFFFFFFFF);
                } else {
                    ChaosEvent event = entry.event();
                    boolean hovered = mouseX >= left && mouseX < right && mouseY >= Math.max(y, listTop()) && mouseY < Math.min(y + ROW, listBottom());
                    if (hovered) {
                        graphics.fill(left + 2, y, right - 2, y + ROW, 0x30FFFFFF);
                        hoverTitle = event.displayName();
                        hoverDesc = Component.translatable(event.translationKey() + ".desc");
                    }
                    int count = stats.getOrDefault(event.id, 0);
                    graphics.renderItem(new ItemStack(ChaosItems.item(event)), left + 8, y + 1);
                    String name = font.plainSubstrByWidth(event.displayName().getString(), 150);
                    graphics.drawString(font, Component.literal(name).withStyle(event.category.color), left + 28, y + 5, 0xFFFFFFFF);
                    if (count > 0) {
                        graphics.drawString(font, Component.literal("✔ ×" + count).withStyle(ChatFormatting.GREEN), left + 182, y + 5, 0xFFFFFFFF);
                    }
                    String value = String.valueOf((long) ChaosConfig.value(event));
                    graphics.drawString(font, value, left + 226, y + 5, 0xFF6F86A8);
                    double chance = chances[event.ordinal()];
                    String percent = chance > 0 ? ChaosScreen.formatChance(chance) : "—";
                    graphics.drawString(font, percent, right - 10 - font.width(percent), y + 5, chance > 0 ? tier.glow : 0xFF4A5468);
                }
            }
            y += ROW;
        }
        graphics.disableScissor();

        if (maxScroll() > 0) {
            int trackHeight = listBottom() - listTop();
            int thumb = Math.max(16, trackHeight * trackHeight / (entries.size() * ROW));
            int thumbY = listTop() + (int) ((trackHeight - thumb) * (scroll / maxScroll()));
            graphics.fill(right - 4, thumbY, right - 2, thumbY + thumb, tier.border);
        }
        if (hoverTitle != null) {
            graphics.renderComponentTooltip(font, List.of(hoverTitle, hoverDesc.copy().withStyle(ChatFormatting.GRAY)), mouseX, mouseY);
        }
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        // Blurred world first, then the panel, so the buttons drawn afterwards sit on top of it.
        super.renderBackground(graphics, mouseX, mouseY, partialTick);
        int left = left();
        graphics.fill(left - 1, 7, left + PANEL_WIDTH + 1, height - 7, tier.border);
        graphics.fill(left, 8, left + PANEL_WIDTH, height - 8, BG);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
