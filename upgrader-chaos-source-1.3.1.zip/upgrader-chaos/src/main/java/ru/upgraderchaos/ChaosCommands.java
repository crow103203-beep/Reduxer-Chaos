package ru.upgraderchaos;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import ru.upgraderchaos.body.Organ;
import ru.upgraderchaos.body.Organs;

/**
 * /chaos list                         - every event with its value
 * /chaos organs [player]              - which organs are missing
 * /chaos trigger <event> [players]    - fire an event (op)
 * /chaos organs restore <players>     - give all organs back (op)
 */
@EventBusSubscriber(modid = UpgraderChaos.MOD_ID)
public final class ChaosCommands {

    @SubscribeEvent
    public static void onRegister(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("chaos")
                .then(Commands.literal("list").executes(ChaosCommands::list))
                .then(Commands.literal("trigger").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("event", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(
                                        Arrays.stream(ChaosEvent.values()).map(e -> e.id), builder))
                                .executes(ctx -> trigger(ctx, Set.of(ctx.getSource().getPlayerOrException())))
                                .then(Commands.argument("targets", EntityArgument.players())
                                        .executes(ctx -> trigger(ctx, EntityArgument.getPlayers(ctx, "targets"))))))
                .then(Commands.literal("organs")
                        .executes(ctx -> organs(ctx, ctx.getSource().getPlayerOrException()))
                        .then(Commands.literal("restore").requires(s -> s.hasPermission(2))
                                .then(Commands.argument("targets", EntityArgument.players())
                                        .executes(ChaosCommands::restore)))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ctx -> organs(ctx, EntityArgument.getPlayer(ctx, "player"))))));
    }

    private static int list(CommandContext<CommandSourceStack> ctx) {
        MutableComponent text = Component.translatable("command.upgrader_chaos.list").withStyle(ChatFormatting.DARK_PURPLE);
        for (ChaosEvent event : ChaosEvent.values()) {
            text.append("\n ").append(Component.translatable(event.translationKey()).withStyle(event.category.color))
                    .append(Component.literal(" (" + event.id + ") = " + (long) ChaosConfig.value(event)
                            + (ChaosConfig.isEnabled(event) ? "" : " [off]")).withStyle(ChatFormatting.DARK_GRAY));
        }
        ctx.getSource().sendSuccess(() -> text, false);
        return ChaosEvent.values().length;
    }

    private static int trigger(CommandContext<CommandSourceStack> ctx, Collection<ServerPlayer> targets) {
        String id = StringArgumentType.getString(ctx, "event");
        ChaosEvent event = ChaosEvent.byId(id);
        if (event == null) {
            ctx.getSource().sendFailure(Component.translatable("command.upgrader_chaos.unknown", id));
            return 0;
        }
        for (ServerPlayer player : targets) {
            ChaosEvents.trigger(player, event);
        }
        return targets.size();
    }

    private static int organs(CommandContext<CommandSourceStack> ctx, ServerPlayer player) {
        Set<Organ> lost = Organs.lost(player);
        if (lost.isEmpty()) {
            ctx.getSource().sendSuccess(() -> Component.translatable("command.upgrader_chaos.organs_none", player.getDisplayName()), false);
            return 0;
        }
        MutableComponent text = Component.translatable("command.upgrader_chaos.organs", player.getDisplayName()).withStyle(ChatFormatting.DARK_RED);
        for (Organ organ : lost) {
            text.append("\n - ").append(organ.displayName().copy().withStyle(ChatFormatting.RED))
                    .append(Component.literal(": ").withStyle(ChatFormatting.GRAY)).append(organ.effectText().copy().withStyle(ChatFormatting.GRAY));
        }
        ctx.getSource().sendSuccess(() -> text, false);
        return lost.size();
    }

    private static int restore(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        Collection<ServerPlayer> targets = EntityArgument.getPlayers(ctx, "targets");
        for (ServerPlayer player : targets) {
            Organs.restoreAll(player);
            player.sendSystemMessage(Component.translatable("command.upgrader_chaos.restored").withStyle(ChatFormatting.GREEN));
        }
        ctx.getSource().sendSuccess(() -> Component.translatable("command.upgrader_chaos.restored_count", targets.size()), true);
        return targets.size();
    }

    private ChaosCommands() {
    }
}
