package ru.upgraderchaos;

import com.mojang.serialization.Codec;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/** Data stored on players. */
public final class ChaosAttachments {
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS = DeferredRegister.create(NeoForgeRegistries.Keys.ATTACHMENT_TYPES, UpgraderChaos.MOD_ID);

    /** Ids of lost organs. Copied over on death by Organs, depending on the config. */
    public static final Supplier<AttachmentType<List<String>>> LOST_ORGANS = ATTACHMENTS.register("lost_organs",
            () -> AttachmentType.<List<String>>builder(() -> List.of()).serialize(Codec.STRING.listOf()).build());

    /** How many times each phenomenon happened to the player. */
    public static final Supplier<AttachmentType<Map<String, Integer>>> EVENT_COUNTS = ATTACHMENTS.register("event_counts",
            () -> AttachmentType.<Map<String, Integer>>builder(() -> Map.of()).serialize(Codec.unboundedMap(Codec.STRING, Codec.INT)).copyOnDeath().build());

    /** Version 1.1 only kept which phenomena were seen; read once and moved into EVENT_COUNTS. */
    public static final Supplier<AttachmentType<List<String>>> LEGACY_DISCOVERED = ATTACHMENTS.register("discovered",
            () -> AttachmentType.<List<String>>builder(() -> List.of()).serialize(Codec.STRING.listOf()).copyOnDeath().build());

    private ChaosAttachments() {
    }
}
