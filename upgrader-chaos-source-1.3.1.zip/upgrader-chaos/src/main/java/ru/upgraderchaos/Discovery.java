package ru.upgraderchaos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import ru.upgraderchaos.network.ChaosNetwork;

/** Per-player statistics of phenomena, shown in the index. Kept through death. */
@EventBusSubscriber(modid = UpgraderChaos.MOD_ID)
public final class Discovery {

    public static void add(ServerPlayer player, ChaosEvent event) {
        Map<String, Integer> counts = new HashMap<>(player.getData(ChaosAttachments.EVENT_COUNTS));
        counts.merge(event.id, 1, Integer::sum);
        player.setData(ChaosAttachments.EVENT_COUNTS, Map.copyOf(counts));
        ChaosNetwork.sendStats(player);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        List<String> legacy = player.getData(ChaosAttachments.LEGACY_DISCOVERED);
        if (!legacy.isEmpty()) {
            Map<String, Integer> counts = new HashMap<>(player.getData(ChaosAttachments.EVENT_COUNTS));
            for (String id : legacy) {
                counts.putIfAbsent(id, 1);
            }
            player.setData(ChaosAttachments.EVENT_COUNTS, Map.copyOf(counts));
            player.removeData(ChaosAttachments.LEGACY_DISCOVERED);
        }
        ChaosNetwork.sendStats(player);
    }

    private Discovery() {
    }
}
