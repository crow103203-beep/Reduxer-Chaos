package ru.upgraderchaos.world;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.saveddata.SavedData;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import ru.upgraderchaos.UpgraderChaos;

/** Eternal night, fast time, and delayed actions (lightning barrages and the like). */
@EventBusSubscriber(modid = UpgraderChaos.MOD_ID)
public final class WorldClock {
    private static final List<Task> TASKS = new ArrayList<>();
    private static long serverTicks;

    public static void later(int delayTicks, Runnable action) {
        TASKS.add(new Task(serverTicks + Math.max(1, delayTicks), action));
    }

    public static void startEternalNight(MinecraftServer server, int durationTicks) {
        ServerLevel overworld = server.overworld();
        State state = State.get(overworld);
        state.eternalNightUntil = overworld.getGameTime() + durationTicks;
        state.setDirty();
        long day = overworld.getDayTime();
        overworld.setDayTime(day - Math.floorMod(day, 24000L) + 18000L);
    }

    public static void startEternalDay(MinecraftServer server, int durationTicks) {
        ServerLevel overworld = server.overworld();
        State state = State.get(overworld);
        state.eternalDayUntil = overworld.getGameTime() + durationTicks;
        state.setDirty();
        long day = overworld.getDayTime();
        overworld.setDayTime(day - Math.floorMod(day, 24000L) + 6000L);
    }

    public static void startTimeWarp(MinecraftServer server, int durationTicks) {
        ServerLevel overworld = server.overworld();
        State state = State.get(overworld);
        state.timeWarpUntil = overworld.getGameTime() + durationTicks;
        state.setDirty();
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        serverTicks++;
        if (!TASKS.isEmpty()) {
            List<Task> due = new ArrayList<>();
            for (Iterator<Task> it = TASKS.iterator(); it.hasNext(); ) {
                Task task = it.next();
                if (task.runAt <= serverTicks) {
                    due.add(task);
                    it.remove();
                }
            }
            for (Task task : due) {
                try {
                    task.action.run();
                } catch (Exception e) {
                    UpgraderChaos.LOGGER.warn("Delayed chaos action failed", e);
                }
            }
        }

        ServerLevel overworld = event.getServer().overworld();
        State state = State.get(overworld);
        long now = overworld.getGameTime();
        boolean cycle = overworld.getGameRules().getBoolean(GameRules.RULE_DAYLIGHT);
        if (state.eternalNightUntil > now || state.eternalDayUntil > now) {
            if (cycle) {
                // Undo the vanilla +1 so the clock stays at midnight (or noon).
                overworld.setDayTime(overworld.getDayTime() - 1);
            }
        } else if (state.timeWarpUntil > now) {
            overworld.setDayTime(overworld.getDayTime() + 19);
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        TASKS.clear();
    }

    private record Task(long runAt, Runnable action) {
    }

    public static final class State extends SavedData {
        long eternalNightUntil;
        long eternalDayUntil;
        long timeWarpUntil;

        static State get(ServerLevel overworld) {
            return overworld.getDataStorage().computeIfAbsent(new Factory<>(State::new, State::load, null), UpgraderChaos.MOD_ID);
        }

        static State load(CompoundTag tag, HolderLookup.Provider registries) {
            State state = new State();
            state.eternalNightUntil = tag.getLong("eternal_night_until");
            state.eternalDayUntil = tag.getLong("eternal_day_until");
            state.timeWarpUntil = tag.getLong("time_warp_until");
            return state;
        }

        @Override
        public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
            tag.putLong("eternal_night_until", eternalNightUntil);
            tag.putLong("eternal_day_until", eternalDayUntil);
            tag.putLong("time_warp_until", timeWarpUntil);
            return tag;
        }
    }

    private WorldClock() {
    }
}
