package ru.upgraderchaos.world;

import com.mojang.datafixers.util.Pair;
import java.util.function.Consumer;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.Climate;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import terrablender.api.Region;
import terrablender.api.RegionType;
import terrablender.api.Regions;
import ru.upgraderchaos.UpgraderChaos;

/**
 * The Chaos Lands: a purple biome with chaos trees and the ores for the upgraders. The biome itself and its
 * features are data (worldgen/*.json); this class only places it into the overworld through TerraBlender,
 * taking the spot of plains, forests and meadows in some regions.
 */
public final class ChaosBiome {
    public static final ResourceKey<Biome> CHAOS_LANDS = ResourceKey.create(Registries.BIOME, UpgraderChaos.id("chaos_lands"));
    private static final int REGION_WEIGHT = 4;

    public static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> Regions.register(new ChaosRegion()));
    }

    private static final class ChaosRegion extends Region {
        ChaosRegion() {
            super(UpgraderChaos.id("overworld"), RegionType.OVERWORLD, REGION_WEIGHT);
        }

        @Override
        public void addBiomes(Registry<Biome> registry, Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> mapper) {
            addModifiedVanillaOverworldBiomes(mapper, builder -> {
                builder.replaceBiome(Biomes.PLAINS, CHAOS_LANDS);
                builder.replaceBiome(Biomes.SUNFLOWER_PLAINS, CHAOS_LANDS);
                builder.replaceBiome(Biomes.FOREST, CHAOS_LANDS);
                builder.replaceBiome(Biomes.MEADOW, CHAOS_LANDS);
            });
        }
    }

    private ChaosBiome() {
    }
}
