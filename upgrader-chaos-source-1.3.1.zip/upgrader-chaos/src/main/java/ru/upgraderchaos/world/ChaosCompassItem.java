package ru.upgraderchaos.world;

import com.mojang.datafixers.util.Pair;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.item.ItemStack;
import ru.upgraderchaos.DescribedItem;

/** Right-click: tells how far and in which direction the nearest Chaos Lands are. */
public class ChaosCompassItem extends DescribedItem {
    private static final int SEARCH_RADIUS = 6400;
    private static final String[] DIRECTIONS = {"south", "southwest", "west", "northwest", "north", "northeast", "east", "southeast"};

    public ChaosCompassItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player instanceof ServerPlayer serverPlayer && level instanceof ServerLevel serverLevel) {
            player.getCooldowns().addCooldown(this, 100);
            Pair<BlockPos, Holder<Biome>> found = serverLevel.findClosestBiome3d(
                    biome -> biome.is(ChaosBiome.CHAOS_LANDS), player.blockPosition(), SEARCH_RADIUS, 32, 64);
            if (found == null) {
                serverPlayer.displayClientMessage(Component.translatable("message.upgrader_chaos.compass.none").withStyle(ChatFormatting.GRAY), false);
            } else {
                BlockPos pos = found.getFirst();
                double dx = pos.getX() - player.getX();
                double dz = pos.getZ() - player.getZ();
                int distance = (int) Math.sqrt(dx * dx + dz * dz);
                // Minecraft yaw: 0 = south, 90 = west.
                double yaw = Math.toDegrees(Math.atan2(-dx, dz));
                String direction = DIRECTIONS[Math.floorMod((int) Math.round(yaw / 45.0), 8)];
                serverPlayer.displayClientMessage(Component.translatable("message.upgrader_chaos.compass.found",
                        Component.translatable("direction.upgrader_chaos." + direction), distance, pos.getX(), pos.getZ())
                        .withStyle(ChatFormatting.LIGHT_PURPLE), false);
            }
            level.playSound(null, player.blockPosition(), SoundEvents.LODESTONE_COMPASS_LOCK, SoundSource.PLAYERS, 1.0F, 1.0F);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
