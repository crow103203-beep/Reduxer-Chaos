package ru.upgraderchaos.world;

import java.util.List;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import ru.upgraderchaos.ChaosItems;
import ru.upgraderchaos.UpgraderChaos;

/**
 * Blocks of the Chaos Lands biome. The better the upgrader a resource is for, the rarer it is:
 * chaos wood (green) > chaos ore (blue) > storm crystal (yellow) > blood ruby (red) > void ore (purple).
 */
public final class ChaosBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(UpgraderChaos.MOD_ID);

    public static final DeferredBlock<RotatedPillarBlock> CHAOS_LOG = BLOCKS.register("chaos_log",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.DARK_OAK_LOG).mapColor(MapColor.COLOR_PURPLE)));
    public static final DeferredBlock<Block> CHAOS_PLANKS = BLOCKS.registerSimpleBlock("chaos_planks",
            BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_PLANKS).mapColor(MapColor.COLOR_MAGENTA));
    public static final DeferredBlock<LeavesBlock> CHAOS_LEAVES = BLOCKS.register("chaos_leaves",
            () -> new LeavesBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LEAVES).mapColor(MapColor.COLOR_MAGENTA)));

    public static final DeferredBlock<DropExperienceBlock> CHAOS_ORE = BLOCKS.register("chaos_ore",
            () -> new DropExperienceBlock(UniformInt.of(1, 3), BlockBehaviour.Properties.ofFullCopy(Blocks.IRON_ORE)));
    public static final DeferredBlock<DropExperienceBlock> STORM_CRYSTAL_ORE = BLOCKS.register("storm_crystal_ore",
            () -> new DropExperienceBlock(UniformInt.of(2, 5), BlockBehaviour.Properties.ofFullCopy(Blocks.GOLD_ORE).lightLevel(s -> 4)));
    public static final DeferredBlock<DropExperienceBlock> BLOOD_RUBY_ORE = BLOCKS.register("blood_ruby_ore",
            () -> new DropExperienceBlock(UniformInt.of(3, 7), BlockBehaviour.Properties.ofFullCopy(Blocks.DIAMOND_ORE)));
    public static final DeferredBlock<DropExperienceBlock> VOID_ORE = BLOCKS.register("void_ore",
            () -> new DropExperienceBlock(UniformInt.of(5, 10), BlockBehaviour.Properties.ofFullCopy(Blocks.DEEPSLATE_DIAMOND_ORE).lightLevel(s -> 2)));

    static {
        for (DeferredBlock<?> block : List.of(CHAOS_LOG, CHAOS_PLANKS, CHAOS_LEAVES, CHAOS_ORE, STORM_CRYSTAL_ORE, BLOOD_RUBY_ORE, VOID_ORE)) {
            ChaosItems.ITEMS.registerSimpleBlockItem(block);
        }
    }

    private ChaosBlocks() {
    }
}
