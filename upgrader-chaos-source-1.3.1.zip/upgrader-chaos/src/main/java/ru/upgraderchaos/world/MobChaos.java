package ru.upgraderchaos.world;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.event.EventHooks;
import org.jetbrains.annotations.Nullable;
import ru.upgraderchaos.ChaosConfig;
import ru.upgraderchaos.UpgraderChaos;

/** Spawning mobs from the installed mods and messing with the ones that are already around. */
public final class MobChaos {
    private static final double BOSS_HEALTH = 120.0;

    private static final ResourceLocation IQ_RANGE = UpgraderChaos.id("iq_follow_range");
    private static final ResourceLocation IQ_SPEED = UpgraderChaos.id("iq_speed");
    private static final ResourceLocation IQ_DAMAGE = UpgraderChaos.id("iq_damage");
    private static final ResourceLocation IQ_ARMOR = UpgraderChaos.id("iq_armor");
    private static final ResourceLocation SIZE_SCALE = UpgraderChaos.id("size_scale");
    private static final ResourceLocation SIZE_HEALTH = UpgraderChaos.id("size_health");
    private static final ResourceLocation SIZE_SPEED = UpgraderChaos.id("size_speed");
    private static final ResourceLocation SIZE_REACH_BLOCK = UpgraderChaos.id("size_reach_block");
    private static final ResourceLocation SIZE_REACH_ENTITY = UpgraderChaos.id("size_reach_entity");
    private static final ResourceLocation SIZE_STEP = UpgraderChaos.id("size_step");

    /** Picks spawnable types of the given categories. Modded ones are preferred so you actually meet the new mobs. */
    private static List<EntityType<?>> pool(Set<MobCategory> categories) {
        Set<String> blacklist = ChaosConfig.mobBlacklist();
        Set<String> bosses = Set.copyOf(ChaosConfig.bossPool());
        List<EntityType<?>> modded = new ArrayList<>();
        List<EntityType<?>> vanilla = new ArrayList<>();
        for (EntityType<?> type : BuiltInRegistries.ENTITY_TYPE) {
            if (!categories.contains(type.getCategory()) || !type.canSummon()) {
                continue;
            }
            ResourceLocation id = BuiltInRegistries.ENTITY_TYPE.getKey(type);
            if (blacklist.contains(id.toString()) || bosses.contains(id.toString())) {
                continue;
            }
            (id.getNamespace().equals("minecraft") ? vanilla : modded).add(type);
        }
        return modded.isEmpty() ? vanilla : modded;
    }

    public static int invasion(ServerPlayer player, int count) {
        return spawnFrom(player, pool(Set.of(MobCategory.MONSTER)), count, 8, 16, false);
    }

    public static int guests(ServerPlayer player, int count) {
        return spawnFrom(player, pool(Set.of(MobCategory.CREATURE, MobCategory.AMBIENT)), count, 4, 10, false);
    }

    @Nullable
    public static Entity boss(ServerPlayer player) {
        List<EntityType<?>> types = new ArrayList<>();
        for (String id : ChaosConfig.bossPool()) {
            ResourceLocation key = ResourceLocation.tryParse(id);
            if (key != null && BuiltInRegistries.ENTITY_TYPE.containsKey(key)) {
                types.add(BuiltInRegistries.ENTITY_TYPE.get(key));
            }
        }
        if (types.isEmpty()) {
            return null;
        }
        for (int attempt = 0; attempt < 5; attempt++) {
            Entity entity = spawn(player, types.get(player.getRandom().nextInt(types.size())), 14, 22, true);
            if (entity != null) {
                return entity;
            }
        }
        return null;
    }

    /** Spawns a fixed vanilla (or any) type around the player. */
    public static List<Entity> spawnMany(ServerPlayer player, EntityType<?> type, int count, int minDist, int maxDist) {
        List<Entity> spawned = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            Entity entity = spawn(player, type, minDist, maxDist, true);
            if (entity != null) {
                spawned.add(entity);
            }
        }
        return spawned;
    }

    private static int spawnFrom(ServerPlayer player, List<EntityType<?>> types, int count, int minDist, int maxDist, boolean allowBosses) {
        if (types.isEmpty()) {
            return 0;
        }
        int spawned = 0;
        for (int attempt = 0; attempt < count * 4 && spawned < count; attempt++) {
            if (spawn(player, types.get(player.getRandom().nextInt(types.size())), minDist, maxDist, allowBosses) != null) {
                spawned++;
            }
        }
        return spawned;
    }

    @Nullable
    private static Entity spawn(ServerPlayer player, EntityType<?> type, int minDist, int maxDist, boolean allowBosses) {
        ServerLevel level = player.serverLevel();
        BlockPos pos = findSpot(level, player.blockPosition(), minDist, maxDist, player.getRandom());
        Entity entity;
        try {
            entity = type.create(level);
        } catch (Exception e) {
            return null;
        }
        if (entity == null) {
            return null;
        }
        if (!allowBosses && entity instanceof LivingEntity living && living.getMaxHealth() > BOSS_HEALTH) {
            entity.discard();
            return null;
        }
        entity.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, player.getRandom().nextFloat() * 360.0F, 0.0F);
        if (entity instanceof Mob mob) {
            try {
                EventHooks.finalizeMobSpawn(mob, level, level.getCurrentDifficultyAt(pos), MobSpawnType.EVENT, null);
            } catch (Exception e) {
                UpgraderChaos.LOGGER.debug("finalizeSpawn failed for {}", type, e);
            }
            if (mob instanceof Enemy) {
                mob.setTarget(player);
            }
        }
        if (!level.addFreshEntity(entity)) {
            return null;
        }
        return entity;
    }

    /** A free 2-block-high spot near the player's height, or the surface if there is none. */
    private static BlockPos findSpot(ServerLevel level, BlockPos center, int minDist, int maxDist, RandomSource random) {
        for (int attempt = 0; attempt < 24; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            int dist = minDist + random.nextInt(Math.max(1, maxDist - minDist + 1));
            int x = center.getX() + (int) Math.round(Math.cos(angle) * dist);
            int z = center.getZ() + (int) Math.round(Math.sin(angle) * dist);
            for (int dy = 4; dy >= -6; dy--) {
                BlockPos feet = new BlockPos(x, center.getY() + dy, z);
                if (level.isEmptyBlock(feet) && level.isEmptyBlock(feet.above())
                        && level.getBlockState(feet.below()).isFaceSturdy(level, feet.below(), Direction.UP)) {
                    return feet;
                }
            }
        }
        int x = center.getX() + random.nextInt(maxDist * 2 + 1) - maxDist;
        int z = center.getZ() + random.nextInt(maxDist * 2 + 1) - maxDist;
        return new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
    }

    public static List<Mob> nearby(ServerPlayer player) {
        double r = ChaosConfig.mobRadius();
        return player.serverLevel().getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(r), Entity::isAlive);
    }

    public static int makeDumb(ServerPlayer player, int durationTicks) {
        long until = player.serverLevel().getGameTime() + durationTicks;
        List<Mob> mobs = nearby(player);
        for (Mob mob : mobs) {
            TimedModifiers.add(mob, Attributes.FOLLOW_RANGE, IQ_RANGE, -0.9, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL, until);
            TimedModifiers.add(mob, Attributes.MOVEMENT_SPEED, IQ_SPEED, -0.4, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL, until);
            TimedModifiers.makeDumb(mob, until);
        }
        return mobs.size();
    }

    public static int makeSmart(ServerPlayer player, int durationTicks) {
        long until = player.serverLevel().getGameTime() + durationTicks;
        List<Mob> mobs = nearby(player);
        for (Mob mob : mobs) {
            TimedModifiers.clearDumb(mob);
            TimedModifiers.add(mob, Attributes.FOLLOW_RANGE, IQ_RANGE, 1.5, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL, until);
            TimedModifiers.add(mob, Attributes.MOVEMENT_SPEED, IQ_SPEED, 0.3, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL, until);
            TimedModifiers.add(mob, Attributes.ATTACK_DAMAGE, IQ_DAMAGE, 0.5, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL, until);
            TimedModifiers.add(mob, Attributes.ARMOR, IQ_ARMOR, 4.0, AttributeModifier.Operation.ADD_VALUE, until);
            if (mob instanceof Enemy) {
                mob.setTarget(player);
            }
        }
        return mobs.size();
    }

    public static int resize(ServerPlayer player, boolean giant, int durationTicks) {
        long until = player.serverLevel().getGameTime() + durationTicks;
        List<Mob> mobs = nearby(player);
        for (Mob mob : mobs) {
            if (giant) {
                TimedModifiers.add(mob, Attributes.SCALE, SIZE_SCALE, 1.5, AttributeModifier.Operation.ADD_MULTIPLIED_BASE, until);
                TimedModifiers.add(mob, Attributes.MAX_HEALTH, SIZE_HEALTH, 1.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL, until);
                mob.setHealth(mob.getMaxHealth());
            } else {
                TimedModifiers.add(mob, Attributes.SCALE, SIZE_SCALE, -0.6, AttributeModifier.Operation.ADD_MULTIPLIED_BASE, until);
                TimedModifiers.add(mob, Attributes.MOVEMENT_SPEED, SIZE_SPEED, 0.25, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL, until);
            }
        }
        return mobs.size();
    }

    public static void resizePlayer(ServerPlayer player, boolean giant, int durationTicks) {
        long until = player.serverLevel().getGameTime() + durationTicks;
        if (giant) {
            TimedModifiers.add(player, Attributes.SCALE, SIZE_SCALE, 1.0, AttributeModifier.Operation.ADD_MULTIPLIED_BASE, until);
            TimedModifiers.add(player, Attributes.BLOCK_INTERACTION_RANGE, SIZE_REACH_BLOCK, 2.5, AttributeModifier.Operation.ADD_VALUE, until);
            TimedModifiers.add(player, Attributes.ENTITY_INTERACTION_RANGE, SIZE_REACH_ENTITY, 2.0, AttributeModifier.Operation.ADD_VALUE, until);
            TimedModifiers.add(player, Attributes.STEP_HEIGHT, SIZE_STEP, 0.5, AttributeModifier.Operation.ADD_VALUE, until);
        } else {
            TimedModifiers.add(player, Attributes.SCALE, SIZE_SCALE, -0.6, AttributeModifier.Operation.ADD_MULTIPLIED_BASE, until);
            TimedModifiers.add(player, Attributes.BLOCK_INTERACTION_RANGE, SIZE_REACH_BLOCK, -1.5, AttributeModifier.Operation.ADD_VALUE, until);
            TimedModifiers.add(player, Attributes.ENTITY_INTERACTION_RANGE, SIZE_REACH_ENTITY, -1.0, AttributeModifier.Operation.ADD_VALUE, until);
        }
    }

    private MobChaos() {
    }
}
