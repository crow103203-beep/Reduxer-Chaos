package ru.upgraderchaos.world;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingChangeTargetEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import ru.upgraderchaos.UpgraderChaos;

/**
 * Attribute modifiers that remove themselves after a while. The expiry is stored in the entity's
 * persistent data, so it survives saving and reloading the world.
 */
@EventBusSubscriber(modid = UpgraderChaos.MOD_ID)
public final class TimedModifiers {
    private static final String KEY = UpgraderChaos.MOD_ID + ":timed";
    private static final String DUMB_UNTIL = UpgraderChaos.MOD_ID + ":dumb_until";

    public static void add(LivingEntity entity, Holder<Attribute> attribute, ResourceLocation id, double amount,
                           AttributeModifier.Operation operation, long untilGameTime) {
        AttributeInstance instance = entity.getAttribute(attribute);
        if (instance == null) {
            return;
        }
        instance.removeModifier(id);
        instance.addPermanentModifier(new AttributeModifier(id, amount, operation));

        ListTag list = entity.getPersistentData().getList(KEY, Tag.TAG_COMPOUND);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.getCompound(i).getString("id").equals(id.toString())) {
                list.remove(i);
            }
        }
        CompoundTag entry = new CompoundTag();
        entry.putString("attr", attribute.unwrapKey().map(k -> k.location().toString()).orElse(""));
        entry.putString("id", id.toString());
        entry.putLong("until", untilGameTime);
        list.add(entry);
        entity.getPersistentData().put(KEY, list);
    }

    public static void makeDumb(Mob mob, long untilGameTime) {
        mob.getPersistentData().putLong(DUMB_UNTIL, untilGameTime);
        mob.setTarget(null);
        mob.getNavigation().stop();
    }

    public static void clearDumb(Mob mob) {
        mob.getPersistentData().remove(DUMB_UNTIL);
    }

    private static boolean isDumb(LivingEntity entity) {
        return entity.getPersistentData().contains(DUMB_UNTIL)
                && entity.getPersistentData().getLong(DUMB_UNTIL) > entity.level().getGameTime();
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof LivingEntity entity) || entity.level().isClientSide() || entity.tickCount % 20 != 0) {
            return;
        }
        CompoundTag data = entity.getPersistentData();
        long now = entity.level().getGameTime();

        if (data.contains(DUMB_UNTIL) && data.getLong(DUMB_UNTIL) <= now) {
            data.remove(DUMB_UNTIL);
        }

        if (!data.contains(KEY)) {
            return;
        }
        ListTag list = data.getList(KEY, Tag.TAG_COMPOUND);
        for (int i = list.size() - 1; i >= 0; i--) {
            CompoundTag entry = list.getCompound(i);
            if (entry.getLong("until") > now) {
                continue;
            }
            ResourceLocation attrId = ResourceLocation.tryParse(entry.getString("attr"));
            ResourceLocation id = ResourceLocation.tryParse(entry.getString("id"));
            if (attrId != null && id != null) {
                BuiltInRegistries.ATTRIBUTE.getHolder(attrId).ifPresent(holder -> {
                    AttributeInstance instance = entity.getAttribute(holder);
                    if (instance != null) {
                        instance.removeModifier(id);
                    }
                });
            }
            list.remove(i);
        }
        if (list.isEmpty()) {
            data.remove(KEY);
        } else {
            data.put(KEY, list);
        }
        if (entity.getHealth() > entity.getMaxHealth()) {
            entity.setHealth(entity.getMaxHealth());
        }
    }

    /** Dumb mobs simply forget whoever they wanted to attack. */
    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent event) {
        if (event.getNewAboutToBeSetTarget() != null && isDumb(event.getEntity())) {
            event.setCanceled(true);
        }
    }

    private TimedModifiers() {
    }
}
