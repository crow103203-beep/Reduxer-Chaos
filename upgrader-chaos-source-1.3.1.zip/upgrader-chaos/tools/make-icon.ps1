param(
    [Parameter(Mandatory)] [string]$Vanilla,   # extracted vanilla textures (assets_minecraft_textures_*.png)
    [Parameter(Mandatory)] [string]$Upgrader,  # the purple upgrader texture
    [Parameter(Mandatory)] [string]$Out
)
# Draws the 512x512 modpack icon: a chaos vortex with the purple upgrader in its eye, lightning and "ХАОС".
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$S = 512
$bmp = New-Object System.Drawing.Bitmap $S, $S
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = 'AntiAlias'
$g.TextRenderingHint = 'AntiAliasGridFit'
function C($a, $r, $gg, $b) { [System.Drawing.Color]::FromArgb($a, $r, $gg, $b) }

# Background: deep purple glow fading to near black.
$path = New-Object System.Drawing.Drawing2D.GraphicsPath
$path.AddEllipse(-160, -170, $S + 320, $S + 320)
$bg = New-Object System.Drawing.Drawing2D.PathGradientBrush $path
$bg.CenterPoint = New-Object System.Drawing.PointF 256, 235
$bg.CenterColor = C 255 86 22 150
$bg.SurroundColors = @(C 255 6 2 14)
$g.FillRectangle($bg, 0, 0, $S, $S)

# Vortex: three spiral arms of soft dots, from the center outwards.
$cx = 256; $cy = 235
$colors = @((C 255 200 90 255), (C 255 255 70 200), (C 255 90 220 255))
for ($arm = 0; $arm -lt 3; $arm++) {
    for ($t = 0; $t -lt 260; $t++) {
        $r = 30 + $t * 1.25
        $theta = $t * 0.045 + $arm * (2 * [Math]::PI / 3)
        $x = $cx + [Math]::Cos($theta) * $r
        $y = $cy + [Math]::Sin($theta) * $r * 0.82
        $alpha = [int](190 * (1 - $t / 260.0))
        $size = 6 + $t * 0.09
        $col = $colors[$arm]
        $brush = New-Object System.Drawing.SolidBrush (C $alpha $col.R $col.G $col.B)
        $g.FillEllipse($brush, [float]($x - $size / 2), [float]($y - $size / 2), [float]$size, [float]$size)
        $brush.Dispose()
    }
}

# Glow behind the upgrader.
for ($i = 12; $i -ge 1; $i--) {
    $rad = 60 + $i * 9
    $brush = New-Object System.Drawing.SolidBrush (C 22 230 160 255)
    $g.FillEllipse($brush, $cx - $rad, $cy - $rad, $rad * 2, $rad * 2)
    $brush.Dispose()
}

# Lightning from the top corners into the vortex.
function Bolt($points) {
    $pts = $points | ForEach-Object { New-Object System.Drawing.PointF $_[0], $_[1] }
    $outer = New-Object System.Drawing.Pen (C 120 90 220 255), 14
    $outer.LineJoin = 'Round'
    $inner = New-Object System.Drawing.Pen (C 255 235 250 255), 5
    $inner.LineJoin = 'Round'
    $g.DrawLines($outer, [System.Drawing.PointF[]]$pts)
    $g.DrawLines($inner, [System.Drawing.PointF[]]$pts)
}
Bolt @(@(30, 0), @(70, 60), @(52, 70), @(110, 130), @(92, 138), @(150, 190))
Bolt @(@(490, 10), @(440, 70), @(462, 80), @(400, 135), @(420, 142), @(360, 190))

# Pixel-art pieces, scaled without smoothing.
function Pixel($file, $x, $y, $size, $angle = 0) {
    $img = New-Object System.Drawing.Bitmap $file
    $state = $g.Save()
    $g.InterpolationMode = 'NearestNeighbor'
    $g.PixelOffsetMode = 'Half'
    $g.TranslateTransform($x + $size / 2, $y + $size / 2)
    $g.RotateTransform($angle)
    $g.DrawImage($img, -$size / 2, -$size / 2, $size, $size)
    $g.Restore($state)
    $img.Dispose()
}
function V($name) { Join-Path $Vanilla $name }
# Things being sucked into the vortex.
Pixel (V 'assets_minecraft_textures_block_tnt_side.png') 40 230 70 -18
Pixel (V 'assets_minecraft_textures_item_spider_eye.png') 400 250 76 22
Pixel (V 'assets_minecraft_textures_item_wind_charge.png') 110 70 64 -10
Pixel (V 'assets_minecraft_textures_item_ender_eye.png') 340 60 60 14
Pixel (V 'assets_minecraft_textures_item_nether_star.png') 70 330 56 25
Pixel (V 'assets_minecraft_textures_item_totem_of_undying.png') 392 340 58 -20
# The purple upgrader in the eye of the storm.
Pixel $Upgrader ($cx - 112) ($cy - 112) 224

# Title with a purple glow and dark outline, readable even as a small thumbnail.
# "ХАОС" as code points, so the script works whatever encoding Windows PowerShell reads it with.
$text = -join [char[]](0x0425, 0x0410, 0x041E, 0x0421)
$font = New-Object System.Drawing.FontFamily 'Impact'
$textPath = New-Object System.Drawing.Drawing2D.GraphicsPath
$format = New-Object System.Drawing.StringFormat
$format.Alignment = 'Center'
$textPath.AddString($text, $font, 0, 128, (New-Object System.Drawing.RectangleF 0, 352, $S, 160), $format)
for ($w = 30; $w -ge 10; $w -= 5) {
    $glow = New-Object System.Drawing.Pen (C 60 200 60 255), $w
    $glow.LineJoin = 'Round'
    $g.DrawPath($glow, $textPath)
}
$outline = New-Object System.Drawing.Pen (C 255 25 0 45), 10
$outline.LineJoin = 'Round'
$g.DrawPath($outline, $textPath)
$fill = New-Object System.Drawing.Drawing2D.LinearGradientBrush (New-Object System.Drawing.Point 0, 370), (New-Object System.Drawing.Point 0, 490), (C 255 255 255 255), (C 255 230 150 255)
$g.FillPath($fill, $textPath)

$g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Write-Output "icon: $Out"
