param(
    [Parameter(Mandatory)] [string]$Vanilla,   # folder with vanilla textures extracted as assets_minecraft_textures_<kind>_<name>.png
    [Parameter(Mandatory)] [string]$Assets     # src/main/resources/assets/upgrader_chaos
)
# Generates the mod's block and item textures: vanilla shapes recolored, ores painted on stone.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$blockDir = Join-Path $Assets 'textures\block'
$itemDir = Join-Path $Assets 'textures\item'
New-Item -ItemType Directory -Force $blockDir, $itemDir | Out-Null

# Vanilla PNGs are palette images; copying them gives a 32-bit bitmap that can be painted on.
function Load($kind, $name) {
    $indexed = New-Object System.Drawing.Bitmap (Join-Path $Vanilla "assets_minecraft_textures_${kind}_$name.png")
    $copy = New-Object System.Drawing.Bitmap $indexed.Width, $indexed.Height, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    for ($y = 0; $y -lt $indexed.Height; $y++) { for ($x = 0; $x -lt $indexed.Width; $x++) { $copy.SetPixel($x, $y, $indexed.GetPixel($x, $y)) } }
    $indexed.Dispose()
    return $copy
}

# Keeps each pixel's brightness, swaps the color for $r,$g,$b. $boost lifts dark textures.
function Tint($bmp, $r, $g, $b, $boost = 1.0) {
    $out = New-Object System.Drawing.Bitmap $bmp.Width, $bmp.Height
    for ($y = 0; $y -lt $bmp.Height; $y++) {
        for ($x = 0; $x -lt $bmp.Width; $x++) {
            $p = $bmp.GetPixel($x, $y)
            $l = [Math]::Min(1.0, ((0.3 * $p.R + 0.59 * $p.G + 0.11 * $p.B) / 255.0) * $boost)
            $out.SetPixel($x, $y, [System.Drawing.Color]::FromArgb($p.A, [int]($r * $l), [int]($g * $l), [int]($b * $l)))
        }
    }
    return $out
}

function Save($bmp, $dir, $name) { $bmp.Save((Join-Path $dir "$name.png"), [System.Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose() }

# Chaos wood: purple bark, pink planks, magenta leaves.
Save (Tint (Load 'block' 'dark_oak_log') 170 90 230 1.9) $blockDir 'chaos_log'
Save (Tint (Load 'block' 'dark_oak_log_top') 190 120 240 1.5) $blockDir 'chaos_log_top'
Save (Tint (Load 'block' 'oak_planks') 200 120 240 1.15) $blockDir 'chaos_planks'
Save (Tint (Load 'block' 'oak_leaves') 220 90 255 1.25) $blockDir 'chaos_leaves'

# Ores: gems painted over stone (deepslate for the void ore). Each gem is a small diamond shape.
$gems = @(@(3, 4), @(10, 3), @(6, 10), @(12, 11), @(2, 13))
function Ore($baseName, $name, $dark, $mid, $light) {
    $bmp = Load 'block' $baseName
    foreach ($g in $gems) {
        $cx = $g[0]; $cy = $g[1]
        foreach ($d in @(@(0, -1), @(-1, 0), @(1, 0), @(0, 1))) { $bmp.SetPixel($cx + $d[0], $cy + $d[1], $dark) }
        $bmp.SetPixel($cx, $cy, $mid)
        if ($cx + 1 -lt 16 -and $cy - 1 -ge 0) { $bmp.SetPixel($cx + 1, $cy - 1, $light) }
    }
    Save $bmp $blockDir $name
}
function C($r, $g, $b) { [System.Drawing.Color]::FromArgb(255, $r, $g, $b) }
Ore 'stone' 'chaos_ore' (C 110 30 140) (C 210 80 240) (C 250 190 255)
Ore 'stone' 'storm_crystal_ore' (C 30 110 150) (C 90 220 255) (C 255 250 160)
Ore 'stone' 'blood_ruby_ore' (C 100 10 20) (C 210 30 50) (C 255 150 150)
Ore 'deepslate' 'void_ore' (C 30 0 50) (C 110 40 170) (C 220 180 255)

# Materials.
Save (Tint (Load 'item' 'amethyst_shard') 240 110 255 1.3) $itemDir 'chaos_shard'
Save (Tint (Load 'item' 'prismarine_crystals') 140 235 255 1.2) $itemDir 'storm_crystal'
Save (Tint (Load 'item' 'emerald') 255 50 70 1.3) $itemDir 'blood_ruby'
Save (Tint (Load 'item' 'echo_shard') 170 80 255 1.6) $itemDir 'void_shard'
Save (Tint (Load 'item' 'compass_00') 200 120 255 1.2) $itemDir 'chaos_compass'
Save (Tint (Load 'item' 'heart_of_the_sea') 255 120 160 1.4) $itemDir 'integrity_amulet'

# Upgraders: the blue one recolored, green (mild) to purple (catastrophe).
$blue = New-Object System.Drawing.Bitmap (Join-Path $itemDir 'blue_upgrader.png')
$copy = New-Object System.Drawing.Bitmap $blue; $blue.Dispose()
Save (Tint $copy 90 255 110 1.5) $itemDir 'green_upgrader'
Save (Tint $copy 255 225 60 1.5) $itemDir 'yellow_upgrader'
Save (Tint $copy 255 70 60 1.5) $itemDir 'red_upgrader'
Save (Tint $copy 200 80 255 1.5) $itemDir 'purple_upgrader'
$copy.Dispose()
Write-Output 'textures done'
