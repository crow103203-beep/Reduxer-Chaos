param([Parameter(Mandatory)] [string]$Resources)  # src/main/resources
# Writes the JSON for the Chaos Lands: blockstates, models, loot, tags, recipes and worldgen.
$ErrorActionPreference = 'Stop'
$enc = New-Object System.Text.UTF8Encoding($false)
function Put($path, $json) {
    $full = Join-Path $Resources $path
    New-Item -ItemType Directory -Force (Split-Path $full) | Out-Null
    [IO.File]::WriteAllText($full, $json.Trim() + "`n", $enc)
}
$ns = 'upgrader_chaos'
$ores = @('chaos_ore', 'storm_crystal_ore', 'blood_ruby_ore', 'void_ore')
$drops = @{ chaos_ore = 'chaos_shard'; storm_crystal_ore = 'storm_crystal'; blood_ruby_ore = 'blood_ruby'; void_ore = 'void_shard' }

# --- blockstates and models ---
Put "assets/$ns/blockstates/chaos_log.json" @"
{ "variants": {
  "axis=y": { "model": "$ns`:block/chaos_log" },
  "axis=z": { "model": "$ns`:block/chaos_log_horizontal", "x": 90 },
  "axis=x": { "model": "$ns`:block/chaos_log_horizontal", "x": 90, "y": 90 } } }
"@
Put "assets/$ns/models/block/chaos_log.json" "{ `"parent`": `"minecraft:block/cube_column`", `"textures`": { `"end`": `"$ns`:block/chaos_log_top`", `"side`": `"$ns`:block/chaos_log`" } }"
Put "assets/$ns/models/block/chaos_log_horizontal.json" "{ `"parent`": `"minecraft:block/cube_column_horizontal`", `"textures`": { `"end`": `"$ns`:block/chaos_log_top`", `"side`": `"$ns`:block/chaos_log`" } }"
Put "assets/$ns/models/block/chaos_leaves.json" "{ `"parent`": `"minecraft:block/cube_all`", `"render_type`": `"minecraft:cutout_mipped`", `"textures`": { `"all`": `"$ns`:block/chaos_leaves`" } }"
foreach ($b in @('chaos_planks') + $ores) {
    Put "assets/$ns/models/block/$b.json" "{ `"parent`": `"minecraft:block/cube_all`", `"textures`": { `"all`": `"$ns`:block/$b`" } }"
}
foreach ($b in @('chaos_planks', 'chaos_leaves') + $ores) {
    Put "assets/$ns/blockstates/$b.json" "{ `"variants`": { `"`": { `"model`": `"$ns`:block/$b`" } } }"
}
foreach ($b in @('chaos_log', 'chaos_planks', 'chaos_leaves') + $ores) {
    Put "assets/$ns/models/item/$b.json" "{ `"parent`": `"$ns`:block/$b`" }"
}
foreach ($i in @('chaos_shard', 'storm_crystal', 'blood_ruby', 'void_shard', 'green_upgrader', 'blue_upgrader', 'yellow_upgrader', 'red_upgrader', 'purple_upgrader', 'chaos_compass', 'integrity_amulet')) {
    Put "assets/$ns/models/item/$i.json" "{ `"parent`": `"minecraft:item/generated`", `"textures`": { `"layer0`": `"$ns`:item/$i`" } }"
}

# --- loot tables ---
foreach ($b in @('chaos_log', 'chaos_planks')) {
    Put "data/$ns/loot_table/blocks/$b.json" @"
{ "type": "minecraft:block", "pools": [ { "rolls": 1, "bonus_rolls": 0,
  "entries": [ { "type": "minecraft:item", "name": "$ns`:$b" } ],
  "conditions": [ { "condition": "minecraft:survives_explosion" } ] } ] }
"@
}
Put "data/$ns/loot_table/blocks/chaos_leaves.json" @"
{ "type": "minecraft:block", "pools": [ { "rolls": 1, "bonus_rolls": 0, "entries": [ { "type": "minecraft:alternatives", "children": [
  { "type": "minecraft:item", "name": "$ns`:chaos_leaves",
    "conditions": [ { "condition": "minecraft:any_of", "terms": [
      { "condition": "minecraft:match_tool", "predicate": { "items": "minecraft:shears" } },
      { "condition": "minecraft:match_tool", "predicate": { "predicates": { "minecraft:enchantments": [ { "enchantments": "minecraft:silk_touch", "levels": { "min": 1 } } ] } } } ] } ] },
  { "type": "minecraft:item", "name": "minecraft:stick",
    "conditions": [ { "condition": "minecraft:survives_explosion" }, { "condition": "minecraft:random_chance", "chance": 0.05 } ] } ] } ] } ] }
"@
foreach ($b in $ores) {
    $item = $drops[$b]
    Put "data/$ns/loot_table/blocks/$b.json" @"
{ "type": "minecraft:block", "pools": [ { "rolls": 1, "bonus_rolls": 0, "entries": [ { "type": "minecraft:alternatives", "children": [
  { "type": "minecraft:item", "name": "$ns`:$b",
    "conditions": [ { "condition": "minecraft:match_tool", "predicate": { "predicates": { "minecraft:enchantments": [ { "enchantments": "minecraft:silk_touch", "levels": { "min": 1 } } ] } } } ] },
  { "type": "minecraft:item", "name": "$ns`:$item",
    "functions": [ { "function": "minecraft:apply_bonus", "enchantment": "minecraft:fortune", "formula": "minecraft:ore_drops" },
                   { "function": "minecraft:explosion_decay" } ] } ] } ] } ] }
"@
}

# --- tags ---
$oreIds = ($ores | ForEach-Object { '"' + $ns + ':' + $_ + '"' }) -join ', '
Put "data/minecraft/tags/block/mineable/pickaxe.json" "{ `"values`": [ $oreIds ] }"
Put "data/minecraft/tags/block/mineable/axe.json" "{ `"values`": [ `"$ns`:chaos_log`", `"$ns`:chaos_planks`" ] }"
Put "data/minecraft/tags/block/mineable/hoe.json" "{ `"values`": [ `"$ns`:chaos_leaves`" ] }"
Put "data/minecraft/tags/block/needs_stone_tool.json" "{ `"values`": [ `"$ns`:chaos_ore`" ] }"
Put "data/minecraft/tags/block/needs_iron_tool.json" "{ `"values`": [ `"$ns`:storm_crystal_ore`", `"$ns`:blood_ruby_ore`" ] }"
Put "data/minecraft/tags/block/needs_diamond_tool.json" "{ `"values`": [ `"$ns`:void_ore`" ] }"
Put "data/minecraft/tags/block/logs_that_burn.json" "{ `"values`": [ `"$ns`:chaos_log`" ] }"
Put "data/minecraft/tags/block/leaves.json" "{ `"values`": [ `"$ns`:chaos_leaves`" ] }"
Put "data/minecraft/tags/block/planks.json" "{ `"values`": [ `"$ns`:chaos_planks`" ] }"
Put "data/minecraft/tags/item/logs_that_burn.json" "{ `"values`": [ `"$ns`:chaos_log`" ] }"
Put "data/minecraft/tags/item/planks.json" "{ `"values`": [ `"$ns`:chaos_planks`" ] }"
Put "data/minecraft/tags/item/leaves.json" "{ `"values`": [ `"$ns`:chaos_leaves`" ] }"
Put "data/minecraft/tags/worldgen/biome/is_overworld.json" "{ `"values`": [ `"$ns`:chaos_lands`" ] }"
Put "data/minecraft/tags/worldgen/biome/has_structure/mineshaft.json" "{ `"values`": [ `"$ns`:chaos_lands`" ] }"
Put "data/minecraft/tags/worldgen/biome/has_structure/ruined_portal_standard.json" "{ `"values`": [ `"$ns`:chaos_lands`" ] }"

# --- recipes (only the basics live at the crafting table; upgraders are made in workshops) ---
Put "data/$ns/recipe/chaos_planks.json" @"
{ "type": "minecraft:crafting_shapeless", "category": "building", "group": "planks",
  "ingredients": [ { "item": "$ns`:chaos_log" } ], "result": { "id": "$ns`:chaos_planks", "count": 4 } }
"@
Put "data/$ns/recipe/green_upgrader.json" @"
{ "type": "minecraft:crafting_shapeless", "category": "misc",
  "ingredients": [ { "item": "upgrader:upgrader" }, { "item": "minecraft:emerald" } ],
  "result": { "id": "$ns`:green_upgrader", "count": 1 } }
"@

# --- worldgen ---
Put "data/$ns/worldgen/configured_feature/chaos_tree.json" @"
{ "type": "minecraft:tree", "config": {
  "dirt_provider": { "type": "minecraft:simple_state_provider", "state": { "Name": "minecraft:dirt" } },
  "trunk_provider": { "type": "minecraft:simple_state_provider", "state": { "Name": "$ns`:chaos_log", "Properties": { "axis": "y" } } },
  "foliage_provider": { "type": "minecraft:simple_state_provider", "state": { "Name": "$ns`:chaos_leaves", "Properties": { "distance": "7", "persistent": "false", "waterlogged": "false" } } },
  "trunk_placer": { "type": "minecraft:straight_trunk_placer", "base_height": 5, "height_rand_a": 3, "height_rand_b": 0 },
  "foliage_placer": { "type": "minecraft:blob_foliage_placer", "radius": 2, "offset": 0, "height": 3 },
  "minimum_size": { "type": "minecraft:two_layers_feature_size", "limit": 1, "lower_size": 0, "upper_size": 1 },
  "decorators": [], "ignore_vines": true, "force_dirt": false } }
"@
Put "data/$ns/worldgen/placed_feature/chaos_trees.json" @"
{ "feature": "$ns`:chaos_tree", "placement": [
  { "type": "minecraft:count", "count": { "type": "minecraft:weighted_list", "distribution": [ { "weight": 8, "data": 3 }, { "weight": 2, "data": 5 } ] } },
  { "type": "minecraft:in_square" },
  { "type": "minecraft:surface_water_depth_filter", "max_water_depth": 0 },
  { "type": "minecraft:heightmap", "heightmap": "OCEAN_FLOOR" },
  { "type": "minecraft:block_predicate_filter", "predicate": { "type": "minecraft:would_survive", "state": { "Name": "minecraft:oak_sapling", "Properties": { "stage": "0" } } } },
  { "type": "minecraft:biome" } ] }
"@
# ore: size, veins per chunk, rarity (1 = every chunk), min y, max y
$oreGen = [ordered]@{
    chaos_ore         = @(9, 16, 1, -32, 160)
    storm_crystal_ore = @(6, 7, 1, -48, 64)
    blood_ruby_ore    = @(4, 3, 1, -64, 24)
    void_ore          = @(4, 3, 1, -60, 8)
}
foreach ($b in $oreGen.Keys) {
    $g = $oreGen[$b]
    Put "data/$ns/worldgen/configured_feature/ore_$b.json" @"
{ "type": "minecraft:ore", "config": { "size": $($g[0]), "discard_chance_on_air_exposure": 0.0, "targets": [
  { "target": { "predicate_type": "minecraft:tag_match", "tag": "minecraft:stone_ore_replaceables" }, "state": { "Name": "$ns`:$b" } },
  { "target": { "predicate_type": "minecraft:tag_match", "tag": "minecraft:deepslate_ore_replaceables" }, "state": { "Name": "$ns`:$b" } } ] } }
"@
    $rarity = if ($g[2] -gt 1) { "{ `"type`": `"minecraft:rarity_filter`", `"chance`": $($g[2]) }," } else { '' }
    Put "data/$ns/worldgen/placed_feature/ore_$b.json" @"
{ "feature": "$ns`:ore_$b", "placement": [
  $rarity
  { "type": "minecraft:count", "count": $($g[1]) },
  { "type": "minecraft:in_square" },
  { "type": "minecraft:height_range", "height": { "type": "minecraft:uniform", "min_inclusive": { "absolute": $($g[3]) }, "max_inclusive": { "absolute": $($g[4]) } } },
  { "type": "minecraft:biome" } ] }
"@
}
Write-Output 'data done'
